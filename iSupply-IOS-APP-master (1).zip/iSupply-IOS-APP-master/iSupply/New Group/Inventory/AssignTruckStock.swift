//
//  AssignTruckStock.swift
//  iSupply
//
//  Created by hassan ghouri on 15/03/2024.
//

import SwiftUI

struct AssignTruckStock: View {
    
    let userEmail:String
    let productName: String
    var flavor:String?
    var size:String?
    var weight:String?
    let productStock: Int
    let productId : String
    let productTempStock: Int
    @State private var isLoading = false
    @Environment(\.presentationMode) var presentationMode
    @State private var assignedTruckStock = ""
    @State private var alertItem: AlertType?
    @StateObject private var viewModel = UserViewModel()
    let apiManager = UsersAPI.sharedInstance
    var body: some View {
        if(isLoading || viewModel.isLoading){
            LoadingView()
        }
        NavigationStack{
            VStack{
                VStack(spacing:20){
                    HStack{
                        Text("Product: ")
                            .font(
                                Font.custom("Manrope", size: 18)
                                    .weight(.bold)
                            )
                        Text("\(productName)")
                            .font(
                                Font.custom("Manrope", size: 18)
                                    .weight(.bold)
                            )
                    }
                    HStack{
                        Text("Flavor: ")
                            .font(
                                Font.custom("Manrope", size: 18)
                                    .weight(.bold)
                            )
                        Text("\(flavor ?? "")")
                            .font(
                                Font.custom("Manrope", size: 18)
                                    .weight(.bold)
                            )
                    }
                    HStack{
                        Text("Size: ")
                            .font(
                                Font.custom("Manrope", size: 18)
                                    .weight(.bold)
                            )
                        Text("\(size ?? "")")
                            .font(
                                Font.custom("Manrope", size: 18)
                                    .weight(.bold)
                            )
                    }
                    HStack{
                        Text("Available Stock: ")
                            .font(
                                Font.custom("Manrope", size: 18)
                                    .weight(.bold)
                            )
                        Text("\(productStock-productTempStock)")
                            .font(
                                Font.custom("Manrope", size: 18)
                                    .weight(.bold)
                            )
                    }
                }
                TextFieldWithBorder(text: "Truck Stock", placeholder: "Add Stock to Truck", value: $assignedTruckStock)
                Button {
                    updateTruckStock()
                } label: {
                    ZStack{
                        Rectangle()
                          .foregroundColor(.clear)
                          .frame(width: 126.00653, height: 44.25)
                          .background(Color(red: 0.17, green: 0.19, blue: 0.58).opacity(0.8))
                          .cornerRadius(20)
                        Text("Update")
                          .font(
                            Font.custom("Manrope", size: 17)
                              .weight(.semibold)
                          )
                          .multilineTextAlignment(.center)
                          .foregroundColor(.white)
                          .frame(width: 94, height: 32, alignment: .top)
                    }
                }
            }
        }.navigationTitle("Assign Truck Stock")
        .alert(item: $alertItem) { alertType in
            switch alertType {
            case .error(let message):
                return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
            case .success(let message):
                return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                    // Navigate to previous screen
                    presentationMode.wrappedValue.dismiss()
                }, secondaryButton: .cancel())
            }
        }
        .onAppear {
            viewModel.getTruckStockByProductId(productId: productId)
        }
        .onReceive(viewModel.$truckStock) { truckStock in
                    // Update assignedTruckStock when truckStock changes
                    assignedTruckStock = truckStock ?? ""
        }
    }
    var formIsValid: Bool {
        return !assignedTruckStock.isEmpty && ((Int(assignedTruckStock) ?? 0)+productTempStock <= productStock)
    }
    
    private func updateTruckStock(){
        Task {
            isLoading = true
            if(!formIsValid){
                alertItem = .error(message: "Cannot add 0 or greater Stock than product")
                isLoading = false
                return
            }
            let user = UserModel(userName:"",email: userEmail,password: "" ,truckStock:[truckStock(productId: productId, truckStock: Int(assignedTruckStock))])
            apiManager.updateTruckStock(user:user) { result in
                switch result {
                case let .success(success):
                    if success {
                        isLoading = false
                        alertItem = .success(message: "Truck Stock Updated!")
                    }
                case let .failure(error):
                    // Handle the error
                    isLoading = false
                    alertItem = .error(message:error.localizedDescription)
                                                       
                }
            }
        }
    }
}

#Preview {
    AssignTruckStock(userEmail: "",productName:"", productStock: 0, productId:"", productTempStock: 0)
}
