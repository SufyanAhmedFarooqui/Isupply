//
//  Inventory.swift
//  iSupply
//
//  Created by hassan ghouri on 07/02/2024.
//

import SwiftUI

struct Inventory: View {
    
    var body: some View {
        NavigationStack{
            VStack(spacing: 20){
                HStack(alignment: .center, spacing: 20) {
                    NavigationLink {
                        ProductsPage()
                    } label: {
                        MainPageCard(title: "Products", imageName: "basket.fill", backColor: Color(red: 0.69, green: 0.87, blue: 0.32).opacity(0.25))
                    }
                    NavigationLink {
                        ProductsPage(lowStock:true)
                    } label: {
                        MainPageCard(title: "Low Stock", imageName: "arrow.down.square.fill", backColor: Color(red: 0.68, green: 0.45, blue: 0.38).opacity(0.25))
                    }
                }
                HStack(alignment: .center, spacing: 20) {
                    NavigationLink {
                            TruckStock()
                    } label: {
                        MainPageCard(title: "Truck Stock", imageName: "box.truck.badge.clock.fill", backColor: Color(red: 0.97, green: 0.55, blue: 0.16).opacity(0.25))
                    }

                    
                }

            }
        }.navigationTitle("Inventory")
            
    }
    
}

#Preview {
    Inventory()
}
