//
//  NewTruckStockProducts.swift
//  iSupply
//
//  Created by hassan ghouri on 16/04/2024.
//
import SwiftUI

struct NewTruckStockProducts: View {
    var vendorEmail:String?
    var salesPersonEmail: String?
    @State private var searchTerm = ""
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @StateObject private var viewModel = ProductViewModel()
    @State private var isLoading = false
    @Environment(\.presentationMode) var presentationMode
    @State private var alertItem: AlertType?
    let apiManager = UsersAPI.sharedInstance

    // Dictionary to track the assigned stock for each product
    @State private var assignedStocks: [String: truckStock] = [:]  // Keyed by product ID for easier access

    var body: some View {
        NavigationStack {
            if viewModel.isLoading {
                LoadingView()
            } else {
                List {
                    ForEach(filteredProducts) { product in
                        VStack(alignment: .leading, spacing: 10) {
                            ProductCell(product: product)
                            .onTapGesture {
                                if assignedStocks[product.id!] == nil {
                                    // Initialize with existing stock or zero if none exists
                                    assignedStocks[product.id!] = truckStock(id: UUID().uuidString, productId: product.id, truckStock: product.tempStock)
                                }
                            }

                            // Only show the text field if this product's stock has been assigned
                            if let stock = assignedStocks[product.id!] {
                                HStack {
                                    Text("Assign Truck Stock for \(product.name!):")
                                        .font(.headline)
                                    TextField(
                                        "AssignedStock: \(stock.truckStock ?? 0)",
                                        text: Binding(
                                            get: { "" },
                                            set: { newValue in
                                                var updatedStock = stock
                                                updatedStock.truckStock = Int(newValue)
                                                assignedStocks[product.id!] = updatedStock
                                            }
                                        )
                                    )
                                    .keyboardType(.numberPad)
                                }
                            }
                        }
                    }
                }
                .listStyle(.inset)
                Button{
                    updateAllTruckStocks()
                }label: {
                    Text("Update")
                }
                .searchable(text: $searchTerm, prompt: "Search Products")
                .navigationTitle("Assign Truck Stock")
                .onAppear {
                    if viewModel.products.isEmpty { // Fetch only if the products list is empty or based on some other condition
                        if userRole == "Vendor" || userRole == "Admin" {
                            viewModel.getProductsByEmail(email: userEmail, role: nil)
                        } else {
                            viewModel.getProductsByEmail(email: vendorEmail ?? "", role: nil)
                        }
                    }
                }

                .alert(item: $alertItem) { alertType in
                    switch alertType {
                    case .error(let message):
                        return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
                    case .success(let message):
                        return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                            // Navigate to previous screen
                            presentationMode.wrappedValue.dismiss()
                        }, secondaryButton: .cancel())
                    }
                }
            }
        }
    }
    
    var filteredProducts: [ProductModel] {
        var filteredArray = viewModel.products
        if !searchTerm.isEmpty {
            filteredArray = filteredArray.filter { product in
                product.name!.lowercased().contains(searchTerm.lowercased()) ||
                product.category!.lowercased().contains(searchTerm.lowercased())
            }
        }
        return filteredArray
    }

    var formIsValid: Bool {
        for (productId, assignedStock) in assignedStocks {
            guard let productStock = viewModel.products.first(where: { $0.id == productId })?.stock else {
                // If the product's stock isn't found, consider this condition as failing the check
                return false
            }
            guard let productTempStock = viewModel.products.first(where: { $0.id == productId })?.tempStock else {
                print("No  Temp Stock Found")
                // If the product's stock isn't found, consider this condition as failing the check
                return false
            }
            if let truckStock = assignedStock.truckStock, truckStock > 0, truckStock+productTempStock <= productStock {
                continue
            } else {
                return false
            }
        }
        return true
    }



    func updateAllTruckStocks() {
        // Implement the logic to update the truck stock for all products
        // using the information in the `assignedStocks` dictionary.
        for stock in assignedStocks.values {
                print("Product ID: \(stock.productId ?? "Unknown"), New Stock: \(stock.truckStock ?? 0)")
            if(!formIsValid){
                alertItem = .error(message: "Cannot add 0 or greater Stock than product")
                isLoading = false
                return
            }
            updateTruckStock(productId: stock.productId ?? "", productTruckStock: stock.truckStock)
            }
    }
    
    private func updateTruckStock(productId:String, productTruckStock:Int?){
        Task {
            isLoading = true
            if let email = salesPersonEmail {
                let user = UserModel(userName:"",email: email,password: "" ,truckStock:[truckStock(productId: productId, truckStock: productTruckStock)])
                apiManager.updateTruckStock(user:user) { result in
                    switch result {
                    case let .success(success):
                        if success {
                            isLoading = false
                            alertItem = .success(message: "Truck Stock Updated!")
                        }
                    case let .failure(error):
                        // Handle the error
                        isLoading = false
                        alertItem = .error(message:error.localizedDescription)
                                                           
                    }
                }
            }else {
                return
            }
        }
    }
}

struct Cell: View {
    let product: ProductModel
    var body: some View {
        Text(product.name ?? "Unknown")
        // Add more UI elements as needed
    }
}

// Define your other structures here...

struct NewTruckStockProducts_Previews: PreviewProvider {
    static var previews: some View {
        NewTruckStockProducts(salesPersonEmail:"salesperson@gmail.com")
    }
}
