//
//  TruckStockProducts.swift
//  iSupply
//
//  Created by hassan ghouri on 11/03/2024.
//

import SwiftUI

struct TruckStockProducts: View {
    var vendorEmail: String?
    var salesPersonEmail: String?
    @State private var searchTerm = ""
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @StateObject private var viewModel = ProductViewModel()
    var body: some View {
        NavigationStack{
            if (viewModel.isLoading){ LoadingView()}
            else {
                List(filteredProducts, id: \.id) { product in
                    NavigationLink(destination: AssignTruckStock(userEmail: salesPersonEmail ?? userEmail, productName:product.name!,flavor:product.flavourType,size:product.size,weight:product.productType, productStock: product.stock ?? 0, productId: product.id!, productTempStock:product.tempStock ?? 0)) {
                        ProductCell(product: product)
                    }
                    
                }
            }
            
        }.navigationTitle("Assign Truck Stock")
            .searchable(text: $searchTerm, prompt: "Search")
            .onAppear {
                        if userRole == "Vendor" || userRole == "Admin" {
                            viewModel.getProductsByEmail(email: userEmail, role:nil)
                        } else {
                            viewModel.getProductsByEmail(email: vendorEmail ?? "", role:nil)
                        }
            }
    }
    var filteredProducts: [ProductModel] {

        var filteredArray = viewModel.products
            if !searchTerm.isEmpty {
                filteredArray = filteredArray.filter { product in
                    product.name!.lowercased().contains(searchTerm.lowercased()) ||
                    product.category!.lowercased().contains(searchTerm.lowercased())
                }
            }

            return filteredArray
}
}

#Preview {
    TruckStockProducts()
}
