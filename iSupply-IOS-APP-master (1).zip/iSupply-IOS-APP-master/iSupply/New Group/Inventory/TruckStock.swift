//
//  TruckStock.swift
//  iSupply
//
//  Created by hassan ghouri on 27/02/2024.
//

import SwiftUI

struct TruckStock: View {
    @State private var searchTerm = ""
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @StateObject private var viewModel = UserViewModel()
    var body: some View {
        NavigationStack{
            if (viewModel.isLoading){ LoadingView()}
            List(filteredUsers, id: \.email) { user in
                NavigationLink(destination: NewTruckStockProducts(salesPersonEmail: user.email)) {
                    UserCell(user: user)
                }
            }
            
        }.navigationTitle("Assign Truck Stock")
            .searchable(text: $searchTerm, prompt: "Search")
            .onAppear {
                viewModel.getUsers(email: userEmail, route: "getUsersByEmail")
            }
    }    
    var filteredUsers: [UserModel] {
        
        var filteredArray = viewModel.users
        
        filteredArray = filteredArray.filter { $0.role == "Sales Person" }
        
        
        if !searchTerm.isEmpty {
            filteredArray = filteredArray.filter { user in
                user.email!.lowercased().contains(searchTerm.lowercased()) ||
                user.name!.lowercased().contains(searchTerm.lowercased())
            }
        }
        
        return filteredArray
    }
}

#Preview {
    TruckStock()
}
