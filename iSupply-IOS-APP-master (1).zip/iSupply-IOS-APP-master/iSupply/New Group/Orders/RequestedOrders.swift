//
//  RequestedOrders.swift
//  iSupply
//
//  Created by hassan ghouri on 28/04/2024.
//
import SwiftUI

struct RequestedOrders: View {
    @State private var searchTerm = ""
    @StateObject var viewModel = OrderViewModel()
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    var customerEmail:String?
    var requested: Bool = false
    var confirmOrder: Bool = false
    var purchaseOrder:Bool = false
    var status:String?
    var body: some View {
        VStack {
            SearchBar(text: $searchTerm) // Custom SearchBar view
            if viewModel.isLoading {
                LoadingView()
            } else {
                if (userRole == "Customer"){
                    DynamicTableView(headers: ["Date", "Business", requested ? "RequestId" : "Invoice Number"], rows: filteredRows, route:"payment")
                }else{
                    DynamicTableView(headers: ["Date", "Business", requested ? "RequestId" : "Invoice Number"], rows: filteredRows, route: (confirmOrder || purchaseOrder) ? "review":"products")
                }
                
            }
        }
        .navigationTitle("Orders")
        .onAppear {
            if let customerEmail = customerEmail {
                viewModel.fetchOrdersByEmailAndStatus(email: customerEmail,role:userRole, status: "Requested", route: "fetchOrders")
            }else {
                if(requested){
                    viewModel.fetchOrdersByEmailAndStatus(email: userEmail,role:userRole, status: "Requested", route: "fetchOrders")
                }else if(confirmOrder){
                    viewModel.fetchOrdersByEmailAndStatus(email: userEmail,role:userRole, status: status ?? "invoiceGenerated", route: "fetchOrders")
                }else if(purchaseOrder) {
                    viewModel.fetchOrdersByEmailAndStatus(email: userEmail,role:userRole, status: status ?? "PurchaseOrder", route: "fetchOrders")
                }else {
                    viewModel.fetchOrdersByEmailAndStatus(email: userEmail,role:userRole, status: status ?? "review", route: "fetchOrders")
                }
                
            }
        }
    }

    private var filteredRows: [[String]] {
        let filteredOrders = searchTerm.isEmpty ? viewModel.orders : viewModel.orders.filter { $0.businessName?.lowercased().contains(searchTerm.lowercased()) ?? false }
        return filteredOrders.map { order in
            formatRow(for: order)
        }
    }

    private func formatRow(for order: OrderModel) -> [String] {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = order.createdAt.map { dateFormatter.string(from: $0) } ?? "N/A"
        let businessName = order.businessName ?? "No Business"
        let orderId = order.id ?? ""
        if (requested){
            let requestId = order.requestId ?? "NA"
            return [dateString, businessName, requestId,orderId]
        }else {
            let invoiceNumber = order.invoiceNumber ?? "NA"
            return [dateString, businessName, invoiceNumber, orderId]
        }
}
}

// Custom Search Bar Component
struct SearchBar: View {
    @Binding var text: String
    var body: some View {
        TextField("Search for Orders", text: $text)
            .padding(7)
            .background(Color(.systemGray6))
            .cornerRadius(8)
            .padding(.horizontal)
    }
}

struct RequestedOrders_Previews: PreviewProvider {
    static var previews: some View {
        RequestedOrders()
    }
}
