//
//  OrderDetails.swift
//  iSupply
//
//  Created by hassan ghouri on 21/03/2024.
//

import SwiftUI

struct OrderDetails: View {
    let ScreenName: String
    @State private var searchTerm = ""
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    var body: some View {
        NavigationStack{
            VStack{
                
            }
        }.navigationTitle(ScreenName)
            .searchable(text: $searchTerm, prompt: "Search for Orders")
    }
}

#Preview {
    OrderDetails(ScreenName:"Requested Orders")
}
