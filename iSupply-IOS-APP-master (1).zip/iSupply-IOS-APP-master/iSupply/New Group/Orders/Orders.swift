//
//  Orders.swift
//  iSupply
//
//  Created by hassan ghouri on 07/02/2024.
//

import SwiftUI

struct Orders: View {
    @StateObject private var viewModel = UserViewModel()
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    var body: some View {
        NavigationStack{
            VStack{
                HStack(alignment: .center, spacing: 20) {
                    NavigationLink {
                        TakeOrder()
                    } label: {
                        MainPageCard(title: "Take Order", imageName: "box.truck.fill", backColor: Color(red: 0.46, green: 0.41, blue: 0.87).opacity(0.25))
                    }
                    NavigationLink{
                        if (userRole == "Sales Person"){
                            UserScreen(userEmail: userEmail, userRole: userRole,requested:true)
                        }else {
                            RequestedOrders(requested:true)
                        }
                    } label: {
                        MainPageCard(title: "Requested Orders", imageName: "basket.fill", backColor: Color(red: 0.69, green: 0.87, blue: 0.32).opacity(0.25))
                    }
                }
                HStack(alignment: .center, spacing: 20) {
                    NavigationLink {
                        OrderReport()
                    } label: {
                        MainPageCard(title: "Previous Orders", imageName: "rosette", backColor: Color(red: 0.97, green: 0.55, blue: 0.16).opacity(0.25))
                    }
                    NavigationLink{
                        RequestedOrders(requested:false, status: "review")
                    //CheckoutView()
                    } label: {
                        MainPageCard(title: "Pending Orders", imageName: "star.square.fill", backColor: Color(red: 0.68, green: 0.45, blue: 0.38).opacity(0.25))
                    }
                }
                HStack(alignment: .center, spacing: 20) {
                    NavigationLink {
                        RequestedOrders(requested:false, confirmOrder:true, status:"invoiceGenerated")
                    } label: {
                        MainPageCard(title: "Confirm Orders", imageName: "cart.fill", backColor: Color(red: 1, green: 0.76, blue: 0.74).opacity(0.25))
                    }
                    NavigationLink {
                        RequestedOrders(requested:false, purchaseOrder: true)
                    } label: {
                        MainPageCard(title: "Purchase Orders", imageName: "newspaper.fill", backColor: Color(red: 0.77, green: 0.77, blue: 0.77).opacity(0.25))
                    }
                    
                }
                
            }
        }.navigationTitle("Orders")
            .onAppear{
                if (userRole == "Sales Person"){
                    viewModel.getUsers(email: userEmail, route: "getCustomerByEmail")
                }
            }
    }
}

#Preview {
    Orders()
}
