import Foundation
import Combine

final class OrderViewModel: ObservableObject {
    @Published var order: OrderModel
    @Published var isLoading = false
    @Published var alertItem: AlertItem?
    @Published var paymentMethod: String
    @Published var paymentDetail: String
    @Published var adjustmentType: String
    @Published var discount: String
    @Published var credit: String
    @Published var notes: String
    @Published var eSign: String
    @Published var orders: [OrderModel] = []
    @Published var isButtonEnabled = false
    private var cancellables = Set<AnyCancellable>()
    private var apiService: OrdersAPIProtocol

    init(apiService: OrdersAPIProtocol = OrdersAPI.sharedInstance, order: OrderModel = OrderModel()) {
        self.apiService = apiService
        self.order = order
        self.paymentMethod = order.paymentMethod ?? "Cash"
        self.paymentDetail = order.paymentDetail ?? ""
        self.adjustmentType = order.adjustmentType ?? "-$"
        self.discount = "\(order.discount ?? 0)"
        self.credit = "\(order.credit ?? 0)"
        self.notes = order.notes ?? ""
        self.eSign = order.eSign ?? ""
    }
    

//        private func observeCreditChanges() {
//            $credit
//                .dropFirst() // Ignore the initial value
//                .sink { [weak self] newCredit in
//                    self?.fetchPaymentIntent(with: newCredit)
//                }
//                .store(in: &cancellables)
//        }
      // Environment variables and functions for handling Stripe payment sheet
    func fetchPaymentIntent(completion: @escaping (Result<String, Error>) -> Void) {
            var amount = 1
            print("Credit: \(credit)")
            if let creditInt = Int(credit), creditInt > 0 {
                amount = creditInt
            } else {
                amount = 1
            }

            guard let url = URL(string: Constants.apiBaseUrl + "create-payment-intent") else {
                completion(.failure(NetworkError.invalidURL))
                return
            }

            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let shoppingCartContent: [String: Any] = ["amount": amount * 100]
            request.httpBody = try? JSONSerialization.data(withJSONObject: shoppingCartContent)

            URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    DispatchQueue.main.async {
                        completion(.failure(error))
                    }
                    return
                }

                guard let data = data,
                      let response = response as? HTTPURLResponse,
                      response.statusCode == 200,
                      let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                      let clientSecret = json["clientSecret"] as? String else {
                    DispatchQueue.main.async {
                        completion(.failure(NetworkError.invalidData))
                    }
                    return
                }

                DispatchQueue.main.async {
                    completion(.success(clientSecret))
                }
            }.resume()
    }

    func getOrder(orderId: String) {
        isLoading = true
        apiService.getOrder(orderId: orderId) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let order):
                    self.order = order
                    self.paymentDetail = order.paymentDetail ?? ""
                    self.paymentMethod = order.paymentMethod ?? ""
                    self.adjustmentType = order.adjustmentType ?? ""
                    self.discount = "\(order.discount ?? 0)"
                    self.credit = "\(order.credit ?? 0)"
                    self.notes = order.notes ?? ""
                    self.eSign = order.eSign ?? ""
                    self.isButtonEnabled = true
                case .failure(_):
                    self.alertItem = AlertItem(title: "Cannot get Order", message: "Check your Internet Connection")
                }
            }
        }
    }
    func fetchOrdersByEmailAndStatus(email: String,role:String, status: String, route:String) {
        isLoading = true
        apiService.fetchOrders(email: email,role:role, status: status,route: route) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let fetchedOrders):
                    self.orders = fetchedOrders
                case .failure(_):
                    self.alertItem = AlertItem(title: "Error", message: "Unable to fetch orders. Please check your network and try again.")
                }
            }
        }
    }
}
