//
//  SelectPayment.swift
//  iSupply
//
//  Created by hassan ghouri on 28/02/2024.
//

import SwiftUI
import StripePaymentSheet

struct SelectPayment: View {
    @StateObject private var viewModel = OrderViewModel()
    @State private var isLoading = false
    @State private var navigationLinkActive = false
    @State private var navigationToMain = false
    @State private var check = false
    @State private var showCreditField = true
    @State private var showPaymentDetails = true
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @State private var paymentIntentClientSecret: String?
    @State private var isButtonEnabled = false
    @State private var alertItem: AlertType?
    @State private var totalColorGreen = false
    let orderId: String
    let apiManager = OrdersAPI.sharedInstance
    let request:Bool
    init(orderId:String, request:Bool){
        self.orderId = orderId
        self.request = request
    }
    
    var body: some View {
        NavigationStack{
            
            ZStack{
                if(viewModel.isLoading || isLoading){
                    LoadingView()
                }
                VStack{
                    Text("Select Payment Method")
                        .font(
                            Font.custom("Manrope", size: 20)
                                .weight(.semibold)
                        )
                        .foregroundColor(Color(red: 0.12, green: 0.12, blue: 0.12))
                        .frame(width: 253, alignment: .topLeading)
                    Picker(selection: $viewModel.paymentMethod, label: Text("Payment Method")) {
                        Text("Cash").tag("Cash")
                        Text("CC").tag("CC")
                        Text("Check").tag("Check")
                        Text("PayLater").tag("PayLater")
                        Text("Online").tag("Online")
                    }.pickerStyle(SegmentedPickerStyle())
                        .padding()
                    if(showPaymentDetails)
                    {
                        InputView(text: $viewModel.paymentDetail, title: setPaymentTitle(), placeholder: "Payment Details").padding()
                    }
                    if(showCreditField){
                        InputView(text: $viewModel.credit, title: "Credit Amount", placeholder: "Enter Credit Amount").padding()
                    }
                    HStack{
                        Spacer()
                        Text("Total:  $\(viewModel.order.totalAmount ?? 0.0)")
                            .font(
                                Font.custom("Manrope", size: 12)
                                    .weight(.bold)
                            )
                            .foregroundColor(totalColorGreen ? Color(red:0.2, green:0.8, blue:0.1):Color(red: 0.15, green: 0.2, blue: 0.22))
                            .frame(width: 100, height: 14, alignment: .leading)
                            .padding()
                    }
                    HStack{
                        Text("Adjustment")
                            .bold()
                            .padding(.horizontal)
                        Picker(selection: $viewModel.adjustmentType, label: Text("Payment Adjustment")) {
                            Text("-$").tag("-$")
                            Text("%").tag("-%")
                        }.pickerStyle(SegmentedPickerStyle())
                    }
                    InputView(text: $viewModel.discount, title: "Discount", placeholder: "Enter Discount").padding()
                    InputView(text: $viewModel.notes, title: "Notes", placeholder: "Any Details can be here").padding()
                    HStack{
                        Spacer()
                        Text("Final Payment:  $\(calculateFinalPayment())")
                            .font(
                                Font.custom("Manrope", size: 12)
                                    .weight(.bold)
                            )
                            .foregroundColor(Color(red: 0.15, green: 0.2, blue: 0.22))
                            .frame(width: 141, height: 14, alignment: .leading)
                            .padding()
                    }
                    if(request){
                        Button {
                            updateOrder(status: "Requested") { success in
                                if success {
                                    // If the updateOrder was successful, navigate to the next screen
                                    alertItem = .success(message: "Order Requested From Vendor.")
                                    navigationToMain = true
                                } else {
                                    // Handle error case if needed
                                    alertItem = .error(message: "Check Internet Connection.")
                                }
                            }
                        } label: {
                            ZStack{
                                Rectangle()
                                    .foregroundColor(.clear)
                                    .frame(width: 200, height: 31)
                                    .background(Color(red: 0.09, green: 0.61, blue: 0.38))
                                    .cornerRadius(20)
                                Text("Create/Update Request")
                                    .font(Font.custom("Manrope", size: 14).weight(.semibold))
                                    .foregroundColor(.white)
                                    .frame(width: 200, height: 16, alignment: .center)
                            }.padding(.horizontal)
                        }
                    } else {
                        HStack{
                            Spacer()
                            Button {
                                updateOrder(status: "draft") { success in
                                    if success {
                                        alertItem = .success(message: "Order Saved to Draft")
                                    } else {
                                        // Handle error case if needed
                                        alertItem = .error(message: "Check Internet Connection.")
                                    }
                                }
                            } label: {
                                ZStack {
                                    Rectangle()
                                        .foregroundColor(.clear)
                                        .frame(width: 140, height: 31)
                                        .background(Color(red: 0.95, green: 0.77, blue: 0.12))
                                        .cornerRadius(20)
                                        .blur(radius: 100)
                                    Text("Save to Draft")
                                        .font(
                                            Font.custom("Manrope", size: 14)
                                                .weight(.semibold)
                                        )
                                        .multilineTextAlignment(.center)
                                        .foregroundColor(Color(red: 0.01, green: 0.01, blue: 0.01))
                                        .frame(width: 99.65841, height: 16, alignment: .top)
                                }.padding(.horizontal)
                            }
                            
                            Button {
                                updateOrder(status: "review") { success in
                                    if success {
                                        // If the updateOrder was successful, navigate to the next screen
                                        navigationLinkActive = true
                                    } else {
                                        // Handle error case if needed
                                        alertItem = .error(message: "Check Internet Connection.")
                                    }
                                }
                            } label: {
                                ZStack{
                                    Rectangle()
                                        .foregroundColor(.clear)
                                        .frame(width: 70, height: 31)
                                        .background(Color(red: 0.09, green: 0.61, blue: 0.38))
                                        .cornerRadius(20)
                                    Text("Next")
                                        .font(Font.custom("Manrope", size: 14).weight(.semibold))
                                        .foregroundColor(.white)
                                        .frame(width: 70, height: 16, alignment: .center)
                                }.padding(.horizontal)
                            }
                        }
                    }
                    Spacer()
                    Button("Pay Online Now") {
                        viewModel.fetchPaymentIntent { result in
                            switch result {
                            case .success(let clientSecret):
                                // Use clientSecret if needed
                                print(clientSecret)
                                pay(secret:clientSecret)
                            case .failure(let error):
                                // Handle the error
                                print("Error fetching payment intent: \(error)")
                            }
                        }
                    }.padding()
                        .background(viewModel.isButtonEnabled ? Color.blue : Color.gray)
                        .foregroundColor(.white)
                        .cornerRadius(5)
                        .disabled(!viewModel.isButtonEnabled)

                }
            }.navigationDestination(isPresented: $navigationLinkActive) {
                Review(orderId: orderId, check:check)
            }
            .navigationDestination(isPresented: $navigationToMain) {
                MainView()
            }
        }.alert(item: $alertItem) { alertType in
            switch alertType {
            case .error(let message):
                return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
            case .success(let message):
                return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                }, secondaryButton: .cancel())
            }
        }
        
        .navigationTitle("Select Payment")
            .onAppear{
                viewModel.getOrder(orderId: orderId)
                }
        
    }
    // Set Payment Title
    func setPaymentTitle() -> String {
        if(viewModel.paymentMethod == "Cash"){
            DispatchQueue.main.async {
                showCreditField = false
                showPaymentDetails = true
                totalColorGreen = true
                check = false
            }
            return "Amount :"
        }else if (viewModel.paymentMethod == "CC"){
            DispatchQueue.main.async {
                showCreditField = true
                showPaymentDetails = true
                check = false
                totalColorGreen = true
            }
            return "CC Details"
        }else if (viewModel.paymentMethod == "Check") {
            DispatchQueue.main.async {
                showCreditField = true
                showPaymentDetails = true
                check = true
                totalColorGreen = true
            }
            
            return "Check #"
        }else if (viewModel.paymentMethod == "Online"){
            DispatchQueue.main.async {
                showCreditField = true
                showPaymentDetails = false
                check = false
                totalColorGreen = true
            }
            return "Online"
        }else{
            DispatchQueue.main.async {
                showCreditField = true
                showPaymentDetails = true
                check = false
                totalColorGreen = true
            }
            return "Pay Later Date"
        }
    }
    func getCredit()->String{
        if(showCreditField){
            return viewModel.credit
        }else{
            return viewModel.paymentDetail
        }
    }
    // Calculate Final Payment
    func calculateFinalPayment() -> String {
        if let totalAmount = viewModel.order.totalAmount{
            guard let discount = Double(viewModel.discount) else {
                return "\(totalAmount)"
            }
            let adjustment = viewModel.adjustmentType
            var finalAmount = 0.0
            if(adjustment == "-$"){
                finalAmount = totalAmount - discount
            }else{
                finalAmount = totalAmount - (totalAmount*discount)/100
            }
            return "\(finalAmount)"
        }else{
            return "0"
        }
        
    }
    func updateOrder(status:String, completion: @escaping (Bool) -> Void) {
        Task {
            isLoading = true
            let order = OrderModel(id: orderId, userEmail: userEmail, userRole: userRole, totalAmount: viewModel.order.totalAmount,paymentMethod: viewModel.paymentMethod, paymentDetail: viewModel.paymentDetail, adjustmentType: viewModel.adjustmentType, discount: Double(viewModel.discount),credit: Double(getCredit()),notes: viewModel.notes,paymentAmount: Double(calculateFinalPayment()), status: status)
            apiManager.createOrderApi(order: order, image: nil, route: "updateOrder") { result in
                switch result {
                case let .success((success, _)):
                    if success {
                        isLoading = false
                        completion(success)
                    } else {
                        isLoading = false
                        alertItem = .error(message: "Check Internet Connection.")
                        completion(false)
                    }
                case let .failure(error):
                    isLoading = false
                    alertItem = .error(message: error.localizedDescription)
                }
            }
        }
    }

    func pay(secret: String?) {
            guard let clientSecret = secret else {
                print("Client secret is nil")
                return
            }

            var configuration = PaymentSheet.Configuration()
            configuration.merchantDisplayName = "Example, Inc."
            configuration.applePay = .init(merchantId: "your_merchant_id_here", merchantCountryCode: "US")

            let paymentSheet = PaymentSheet(paymentIntentClientSecret: clientSecret, configuration: configuration)

            if let viewController = getRootViewController() {
                paymentSheet.present(from: viewController) { paymentResult in
                    switch paymentResult {
                    case .completed:
                        updateOrder(status: "review") { success in
                            if success {
                                // If the updateOrder was successful, navigate to the next screen
                                navigationLinkActive = true
                            } else {
                                // Handle error case if needed
                                alertItem = .error(message: "Check Internet Connection.")
                            }
                        }
                        print("Payment successful")
                    case .failed(let error):
                        alertItem = .error(message: "Check Internet Connection. \(error.localizedDescription)")
                        print("Payment failed: \(error.localizedDescription)")
                    case .canceled:
                        print("Payment canceled")
                    }
                }
            } else {
                print("Failed to get root view controller")
            }
        }

        func getRootViewController() -> UIViewController? {
            guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene else {
                return nil
            }
            return windowScene.windows.first?.rootViewController
        }
}

#Preview {
    SelectPayment(orderId: "663d46b60758835e817b60c8", request:false)
}
