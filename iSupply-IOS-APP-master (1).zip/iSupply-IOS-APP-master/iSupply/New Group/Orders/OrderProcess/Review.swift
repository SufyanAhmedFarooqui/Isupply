//
//  Review.swift
//  iSupply
//
//  Created by hassan ghouri on 29/02/2024.
//

import SwiftUI

struct Review: View {
    @State private var path = Path()
    @State private var isSigning = false
    @State private var isLoading = false
    @State private var isPdfVisible = false
    @State private var invoiceNumber = ""
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @State private var alertItem: ConfirmAlertType?
    @StateObject private var viewModel = OrderViewModel()
    @StateObject private var userViewModel = UserViewModel()
    @State private var showSignatureView = false
    @State private var signatureImage: UIImage?
    @State private var signaturePoints: [CGPoint] = []
    let orderId: String
    let apiManager = OrdersAPI.sharedInstance
    let check:Bool
    init(orderId:String, check:Bool){
        self.orderId = orderId
        self.check = check
    }
    var body: some View {
        NavigationStack{
            if isLoading {LoadingView()}
            VStack(alignment: .leading, spacing: 10){
                Spacer()
                reviewFields(label: "Name : ", value: viewModel.order.customerName ?? "")
                reviewFields(label: "Email : ", value: viewModel.order.customerEmail ?? "")
                reviewFields(label: "Payment Method : ", value: viewModel.order.paymentMethod ?? "")
                reviewFields(label: check ? "Check # : ":"Payment Details : ", value: viewModel.order.paymentDetail ?? "")
                reviewFields(label: "Total : ", value: "$\(viewModel.order.totalAmount ?? 0.0)")
                reviewFields(label: "Discount : ", value: "$-\(viewModel.order.discount ?? 0)")
                reviewFields(label: "Credit : ", value: "$-\(viewModel.order.credit ?? 0)")
                reviewFields(label: "Grand Total : ", value: "$\(viewModel.order.paymentAmount ?? 0)")
                if let image = signatureImage {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 200, height: 200)
                        .padding()
                }
                
                if (viewModel.eSign != ""){
                    AsyncImage(url: URL(string: Constants.imageBaseUrl+viewModel.eSign)) { phase in
                        switch phase {
                        case .empty:
                            Image("avatar")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 100, height: 100)
                                .clipShape(Circle())
                        case .success(let image):
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 100, height: 100)
                                .clipShape(Circle())
                        default:
                            Image("avatar")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 100, height: 100)
                                .clipShape(Circle())
                        }
                    }
                }
                if(userRole != "Customer"){
                HStack{
                    Spacer()
                    NavigationLink {
                        ESignView(signatureImage: .constant(.init()), signaturePDF: .constant(.init()), orderId: orderId)
                    } label: {
                        ZStack{
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 131, height: 31)
                                .background(Color(red: 0.09, green: 0.61, blue: 0.38))
                                .cornerRadius(20)
                            Text("E-Sign POD")
                                .font(
                                    Font.custom("Manrope", size: 14)
                                        .weight(.semibold)
                                )
                                .foregroundColor(.white)
                                .frame(width: 98.25, height: 16, alignment: .center)
                        }
                    }
                    Button {
                        alertItem = .success(message: "Are you sure you want to Generate invoice and confirm Order?") {
                            generateInvoiceNumber(orderId: orderId, businessName: viewModel.order.businessName ?? "ABC")
                            isPdfVisible = true
                        }
                        
                    } label: {
                        ZStack{
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 148, height: 31)
                                .background(Color(red: 0.09, green: 0.61, blue: 0.38))
                                .cornerRadius(20)
                            Text("Generate Invoice")
                                .font(
                                    Font.custom("Manrope", size: 14)
                                        .weight(.semibold)
                                )
                                .foregroundColor(.white)
                                .frame(width: 132, height: 16, alignment: .center)
                        }
                    }
                    Spacer()
                    
                }.padding()
            }
                HStack{
                    Spacer()
                    Button {
                        isPdfVisible = true
                    } label: {
                        ZStack{
                            Rectangle()
                              .foregroundColor(.clear)
                              .frame(width: 131, height: 31)
                              .background(Color(red: 0.95, green: 0.77, blue: 0.12))
                              .cornerRadius(20)
                            Text("Print Draft")
                              .font(
                                Font.custom("Manrope", size: 14)
                                  .weight(.semibold)	
                              )
                              .foregroundColor(Color(red: 0.01, green: 0.01, blue: 0.01))
                              .frame(width: 85, height: 16, alignment: .center)
                        }
                    }
                    Spacer()
                }
                Spacer()
            }.padding()
        }.navigationTitle("Review")
            .alert(item: $alertItem) { alertType in
                switch alertType {
                case .error(let message):
                    return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
                case .success(let message, let action):
                    return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("YES"), action: action), secondaryButton: .cancel())
                }
            }
            .onAppear{
                viewModel.getOrder(orderId: orderId)
            }
            .navigationDestination(isPresented: $isPdfVisible) {
                Invoice(order:viewModel.order, invoiceNumber: invoiceNumber)
            }
    }
    func generateInvoiceNumber(orderId:String,businessName:String){
        Task {
            isLoading = true
            apiManager.generateInvoiceNumber(orderId: orderId, businessName: businessName) { result in
                switch result {
                case let .success(invoiceNum):
                        DispatchQueue.main.async{
                            isLoading = false
                            invoiceNumber = invoiceNum
                            isPdfVisible = true // Trigger navigation here
                        }
                case let .failure(error):
                    DispatchQueue.main.async{
                        isLoading = false
                        alertItem = .error(message: error.localizedDescription)
                    }
                    
                }
            }
        }
    }
}

#Preview {
    Review(orderId: "663d46b60758835e817b60c8", check: false)
}

struct reviewFields: View {
    let label: String
    let value: String
    var body: some View {
        HStack{
            Text(label)
                .font(
                    Font.custom("Manrope", size: 18)
                )
                .bold()
            Text(value)
                .font(
                    Font.custom("Manrope", size: 16)
                )
            Spacer()
        }
    }
}
