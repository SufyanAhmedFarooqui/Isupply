//
//  TakeOrder.swift
//  iSupply
//
//  Created by hassan ghouri on 27/02/2024.
//

import SwiftUI

struct TakeOrder: View {
    @State private var searchTerm = ""
    @StateObject private var viewModel = UserViewModel()
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @State private var isLoading = false
    @State private var alertItem: ConfirmAlertType?
    @State private var navigationLinkActive = false
    @State private var createdOrderId = ""
    var orderStatus: String?
    var products:[OrderProduct] = []
    let apiManager = OrdersAPI.sharedInstance
    var body: some View {
        NavigationStack{
            ZStack {
                if isLoading {LoadingView()}
                VStack(alignment: .leading){
                   
                    Text("Select Customer")
                      .font(
                        Font.custom("Manrope", size: 18)
                          .weight(.semibold)
                      )
                      .kerning(0.054)
                      .foregroundColor(Color(red: 0.53, green: 0.53, blue: 0.53))
                    List(filteredUsers, id: \.email) { user in
                        UserCell(user: user)
                        .onTapGesture {
                            alertItem = .success(message: "Are you sure you want to create an order for \(user.userName!)?") {
                                createOrder(customerName: user.userName ?? "", customerEmail: user.email!, businessName: user.businessName ?? "", customerAddress: user.address ?? "", customerPhone: user.telephone ?? "")
                                        navigationLinkActive = true
                                }
                            }
                    }
                }.padding(.horizontal)
                
            }
            Spacer()
        }.navigationDestination(isPresented: $navigationLinkActive) {
            ProductScreen(request:false, email:userEmail,orderId:createdOrderId)
        }
        .navigationTitle("Take Order")
        .searchable(text: $searchTerm, prompt: "Search")
        .alert(item: $alertItem) { alertType in
            switch alertType {
            case .error(let message):
                return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
            case .success(let message, let action):
                return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("YES"), action: action), secondaryButton: .cancel())
            }
        }
        .onAppear{
            if let status = orderStatus {
                if status == "Requested" {
                    navigationLinkActive = true
                }
            }
            viewModel.getUsers(email: userEmail,route:"getUsersByEmail")
        }
        if (viewModel.isLoading){ LoadingView()}
    }
    
    var filteredUsers: [UserModel] {
        
        var filteredArray = viewModel.users
        
        filteredArray = filteredArray.filter { $0.role == "Customer" }
        
        if !searchTerm.isEmpty {
            filteredArray = filteredArray.filter { user in
                user.email!.lowercased().contains(searchTerm.lowercased()) ||
                user.name!.lowercased().contains(searchTerm.lowercased())
            }
        }
        
        return filteredArray
    }
    
    func createOrder(customerName: String, customerEmail: String, businessName: String, customerAddress:String, customerPhone:String) {
        Task {
            isLoading = true
            let order = OrderModel(userEmail: userEmail, userRole: userRole, customerName: customerName, customerEmail: customerEmail, businessName:businessName, customerAddress: customerAddress, customerPhone: customerPhone, products: products, status: "created")
            apiManager.createOrderApi(order: order, image: nil, route: "createOrder") { result in
                switch result {
                case let .success((success, id)):
                    if success {
                        DispatchQueue.main.async{
                            isLoading = false
                            createdOrderId = id!
                            navigationLinkActive = true // Trigger navigation here
                        }
                    } else {
                        DispatchQueue.main.async{
                            isLoading = false
                            alertItem = .error(message: "Check Internet Connection.")
                        }
                    }
                case let .failure(error):
                    DispatchQueue.main.async{
                        isLoading = false
                        alertItem = .error(message: error.localizedDescription)
                    }
                    
                }
            }
        }
    }

        
}

#Preview {
    TakeOrder()
}
