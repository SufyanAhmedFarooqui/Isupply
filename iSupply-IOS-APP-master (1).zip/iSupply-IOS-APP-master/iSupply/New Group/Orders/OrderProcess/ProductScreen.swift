//
//  ProductScreen.swift
//  iSupply
//
//  Created by Hassan Ghori on 18/08/2025.
//

import SwiftUI

struct ProductScreen: View {
    @State private var searchText: String = ""
    @State private var isShowingScanner = false
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    let request:Bool
    let email:String?
    let orderId: String?
    @StateObject private var viewModel = ProductViewModel()
    @StateObject private var orderViewModel = OrderProductViewModel()
    // Mock Order Data (replace with API data)
    @State private var orderData: [OrderItem] = []
    @State private var currentPage = 1
    private let itemsPerPage = 10

    
    var body: some View {

        NavigationView {
            if viewModel.isLoading && viewModel.products.isEmpty {
                LoadingView()
            } else {
                VStack(alignment: .leading, spacing: 16) {
                    
                    // Title Row (Select Products + Scan Button)
                    HStack {
                        Text("Select Products")
                            .font(.headline)
                        
                        Spacer()
                        
                        Button(action: {
                            isShowingScanner = true
                        }) {
                            Text("Scan")
                                .foregroundColor(.blue)
                        }
                        .sheet(isPresented: $isShowingScanner) {
                            BarcodeScannerView()
                        }
                    }
                    .padding(.horizontal)
                    
                    // Search Bar
                    TextField("Search Here...", text: $searchText)
                        .padding(10)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                        .padding(.horizontal)
                    
                    // Product List with Pagination
                    ScrollView {
                        LazyVStack(spacing: 12) {
                            ForEach(paginatedProducts, id: \.id) { product in
                                // Check if product exists in orderViewModel.products
                                let existsInOrder = orderViewModel.products.contains { $0.id == product.id }
                                NavigationLink(destination: ViewAndAddProducts(product: product,orderId:orderId!, request:request)) {
                                    ProductListCard(product: product,backgroundColor: existsInOrder ? Color.green.opacity(0.3) : Color(.systemGray6))
                                }
                                
                            }
                        }
                    }
                    
                    // Pagination Controls
                    HStack {
                        Button(action: { if currentPage > 1 { currentPage -= 1 } }) {
                            Image(systemName: "chevron.left")
                        }
                        .disabled(currentPage == 1)

                        Text("Page \(currentPage) of \(totalPages)")

                        Button(action: { if currentPage < totalPages { currentPage += 1 } }) {
                            Image(systemName: "chevron.right")
                        }
                        .disabled(currentPage == totalPages)
                    }
                    .padding(.vertical, 4)
                    .frame(maxWidth: .infinity)
                    
                    
                    // Order Table (Product, Quantity, Price, Total)
                    ProductsTableView(data:orderViewModel.products, orderId: orderId ?? "")
                    
                    // Current Total
                    Text("Current Total: $\(orderTotal(), specifier: "%.2f")")
                        .padding(.horizontal)
                        .padding(.top, 8)
                    
                    Spacer()
                }
                .navigationBarTitle("Take Order", displayMode: .inline)
                .navigationBarItems(trailing: Button("Next") {
                    // Handle Next action
                })
                .onAppear {
                    // Load order API data here
                    Task{
                        orderViewModel.getProducts(orderId: orderId ?? "")
                        if(request){
                            viewModel.getProductsByEmail(email: email ?? "", role: "Vendor")
                        }else{
                            viewModel.getProductsByEmail(email: userEmail, role: userRole)
                    }
                }
                }
            }
        }
    }
    
    
    // MARK: - Functions
    
    var filteredProducts: [ProductModel] {
        
        var filteredArray = viewModel.products

            if !searchText.isEmpty {
                filteredArray = filteredArray.filter { product in
                    product.name!.lowercased().contains(searchText.lowercased()) ||
                    product.category!.lowercased().contains(searchText.lowercased())
                }
            }

            return filteredArray
}
    var paginatedProducts: [ProductModel] {
        let filteredArray = filteredProducts
        let startIndex = (currentPage - 1) * itemsPerPage
        let endIndex = min(startIndex + itemsPerPage, filteredArray.count)
        
        if startIndex < filteredArray.count {
            return Array(filteredArray[startIndex..<endIndex])
        } else {
            return []
        }
    }

    var totalPages: Int {
        let count = filteredProducts.count
        return count == 0 ? 1 : Int(ceil(Double(count) / Double(itemsPerPage)))
    }

    
    func orderTotal() -> Double {
        orderData.reduce(0) { $0 + $1.total }
    }
    
    func fetchOrderData() {
        // Replace this with API call
            
    }
}

// MARK: - Models

struct OrderItem {
    let id: Int
    let productName: String
    let quantity: Int
    let price: Double
    let total: Double
}


#Preview {
    ProductScreen(request:false, email:"",orderId:"65e4fd204d6e36d145cc4564")
}
