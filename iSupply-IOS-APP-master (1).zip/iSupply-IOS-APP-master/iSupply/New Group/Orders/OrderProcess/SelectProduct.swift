//
//  SelectProduct.swift
//  iSupply
//
//  Created by hassan ghouri on 28/02/2024.
//

import SwiftUI

struct SelectProduct: View {
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    let request:Bool
    let email:String?
    let orderId: String?
    @State private var searchTerm = ""
    @StateObject private var viewModel = ProductViewModel()
    
    init(orderId:String?,request:Bool ,email:String?){
        self.orderId = orderId
        self.request = request
        self.email = email
    }
    
    var columns = [GridItem(.adaptive(minimum: 160),spacing:20)]
    var body: some View {
        NavigationStack{
            ScrollView{
                LazyVGrid(columns: columns,spacing:20, content: {
                    ForEach(filteredProducts, id: \.id) { product in
                        NavigationLink(destination: ViewAndAddProducts(product: product,orderId:orderId!, request:request)) {
                            ProductCard(product: product)
                        }
                    }
                    .padding()
                })
                
            }.padding(.horizontal)
                .navigationTitle("Select Products")
                .searchable(text: $searchTerm, prompt: "Search")
            Spacer()
        }
        .onAppear{
            if(request){
                viewModel.getProductsByEmail(email: email ?? "", role: "Vendor")
            }else{
                viewModel.getProductsByEmail(email: userEmail, role: userRole)
            }
            
        }
        if (viewModel.isLoading){ LoadingView()}
    }
    var filteredProducts: [ProductModel] {
        
        var filteredArray = viewModel.products

            if !searchTerm.isEmpty {
                filteredArray = filteredArray.filter { product in
                    product.name!.lowercased().contains(searchTerm.lowercased()) ||
                    product.category!.lowercased().contains(searchTerm.lowercased())
                }
            }

            return filteredArray
}
}

#Preview {
    SelectProduct(orderId:"65e4fd204d6e36d145cc4564", request:false, email:"")
}
