import SwiftUI
import PDFKit
import UIKit

struct Invoice: View {
    let apiManager = UsersAPI.sharedInstance
    @AppStorage("userEmail") var userEmail = ""
    let order:OrderModel
    var invoiceNumber:String?
    var body: some View {
        // Design your invoice view using SwiftUI
        VStack{
            PDFKitView(pdfDoc: PDFDocument(data:generatePDF())!)
            Button {
                saveAndSharePDF()
            } label: {
                Text("Save and Share PDF")
            }
            Divider()
        }
    }
    func currentDateFormatted() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        return formatter.string(from: Date())
    }
    
    @MainActor
    private func generatePDF() -> Data {
        let pdfRenderer = UIGraphicsPDFRenderer(bounds: CGRect(x:0, y:0, width:595, height:842))
        
        let data = pdfRenderer.pdfData { context in
            context.beginPage()
            let vendorName = order.vendorName ?? "NA"
            let vendorAddressComponents = (order.vendorAddress ?? "No Address").components(separatedBy: ", ")
            let vendorAddressLine1 = vendorAddressComponents.first ?? "No Address"
            let vendorAddressLine2 = vendorAddressComponents.dropFirst().joined(separator: ", ")
            let vendorPhone = order.vendorPhone ?? "NA"
            let adminPhone = "914-327-9500"
            let businessName = order.businessName ?? "Test Business"
            let customerName = order.customerName ?? "Test name"
            let customerAddress = order.customerAddress ?? "No address"
            let customerPhone = order.customerPhone ?? "NA"
            let paymentMethod = order.paymentMethod ?? ""
            let total = order.totalAmount ?? 0.0
            let discount = order.discount ?? 0
            let credit = order.credit ?? 0
            let grandTotal = total - credit - discount
            let formattedGrandTotal = String(format: "%.2f", grandTotal)
            alignText(value: " \(currentDateFormatted()) \n \(vendorName) \n \(vendorAddressLine1) \n \(vendorAddressLine2) \n Tel:\(vendorPhone) \n Admin: \(adminPhone)", x: 10, y: 50, width: 200, height: 200, alignment: .left, textFont: UIFont.systemFont(ofSize: 16), isBold: true)
            
            alignText(value: "\(businessName) \n \(customerName) \n \(customerAddress) \n Tel:\(customerPhone) \n Invoice number: \(invoiceNumber ?? "#Draft")", x: 410, y: 50, width: 180, height: 200, alignment: .left, textFont: UIFont.systemFont(ofSize: 16), isBold: false)
            
            drawTable(tableHeaders: ["Item","Description", "Qty", "Price"],
                      tableRows: order.products,
                      startX: 10,
                      startY: 250,
                     
                      cellHeight: 40,
                      alignment: .left,
                      textFont: UIFont.systemFont(ofSize: 14), pageWidth: 800)
            
            alignText(value: "Payment Method: \(paymentMethod)", x: 10, y: 500, width: 400, height: 100, alignment: .left, textFont: UIFont.systemFont(ofSize: 20), isBold: false)
            alignText(value: "Total: $\(total) \n Discount: -$\(discount) \n Credit: -$\(credit) \n Grand Total: $\(formattedGrandTotal)",x: 410,y: 500,width: 200,height: 200,alignment: .left,textFont: UIFont.systemFont(ofSize: 16), isBold: true)
            alignText(value: "POD", x: 10, y: 600, width: 1000, height: 200, alignment: .left, textFont: UIFont.systemFont(ofSize: 18), isBold: false)
            alignText(value: "Notes: __________\(order.notes ?? "")______________________", x: 10, y: 630, width: 1000, height: 200, alignment: .left, textFont: UIFont.systemFont(ofSize: 18), isBold: false)
            alignText(value: "ThankYou For your Business", x: 170, y: 680, width: 400, height: 200, alignment: .left, textFont: UIFont.systemFont(ofSize: 20), isBold: false)
            alignText(value: "iProvide By Software Sufi (https://softwaresufi.com)", x: 100, y: 750, width: 700, height: 200, alignment: .left, textFont: UIFont.systemFont(ofSize: 18), isBold: false)
            alignText(value: "Designed by tecRoam Solution (https://tecroam.com)", x: 125, y: 780, width: 700, height: 200, alignment: .left, textFont: UIFont.systemFont(ofSize: 15), isBold: false)

            if let image = loadImageAsync(imageName: order.eSign ?? "") {
                let imageRect = CGRect(x: 140, y: 540, width: 80, height: 80)
                image.draw(in: imageRect)
            }
            
            // Load and draw the image at specified position
            if let image = loadImageAsync(imageName: order.logo ?? "2024-03-13T02-00-49.233Z-avatar.jpeg") {
                let imageRect = CGRect(x: 220, y: 30, width: 150, height: 150)
                let clipPath = UIBezierPath(roundedRect: imageRect, cornerRadius: 50)
                clipPath.addClip()
                image.draw(in: imageRect)

            }
        }
        return data
    }

    
    func loadImageAsync(imageName:String?) -> UIImage? {
        let logo = imageName ?? "2024-03-13T02-00-49.233Z-avatar.jpeg"
        // Replace "YOUR_IMAGE_URL" with the actual URL of the image you want to load
        guard let url = URL(string: Constants.imageBaseUrl + logo) else {
            print("Invalid image URL")
            return nil
        }
        
        var loadedImage: UIImage?
        let semaphore = DispatchSemaphore(value: 0)
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            defer { semaphore.signal() }
            guard let data = data, error == nil else {
                print("Failed to load image:", error?.localizedDescription ?? "Unknown error")
                return
            }
            loadedImage = UIImage(data: data)
        }.resume()
        
        semaphore.wait()
        return loadedImage
    }
    
    func drawTable(tableHeaders: [String], tableRows: [OrderProduct?], startX: Int, startY: Int, cellHeight: Int, alignment: NSTextAlignment, textFont: UIFont, pageWidth: Int) {
    let totalColumns = tableHeaders.count
    let descriptionColumnWidth = 3 * pageWidth / 8 // Description column is 3/8th of the page width
    let otherColumnWidth = (pageWidth - descriptionColumnWidth) / (totalColumns - 1) // Remaining columns share the rest of the width
    var currentY = startY
    
    // Draw table headers with bold text and a dark line below
    for (index, header) in tableHeaders.enumerated() {
        let width: Int
        let xPosition: Int
        
        switch index {
        case 0:
            width = otherColumnWidth
            xPosition = startX
        case 1:
            width = descriptionColumnWidth
            xPosition = startX + otherColumnWidth
        default:
            width = otherColumnWidth
            xPosition = startX + otherColumnWidth + descriptionColumnWidth + (otherColumnWidth * (index - 2))
        }
        
        drawText(value: header, x: xPosition, y: currentY, width: width, height: cellHeight, alignment: .left, textFont: textFont, isBold: true)
    }
//    drawLine(fromX: startX, fromY: currentY + cellHeight, toX: startX + pageWidth, toY: currentY + cellHeight, color: .black, lineWidth: 2.0)
    currentY += cellHeight + 10 // Add extra spacing after header line
    
    // Draw table rows with light lines between them
    for row in tableRows.compactMap({ $0 }) { // Unwrap the optional OrderProducts
        let description = row.productName ?? ""
        let item = "000000"
        //truncateProductCode(row.productCode ?? "000000")
        let price = "$\(row.price ?? 0)"
        let quantity = "\(row.quantity ?? 0)"
        let total = "$" + ""
        
        // Adjusting widths and x positions for each column
        let productDetails = [item, description, price, quantity, total]
        for (index, value) in productDetails.enumerated() {
            let width: Int
            let xPosition: Int
            
            switch index {
            case 0:
                width = otherColumnWidth
                xPosition = startX
            case 1:
                width = descriptionColumnWidth
                xPosition = startX + otherColumnWidth
            default:
                width = otherColumnWidth
                xPosition = startX + otherColumnWidth + descriptionColumnWidth + (otherColumnWidth * (index - 2))
            }
            
            drawText(value: value, x: xPosition, y: currentY, width: width, height: cellHeight, alignment: .left, textFont: textFont, isBold: true)
        }
//        drawLine(fromX: startX, fromY: currentY + cellHeight, toX: startX + pageWidth, toY: currentY + cellHeight, color: .lightGray, lineWidth: 1.0)
        currentY += cellHeight + 5 // Add extra spacing after each row
    }
}

func drawText(value: String, x: Int, y: Int, width: Int, height: Int, alignment: NSTextAlignment, textFont: UIFont, isBold: Bool) {
    let paragraphStyle = NSMutableParagraphStyle()
    paragraphStyle.alignment = alignment
    
    var attributes: [NSAttributedString.Key: Any] = [
        .paragraphStyle: paragraphStyle,
        .foregroundColor: UIColor.black
    ]
    
    if isBold {
        let boldFontDescriptor = textFont.fontDescriptor.withSymbolicTraits(.traitBold)
        let boldFont = UIFont(descriptor: boldFontDescriptor!, size: textFont.pointSize)
        attributes[.font] = boldFont
    } else {
        attributes[.font] = textFont
    }
    
    let textRect = CGRect(x: x, y: y, width: width, height: height)
    let attributedText = NSAttributedString(string: value, attributes: attributes)
    attributedText.draw(in: textRect)
}



   func alignText(value: String, x: Int, y: Int, width: Int, height: Int, alignment: NSTextAlignment, textFont: UIFont, isBold: Bool) {
    let paragraphStyle = NSMutableParagraphStyle()
    paragraphStyle.alignment = alignment

    // Adjust the font based on the isBold parameter
    let font: UIFont
    if isBold {
        if let boldFontDescriptor = textFont.fontDescriptor.withSymbolicTraits(.traitBold) {
            font = UIFont(descriptor: boldFontDescriptor, size: textFont.pointSize)
        } else {
            font = UIFont.boldSystemFont(ofSize: textFont.pointSize)
        }
    } else {
        font = textFont
    }

    let attributes: [NSAttributedString.Key: Any] = [
        .font: font,
        .paragraphStyle: paragraphStyle
    ]
    
    let textRect = CGRect(x: x, y: y, width: width, height: height)
    value.draw(in: textRect, withAttributes: attributes)
}

    
    
@MainActor
func saveAndSharePDF() {
    let fileName = "\(order.invoiceNumber ?? "NA").pdf"
    let pdfData = generatePDF()
    
    guard let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
        print("Document directory not found")
        return
    }
    
    let documentUrl = documentDirectory.appendingPathComponent(fileName)
    
    do {
        try pdfData.write(to: documentUrl)
        print("PDF saved at: \(documentUrl)")
        
        // Present share sheet
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let keyWindow = windowScene.windows.first(where: { $0.isKeyWindow }),
              let rootViewController = keyWindow.rootViewController else {
            print("Could not find root view controller")
            return
        }
        
        let activityViewController = UIActivityViewController(activityItems: [documentUrl], applicationActivities: nil)
        rootViewController.present(activityViewController, animated: true)
        
    } catch {
        print("Error saving PDF: \(error.localizedDescription)")
    }
}

    
//    @MainActor
//    func sharePDF() {
//        let pdfData = generatePDF()
//        let fileName = "GeneratedPDF.pdf"
//        
//        guard let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
//            print("Document directory not found")
//            return
//        }
//        
//        let fileURL = documentDirectory.appendingPathComponent(fileName)
//        
//        do {
//            try pdfData.write(to: fileURL)
//            
//            DispatchQueue.main.async {
//                let documentInteractionController = UIDocumentInteractionController(url: fileURL)
//                if let windowScene = UIApplication.shared.connectedScenes.first(where: { $0 is UIWindowScene }) as? UIWindowScene {
//                    if let window = windowScene.windows.first {
//                        if !documentInteractionController.presentOptionsMenu(from: .zero, in: window.rootViewController?.view ?? UIView(), animated: true) {
//                            print("Failed to present options menu")
//                        }
//                    }
//                }
//            }
//        } catch {
//            print("Error writing PDF data to file: \(error.localizedDescription)")
//        }
//    }



}



struct Invoice_Previews: PreviewProvider {
    static var previews: some View {
        Invoice(order:OrderModel(customerEmail:"customer2@gmail.com",vendorEmail: "vendor@gmail.com",eSign: "2024-04-29T20-36-27.590Z-eSign.jpg"))
    }
}
