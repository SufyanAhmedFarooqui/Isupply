//
//  ViewAndAddProducts.swift
//  iSupply
//
//  Created by hassan ghouri on 28/02/2024.
//

import SwiftUI

struct ViewAndAddProducts: View {
    @Environment(\.presentationMode) var presentationMode
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    let product:ProductModel
    @State private var isLoading = false
    @State private var qty = ""
    @State private var unitPrice = ""
    @State private var alertItem: AlertType?
    let orderId:String
    let request:Bool
    let apiManager = OrdersAPI.sharedInstance
    @StateObject private var viewModel = OrderProductViewModel()
    init(product: ProductModel, orderId:String, request:Bool) {
            self.product = product
            self.orderId = orderId
            self.request = request
            _unitPrice = State(initialValue: "\(product.price ?? 0.0)")
        }

    var body: some View {
        NavigationStack{
            ZStack {
                if (isLoading){
                    LoadingView()
                }else{
                    VStack(alignment: .leading, spacing: 10) {
                        HStack{
                            Text(product.name ?? "No Product Selected")
                                .font(
                                    Font.custom("Manrope", size: 18)
                                        .weight(.semibold)
                                )
                                .kerning(0.054)
                                .foregroundColor(Color(red: 0.53, green: 0.53, blue: 0.53))
                            Spacer()
                            if product.images != [] {
                                if let imageName = product.images[0] {
                                    AsyncImage(url: URL(string: Constants.imageBaseUrl + imageName)) { phase in
                                        switch phase {
                                        case .empty:
                                            Image("avatar")
                                                .resizable()
                                                .aspectRatio(contentMode: .fill)
                                                .frame(width: 100, height: 100)
                                                .clipShape(Circle())
                                        case .success(let image):
                                            image
                                                .resizable()
                                                .aspectRatio(contentMode: .fill)
                                                .frame(width: 100, height: 100)
                                                .clipShape(Circle())
                                        default:
                                            Image("avatar")
                                                .resizable()
                                                .aspectRatio(contentMode: .fill)
                                                .frame(width: 100, height: 100)
                                                .clipShape(Circle())
                                        }
                                    }
                                }
                            }else {
                                Image("avatar")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 100, height: 100)
                                    .clipShape(Circle())
                            }
                        }.padding(.horizontal)
                        TextFieldWithBorder(text: "QTY", placeholder: "Qty", value: $qty)
                        if(product.productType == "Weight"){
                            TextFieldWithBorder(text: "Weight", placeholder: "Enter Weight", value: $qty)
                        }
                        TextFieldWithBorder(text: "Unit Price", placeholder: "Price", value: $unitPrice)
                        Text("Item Total: $\(calculateItemTotal(),specifier: "%.2f")")
                            .font(Font.custom("Manrope", size: 12).weight(.heavy))
                            .foregroundColor(Color(red: 0.15, green: 0.2, blue: 0.22))
                            .frame(width: 141, height: 14, alignment: .leading)
                            .padding()
                        VStack(alignment: .center) {
                            HStack(alignment: .center, spacing: 10) {
                                Spacer()
                                Button(action: {
                                    presentationMode.wrappedValue.dismiss()
                                }) {
                                    ZStack {
                                        Rectangle()
                                            .foregroundColor(.clear)
                                            .frame(width: 70, height: 31)
                                            .background(Color(red: 0.92, green: 0.11, blue: 0.18))
                                            .cornerRadius(20)
                                        Text("Cancel")
                                            .font(Font.custom("Manrope", size: 14).weight(.semibold))
                                            .foregroundColor(.white)
                                            .frame(width: 70, height: 16, alignment: .center)
                                    }
                                }
                                
                                Button(action: {
                                    addProduct()
                                }) {
                                    ZStack {
                                        Rectangle()
                                            .foregroundColor(.clear)
                                            .frame(width: 50, height: 31)
                                            .background(Color(red: 0.09, green: 0.61, blue: 0.38))
                                            .cornerRadius(20)
                                        Text("Add")
                                            .font(Font.custom("Manrope", size: 14).weight(.semibold))
                                            .foregroundColor(.white)
                                            .frame(width: 70, height: 16, alignment: .center)
                                    }
                                }
                                Spacer()
                            }
                        }
                        ProductsTableView(data:viewModel.products, orderId: orderId)
                        
                        Text("Current Total:  $\(calculateTotalAmount(products: viewModel.products),specifier: "%.2f")")
                          .font(
                            Font.custom("Manrope", size: 12)
                              .weight(.heavy)
                          )
                          .foregroundColor(Color(red: 0.15, green: 0.2, blue: 0.22))
                          .frame(width: 141, height: 14, alignment: .leading)
                          .padding()
                        Spacer()
                    }
                }
            }.navigationTitle("Product Details")
                .toolbar {
                    NavigationLink(destination: SelectPayment(orderId:orderId, request:request)) {
                        Text("Next")
                    }
                }
                .alert(item: $alertItem) { alertType in
                    switch alertType {
                    case .error(let message):
                        return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
                    case .success(let message):
                        return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                        }, secondaryButton: .cancel())
                    }
                }
        }.onAppear{
            viewModel.getProducts(orderId: orderId)
        }
    }
    // Calculate item total
    func calculateItemTotal() -> Float {
            guard let qty = Float(qty), let unitPrice = Float(unitPrice) else {
                return 0.0
        }
        
        let itemTotal = qty * unitPrice
        return itemTotal
    }
    func calculateTotalAmount(products: [OrderProduct]) -> Double {
        var totalAmount = 0.0
        
        for product in products {
            if let quantity = product.quantity, let price = product.price {
                totalAmount += Double(quantity) * Double(price)
            }
        }
        
        return totalAmount
    }

    func addProduct() {
        Task {
            isLoading = true
            if(!formIsValid){
                alertItem = .error(message: "Quantity cannot be more than stock enter valid quantity or adjust stock")
                isLoading = false
                return
            }
            viewModel.products.append(OrderProduct(id:product.id, productCode:product.itemCode ?? "0", productName: product.name, quantity: Int(qty), price: Double(unitPrice)))
            let order = OrderModel(id: orderId, userEmail: userEmail, userRole: userRole, products: viewModel.products, totalAmount: calculateTotalAmount(products: viewModel.products), status: "productsAdded")
            apiManager.createOrderApi(order: order, image: nil, route: "updateOrder") { result in
                switch result {
                case let .success((success, _)):
                    if success {
                        DispatchQueue.main.async {
                            // Make sure isLoading and other UI updates are on the main thread
                            isLoading = false
                            presentationMode.wrappedValue.dismiss()
                        }
                    } else {
                        DispatchQueue.main.async {
                            isLoading = false
                            alertItem = .error(message: "Check Internet Connection.")
                        }
                    }
                case let .failure(error):
                    DispatchQueue.main.async {
                        isLoading = false
                        alertItem = .error(message: error.localizedDescription)
                    }
                }
            }
        }
    }
    
}

#Preview {
    ViewAndAddProducts(product: ProductModel(),orderId:"66301ec516bbccb237d1ad90",request:false)
}

// Mark: - AuthenticationFormProtocol

extension ViewAndAddProducts: AuthenticationFormProtocol {
    var formIsValid: Bool {
        guard let quantity = Int(qty), let stock = product.stock else {
            return false
        }
        return quantity <= stock
    }
}
