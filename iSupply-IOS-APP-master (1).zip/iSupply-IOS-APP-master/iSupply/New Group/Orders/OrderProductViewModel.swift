//
//  OrderProductViewModel.swift
//  iSupply
//
//  Created by hassan ghouri on 04/03/2024.
//

import Foundation

final class OrderProductViewModel: ObservableObject {
    @Published var products:[OrderProduct] = []
    @Published var isLoading = false
    @Published var alertItem: AlertItem?

    func getProducts(orderId:String) {
        isLoading = true
        OrdersAPI.sharedInstance.getProducts(orderId: orderId, completion:{ [self] result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let products):
                    self.products = products
                case .failure(_):
                    self.alertItem = AlertItem(title: "Cannot get Products", message: "Check your Internet Connection")
                }
            }
        })
    }
}
