//
//  GetStartedView.swift
//  iSupply
//
//  Created by hassan ghouri on 29/01/2024.
//

import SwiftUI

struct GetStartedView: View {
    @AppStorage("isOnboarding") var isOnboarding:Bool?
    var body: some View {
        NavigationStack{
        VStack {
            Spacer()
            Image("gettingCoffee")
                .resizable()
                .scaledToFit()
                .frame(width: 200,height: 200)
            Text("Welcome to iProvide Business App")
              .font(
                Font.custom("Manrope", size: 24)
                  .weight(.heavy)
              )
              .multilineTextAlignment(.center)
              .foregroundColor(Color(red: 0.92, green: 0.11, blue: 0.18))
              .frame(width: 313, height: 72, alignment: .top)
            Text("Streamline operations with ease")
              .font(Font.custom("Manrope", size: 18))
              .multilineTextAlignment(.center)
              .foregroundColor(Color(red: 0.01, green: 0.01, blue: 0.01))
              .frame(width: 256.76001, height: 23.05459, alignment: .top)
            NavigationLink {
                SignInView().onAppear(perform: {
                    isOnboarding = false
                })
            } label: {
                ZStack {
                    Rectangle()
                      .foregroundColor(.clear)
                      .frame(width: 210, height: 58)
                      .background(
                        LinearGradient(
                          stops: [
                            Gradient.Stop(color: Color(red: 0.92, green: 0.11, blue: 0.18), location: 0.00),
                            Gradient.Stop(color: Color(red: 0.95, green: 0.18, blue: 0.39), location: 1.00),
                          ],
                          startPoint: UnitPoint(x: -0.5, y: 0.5),
                          endPoint: UnitPoint(x: 0.5, y: 1.5)
                        )
                      )
                  .cornerRadius(100)
                
                Text("Get Started")
                  .font(
                    Font.custom("Manrope", size: 22)
                      .weight(.heavy)
                  )
                  .multilineTextAlignment(.center)
                  .foregroundColor(.white)
                  .frame(width: 224, alignment: .top)
                }
            }
            Spacer()
            
        }.navigationBarBackButtonHidden()
    }
    }
}

#Preview {
    GetStartedView()
}
