import SwiftUI

struct PrivacyPolicy: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("iSupply Pro Privacy Policy")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding(.top, 20)
                    .foregroundColor(.blue)

                Text("Last Updated: 19-07-2025")
                    .font(.caption)
                    .foregroundColor(.gray)

                Text("At iSupply Pro, we are committed to protecting your privacy. This Privacy Policy explains how we collect, use, and disclose your personal information when you use our mobile application.")

                Text("**1. Information We Collect**")
                    .font(.headline)
                    .padding(.top, 20)

                Text("We may collect the following types of information from you:")
                    .padding(.leading, 10)

                VStack(alignment: .leading) {
                    Text("• Personal Information: Name, email address, phone number, and other contact details you provide when creating an account or using the app.")
                    Text("• Usage Data: Information about how you use the app, such as your device type, operating system, app version, and usage patterns.")
                    Text("• Location Data: If you enable location services, we may collect your location data to provide location-based services, such as tracking salespersons and managing inventory.")
                    Text("• Payment Information: If you make a purchase within the app, we may collect your payment information, such as credit card details, to process the transaction.")
                }

                Text("**2. How We Use Your Information**")
                    .font(.headline)

                Text("We may use your information for the following purposes:")
                    .padding(.leading, 10)

                VStack(alignment: .leading) {
                    Text("• To provide and maintain the iSupply Pro app.")
                    Text("• To create and manage your account.")
                    Text("• To process orders, payments, and track sales data.")
                    Text("• To communicate with you about the app, including updates, promotions, and support.")
                    Text("• To improve the app's functionality and user experience.")
                    Text("• To comply with legal and regulatory requirements.")
                }

                Text("**3. Data Sharing**")
                    .font(.headline)

                Text("We may share your information with the following third parties:")
                    .padding(.leading, 10)

                VStack(alignment: .leading) {
                    Text("• Payment processors: To process your payments.")
                    Text("• Shipping carriers: To deliver your orders.")
                    Text("• Service providers: To assist us with providing the app and its features.")
                    Text("• Business partners: To collaborate on marketing and promotional activities.")
                    Text("• Legal authorities: To comply with legal requests or to protect our rights and interests.")
                }

                Text("**4. Data Security**")
                    .font(.headline)

                Text("We take reasonable measures to protect your information from unauthorized access, use, or disclosure. However, no method of transmission over the internet or method of electronic storage is completely secure.")

                Text("**5. Children's Privacy**")
                    .font(.headline)

                Text("The iSupply Pro app is not intended for use by children under the age of 13. We do not knowingly collect personal information from children.")

                Text("**6. Your Rights**")
                    .font(.headline)

                Text("You have the right to:")
                    .padding(.leading, 10)

                VStack(alignment: .leading) {
                    Text("• Access your personal information.")
                    Text("• Update or correct your personal information.")
                    Text("• Request the deletion of your personal information.")
                    Text("• Opt-out of certain data processing activities.")
                }

                Text("**7. Changes to This Policy**")
                    .font(.headline)

                Text("We may update this Privacy Policy from time to time. We will notify you of any material changes by posting the updated policy on the app.")

                Text("**8. Contact Us**")
                    .font(.headline)

                Text("If you have any questions about this Privacy Policy, please contact us at [Insert Email Address].")

                Spacer()
            }
            .padding()
        }
    }
}

#Preview {
    PrivacyPolicy()
}
