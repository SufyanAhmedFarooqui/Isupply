//
//  ContainerView.swift
//  iSupply
//
//  Created by hassan ghouri on 26/01/2024.
//

import SwiftUI

struct ContainerView: View {
    @State private var isSplashScreenViewPresented = true
    @AppStorage("isOnboarding") var isOnboarding = true
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    var body: some View {
        if isSplashScreenViewPresented {
            SplashScreenView(isPresented: $isSplashScreenViewPresented)
        } else if isOnboarding {
            GetStartedView()
        } else if (userEmail != "" && userRole != ""){
            MainView()
        }else{
            SignInView()
        }
            
    }
}

#Preview {
    ContainerView()
}
