//
//  SplashScreenView.swift
//  iSupply
//
//  Created by hassan ghouri on 26/01/2024.
//

import SwiftUI

struct SplashScreenView: View {
    @Binding var isPresented:Bool
    @State private var imageOpacity = 1.0
    @State private var opacity = 1.0
    @State private var scale = CGSize(width: 0.8, height: 0.8)
    
    var body: some View {
        ZStack{
            VStack {
                VStack{
                    Spacer()
                    Image("logo")
                        .resizable()
                        .scaledToFit()
                        .opacity(imageOpacity)
                        .frame(width: 200,height: 200)
                    
                }
                .scaleEffect(scale)
                Spacer()
                Image("SplashImage")
                    .resizable()
                    .scaledToFit()
                    .opacity(imageOpacity)
            }
        }
        .opacity(opacity)
        .onAppear{
            withAnimation(.easeInOut(duration: 1.5)){
                scale = CGSize(width: 1, height: 1)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5, execute:{
                withAnimation(.easeInOut(duration: 0.35)){
                    scale = CGSize(width: 50, height: 50)
                    opacity = 0
                }
            })
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.9, execute:{
                withAnimation(.easeInOut(duration: 0.2)){
                    isPresented.toggle()
                }
            })
            
        }
    }
}

#Preview {
    SplashScreenView(isPresented: .constant(true))
}
