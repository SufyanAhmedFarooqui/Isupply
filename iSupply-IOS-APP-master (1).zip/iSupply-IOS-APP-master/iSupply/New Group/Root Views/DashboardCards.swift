//
//  DashboardCards.swift
//  iSupply
//
//  Created by hassan ghouri on 11/03/2024.
//

import SwiftUI

struct AdminDashboardCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("What do you want to do today?")
                .font(Font.custom("Manrope", size: 16))
                .multilineTextAlignment(.center)
                .foregroundColor(Color(red: 0.14, green: 0.12, blue: 0.13))
                .padding(.top)
                .padding(.horizontal)
            VStack(alignment: .center, spacing: 20) {
                HStack(alignment: .top, spacing: 20) {
                    NavigationLink {
                        ExploreUsers()
                    } label: {
                        //                    MainPageCard2(title: "Users", imageName: "kulfi")
                        MainPageCard(title: "Users", imageName: "person.3.fill", backColor: Color(red: 0.46, green: 0.41, blue: 0.87).opacity(0.25),text:"Explore Users Here")
                    }
                    NavigationLink {
                        Analytics()
                    } label: {
                        //                    MainPageCard2(title: "Products", imageName: "kulfi")
                        MainPageCard(title: "Analytics", imageName: "chart.bar.xaxis", backColor: Color(red: 0.69, green: 0.87, blue: 0.32).opacity(0.25),text:"Measure your productivity")
                    }
                }
            }
            HStack(alignment: .top, spacing: 20) {
                NavigationLink {
                    Inventory()
                } label: {
                    MainPageCard(title: "Inventory", imageName: "shippingbox.fill", backColor: Color(red: 0.85, green: 0.92, blue: 0.85).opacity(0.25),text:"What you have here")
                }
                NavigationLink {
                    Orders()
                } label: {
                    MainPageCard(title: "Orders", imageName: "list.bullet.clipboard.fill", backColor: Color(red: 0.95, green: 0.77, blue: 0.12).opacity(0.25),text:"Manage your orders")
                }
                
            }
        }
    }
}

struct SalesPersonDashboardCard: View {
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @StateObject private var viewModel = UserViewModel()
    @StateObject private var locationViewModel = LocationViewModel()
    let apiManager = UsersAPI.sharedInstance
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("What do you want to do today?")
                .font(Font.custom("Manrope", size: 16))
                .multilineTextAlignment(.center)
                .foregroundColor(Color(red: 0.14, green: 0.12, blue: 0.13))
                .padding(.top)
                .padding(.horizontal)
            HStack(alignment: .center, spacing: 20) {
                NavigationLink {
                    UserScreen()
                } label: {
                    MainPageCard(title: "Customers", imageName: "person.3.fill", backColor: Color(red: 0.46, green: 0.41, blue: 0.87).opacity(0.25),text:"Explore Users")
                }
                NavigationLink {
                    Orders()
                } label: {
                    MainPageCard(title: "Orders", imageName: "chart.bar.xaxis", backColor: Color(red: 0.69, green: 0.87, blue: 0.32).opacity(0.25),text:"Manage your orders")
                }
                
            }
            HStack(alignment: .top, spacing: 20) {
                NavigationLink {
                    NewTruckStockProducts(vendorEmail:vendorEmail,salesPersonEmail:userEmail)
                } label: {
                    MainPageCard(title: "Truck Stock", imageName: "shippingbox.fill", backColor: Color(red: 0.85, green: 0.92, blue: 0.85).opacity(0.25),text:"Assign Stock in your Truck")
                }
                
            }
        }.onAppear{
            viewModel.getUsers(email: userEmail, route: "getUserByEmail")
            locationViewModel.checkIfLocationServicesEnabled()
            saveLocationToDatabase(lat: locationViewModel.centerCoordinate?.latitude ?? 0, lng: locationViewModel.centerCoordinate?.longitude ?? 0)
        }
    }
    
    private func saveLocationToDatabase(lat: Double, lng: Double) {
        // API call to save the location
        Task {
            apiManager.saveLocationToDatabase(email:userEmail ,lat: lat, lng: lng, route: "updateCurrentLocation") { result in
                switch result {
                case let .success(success):
                    if success {
                        print("Location Sent")
                    } else {
                        print("Location not sent")
                    }
                case let .failure(error):
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    var vendorEmail: String {
        guard let user = viewModel.users.first else {
            return "" // No users available	
        }
        
        // Find the associated user with role "Vendor"
        if let vendorAssociatedUser = user.associatedUsers.first(where: { $0?.role == "Vendor" }),
           let vendorEmail = vendorAssociatedUser?.email {
            
            return vendorEmail
        } else {
            return "" // No associated user with role "Vendor" found
        }
    }
}

struct CustomerDashboardCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("What do you want to do today?")
                .font(Font.custom("Manrope", size: 16))
                .multilineTextAlignment(.center)
                .foregroundColor(Color(red: 0.14, green: 0.12, blue: 0.13))
                .padding(.top)
                .padding(.horizontal)
            HStack(alignment: .center, spacing: 20) {
                NavigationLink {
                    ProductsForCustomer()
                } label: {
                    MainPageCard(title: "Vendors / Products", imageName: "basket.fill", backColor: Color(red: 0.46, green: 0.41, blue: 0.87).opacity(0.25),text:"View Products Here")
                }
                NavigationLink {
                    OrderReport()
                } label: {
                    MainPageCard(title: "PreviousOrders", imageName: "cart.fill", backColor: Color(red: 0.69, green: 0.87, blue: 0.32).opacity(0.25),text:"Manage your orders")
                }
                
            }
            HStack(alignment: .top, spacing: 20) {
                NavigationLink {
                    RequestOrder()
                } label: {
                    MainPageCard(title: "Request Order", imageName: "cart.badge.plus", backColor: Color(red: 0.85, green: 0.92, blue: 0.85).opacity(0.25),text:"Make an order request")
                }
                NavigationLink {
                    RequestedOrders(requested: true)
                } label: {
                    MainPageCard(title: "Requested Purchase Orders", imageName: "cart.badge.plus", backColor: Color(red: 0.85, green: 0.92, blue: 0.85).opacity(0.25),text:"Manage Requested orders here")
                }
            }
        }
    }
}

