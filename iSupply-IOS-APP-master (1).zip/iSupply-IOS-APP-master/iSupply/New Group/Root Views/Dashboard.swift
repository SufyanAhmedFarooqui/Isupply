//
//  Dashboard.swift
//  iSupply
//
//  Created by hassan ghouri on 31/01/2024.
//

import SwiftUI

struct Dashboard: View {
    @Environment(\.presentationMode) var presentationMode
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @AppStorage("userName") var userName = ""
    var body: some View {
        NavigationStack{
            VStack(alignment: .leading, content: {
                HStack{
                    Text("Hi \(userName)")
                        .font(Font.custom("Manrope", size: 20))
                        .multilineTextAlignment(.center)
                        .foregroundColor(.black)
                    Spacer()
                    Button {
                        UserDefaults.standard.set("", forKey: "userEmail")
                        UserDefaults.standard.set("", forKey: "userName")
                        UserDefaults.standard.set("", forKey: "userRole")
                        presentationMode.wrappedValue.dismiss()
                    } label: {
                        Image("moveUp")
                            .resizable()
                            .frame(width: 35, height: 35)
                    }
                }.padding(.horizontal)
                VStack(alignment: .leading, spacing: 0, content: {
                    Text("Explore")
                        .font(
                            Font.custom("Manrope", size: 48)
                                .weight(.heavy)
                        )
                        .foregroundColor(Color(red: 0.2, green: 0.19, blue: 0.19))
                    
                    Text("Dashboard")
                        .font(Font.custom("Manrope", size: 20))
                        .multilineTextAlignment(.center)
                        .foregroundColor(.black)
                }).padding(.horizontal)
                
                if(userRole == "Admin" || userRole == "Vendor"){
                    AdminDashboardCard()
                }else if (userRole == "Customer") {
                    CustomerDashboardCard()
                }else{
                    SalesPersonDashboardCard()
                }
                
            }).padding(.horizontal)
        }
    }
}

#Preview {
    Dashboard()
}
