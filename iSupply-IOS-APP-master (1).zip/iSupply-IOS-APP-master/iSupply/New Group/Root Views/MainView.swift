//
//  MainView.swift
//  iSupply
//
//  Created by hassan ghouri on 17/01/2024.
//

import SwiftUI

struct MainView: View {
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    
    @StateObject private var viewModel = UserViewModel()
    @State private var selectedTab: Tab = .dashboard // Initialize with a default tab	
    
    var body: some View {
        NavigationStack {
            TabView(selection: $selectedTab) {// Use selection parameter
                Dashboard()
                    .tabItem {
                        Label("Dashboard", systemImage: "circle.grid.3x3.circle.fill")
                    }
                    .tag(Tab.dashboard) // Assign a tag to identify this tab
                Settings()
                    .tabItem {
                        Label("Setting", systemImage: "gear.circle")
                    }
                    .tag(Tab.settings) // Assign a tag to identify this tab
                if(userRole == "admin" || userRole == "Vendor"){
                    SelectSalesPerson(locationScreen: true)
                        .tabItem {
                            Label("Locations", systemImage: "bell.circle")
                        }
                        .tag(Tab.locations) // Assign a tag to identify this tab
                }
                if !viewModel.users.isEmpty {
                    UpdateUser(user: viewModel.users[0], profile: true)
                        .tabItem {
                            Label("Profile", systemImage: "person.circle")
                        }
                        .tag(Tab.profile) // Assign a tag to identify this tab
                    
                }
            }.navigationBarBackButtonHidden(true)
                .onAppear {
                    viewModel.getUsers(email: userEmail, route: "getUserByEmail")
            }
        }
    }
}

// Enum to represent tab selection
enum Tab {
    case dashboard
    case settings
    case locations
    case profile
}



#Preview {
    MainView()
}
