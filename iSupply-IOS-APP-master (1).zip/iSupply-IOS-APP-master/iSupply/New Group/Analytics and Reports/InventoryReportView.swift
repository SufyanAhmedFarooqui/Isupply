//
//  InventoryReportView.swift
//  iSupply
//
//  Created by hassan ghouri on 28/04/2024.
//

import SwiftUI

struct InventoryReportView: View {
    @State private var fromDate = Date()
    @State private var toDate = Date()
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @State private var searchTerm = ""
    @StateObject private var viewModel = ProductViewModel()
    
    var body: some View {
        NavigationView {
            VStack {
                // Date Picker From
                DatePicker("From", selection: $fromDate, displayedComponents: .date)
                    .datePickerStyle(.compact)
                    .padding(.horizontal)
                
                // Date Picker To
                DatePicker("To", selection: $toDate, displayedComponents: .date)
                    .datePickerStyle(.compact)
                    .padding(.horizontal)
                // Buttons for Retrieving Reports
                VStack{
                    Button("Search/Retrieve") {
                        // Implement search action
                        viewModel.getProductsByDateAndEmail(email: userEmail, fromDate: fromDate, toDate: toDate)
                    }
                    .buttonStyle(.bordered)
                    HStack {
                        
                        
                        Button("Excel") {
                            // Implement Excel export action
                            DispatchQueue.global(qos: .background).async {
                                do {
                                    let fileURL = try createExcel(from: filteredProducts)
                                    DispatchQueue.main.async {
                                        // Update your UI or handle the file URL on the main thread
                                        shareCSV(fileURL: fileURL)
                                    }
                                } catch {
                                    print("Error generating CSV: \(error)")
                                }
                            }
                        }
                        .buttonStyle(.bordered)
                        
                        Button("CSV") {
                            DispatchQueue.global(qos: .background).async {
                                do {
                                    let fileURL = try createCSV(from: filteredProducts)
                                    DispatchQueue.main.async {
                                        // Update your UI or handle the file URL on the main thread
                                        shareCSV(fileURL: fileURL)
                                    }
                                } catch {
                                    print("Error generating CSV: \(error)")
                                }
                            }

                        }
                        .buttonStyle(.bordered)
                        
                        Button("PDF") {
                            // Implement PDF export action
                            DispatchQueue.global(qos: .background).async {
                                do {
                                    let fileURL = try createPDF(from: filteredProducts)
                                    DispatchQueue.main.async {
                                        // Update your UI or handle the file URL on the main thread
                                        shareCSV(fileURL: fileURL)
                                    }
                                } catch {
                                    print("Error generating CSV: \(error)")
                                }
                            }
                        }
                        .buttonStyle(.bordered)
                    }
                }.padding()
                
                List {
                    // Headers for the Product Table
                    HStack {
                        Text("$")
                            .frame(width: 50, alignment: .leading)
                        Spacer()
                        Text("Name")
                            .frame(width: 100, alignment: .leading)
                        Spacer()
                        Text("Brand")
                            .frame(width: 100, alignment: .leading)
                        Spacer()
                        Text("QTY")
                            .frame(width: 50, alignment: .trailing)
                    }
                    .padding(.horizontal)
                    .background(Color.gray.opacity(0.2))
                    
                    // Product Rows
                    ForEach(filteredProducts.indices, id: \.self) { index in
                        let product = filteredProducts[index]
                        HStack {
                            Text("\(product.price ?? 0.00)")
                            Spacer()
                            Text(product.name ?? "")
                                .frame(width: 100, alignment: .leading)
                            Spacer()
                            Text(product.brand ?? "")
                                .frame(width: 100, alignment: .leading)
                            Spacer()
                            Text("\(product.stock ?? 0)")
                                .frame(width: 50, alignment: .trailing)
                        }
                    }
                }
                
            }
            .navigationBarTitle("Inventory Report", displayMode: .inline)
            
        }
        if (viewModel.isLoading){ LoadingView()}
    }
    var filteredProducts: [ProductModel] {
        let filteredArray = viewModel.products
        return filteredArray
    }
    private func shareCSV(fileURL: URL) {
            // Finding the current key window in a safe way using the new API
            guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                  let rootViewController = windowScene.keyWindow?.rootViewController else {
                return
            }

            let activityViewController = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
            rootViewController.present(activityViewController, animated: true, completion: nil)
        }

}


struct InventoryReportView_Previews: PreviewProvider {
    static var previews: some View {
        InventoryReportView()
    }
}
