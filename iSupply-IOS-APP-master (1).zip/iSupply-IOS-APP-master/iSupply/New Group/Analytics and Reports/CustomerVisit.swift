//
//  CustomerVisit.swift
//  iSupply
//
//  Created by hassan ghouri on 27/04/2024.
//

import SwiftUI

struct CustomerVisit: View {
    @StateObject private var viewModel = UserViewModel()
    @State private var searchTerm = ""
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    var body: some View {
        NavigationStack{
            List(filteredUsers, id: \.email) { user in
                CustomerCell(person: user)
            }
        }.padding(.horizontal)
            .navigationTitle("User Details")
            .searchable(text: $searchTerm, prompt: "Search for selected Users")
            .onAppear{
                viewModel.getUsers(email: userEmail,route:"getUsersByEmail")
            }
        if (viewModel.isLoading){ LoadingView()}
        
        var filteredUsers: [UserModel] {
            
            var filteredArray = viewModel.users
            filteredArray = filteredArray.filter { $0.role == "Customer" }
            if !searchTerm.isEmpty {
                filteredArray = filteredArray.filter { user in
                    user.email!.lowercased().contains(searchTerm.lowercased()) ||
                    user.name!.lowercased().contains(searchTerm.lowercased())
                }
            }
            
            return filteredArray
        }
    }
}
    #Preview {
        CustomerVisit()
    }
    
    
    struct CustomerCell: View {
        var person: UserModel
        
        var body: some View {
            HStack {
                if let avatar = person.avatar {
                    AsyncImage(url: URL(string: Constants.imageBaseUrl+avatar)) { phase in
                        switch phase {
                        case .empty:
                            Image("avatar")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 80, height: 80)
                                .clipShape(Circle())
                        case .success(let image):
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 80, height: 80)
                                .clipShape(Circle())
                        default:
                            Image("avatar")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 80, height: 80)
                                .clipShape(Circle())
                        }
                    }
                }else{
                    Image("avatar")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 100, height: 100)
                        .clipShape(Circle())
                }
                
                VStack(alignment: .leading) {
                    Text(person.name ?? "")
                        .font(.headline)
                    
                    Text("No Invoice yet ")
                        .font(.subheadline)
                        .foregroundColor(.red)
                }
            }
        }
    }
