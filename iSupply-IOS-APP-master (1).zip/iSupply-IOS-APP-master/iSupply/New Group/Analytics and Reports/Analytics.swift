//
//  Analytics.swift
//  iSupply
//
//  Created by hassan ghouri on 07/02/2024.
//

import SwiftUI

struct Analytics: View {
    var body: some View {
        NavigationStack{
            VStack{
                HStack(alignment: .center, spacing: 20) {
                    NavigationLink {
                        CustomerVisit()
                    } label: {
                        MainPageCard(title: "No Customer/Vendor Visit in 30 days", imageName: "doc.text.below.ecg.fill", backColor: Color(red: 0.54, green: 0.84, blue: 0.91).opacity(0.25))
                    }
                    
                    NavigationLink{
                        InventoryReportView()
                    } label: {
                        MainPageCard(title: "Inventory Report", imageName: "basket.fill", backColor: Color(red: 0.69, green: 0.87, blue: 0.32).opacity(0.25))
                    }
                }
                HStack(alignment: .center, spacing: 20) {
                    NavigationLink {
                        TopSeller(showUserDetails: false, user:UserModel(userName:"", email: "abc@gmail.com", password:"123"))
                    } label: {
                        MainPageCard(title: "Top Seller", imageName: "rosette", backColor: Color(red: 0.97, green: 0.55, blue: 0.16).opacity(0.25))
                    }
                    NavigationLink {
                        TopSellingProduct(showProductDetails: false, productId: "")
                    } label: {
                        MainPageCard(title: "Top Selling Product", imageName: "star.square.fill", backColor: Color(red: 0.68, green: 0.45, blue: 0.38).opacity(0.25))
                    }
                }
            }
        }.navigationTitle("Analytics and Reports")
    }
}

#Preview {
    Analytics()
}
