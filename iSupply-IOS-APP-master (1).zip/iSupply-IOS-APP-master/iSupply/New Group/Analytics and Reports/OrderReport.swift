//
//  OrderReport.swift
//  iSupply
//
//  Created by hassan ghouri on 28/04/2024.
//

import SwiftUI

struct OrderReport: View {
    @State private var searchTerm = ""
    @State private var showPaid = true
    @StateObject var viewModel = OrderViewModel()
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    
    var body: some View {
        VStack {
            // Filter Buttons
            HStack {
                Button("Paid") {
                    showPaid = true
                }
                .buttonStyle(FilledRoundedButtonStyle(isSelected: showPaid))
                
                Button("UnPaid") {
                    showPaid = false
                }
                .buttonStyle(FilledRoundedButtonStyle(isSelected: !showPaid))
            }
            
            DynamicTableView(headers: ["Date", "Business","Invoice Number"], rows: filteredRows, route: showPaid ? "review":"payment")
        }
        .navigationTitle("Previous Orders")
        .searchable(text: $searchTerm, prompt: "Search for Orders")
        .onAppear {
            viewModel.fetchOrdersByEmailAndStatus(email: userEmail, role: userRole, status: "", route:"fetchOrders")
        }
    }
    private var filteredRows: [[String]] {
        // Start with the orders and apply the search term filter if necessary
        var filteredOrders = searchTerm.isEmpty ? viewModel.orders : viewModel.orders.filter {
            $0.businessName?.lowercased().contains(searchTerm.lowercased()) ?? false
        }
        
        // Apply additional filtering based on the 'showPaid' state
        if showPaid {
            filteredOrders = filteredOrders.filter { order in
                order.status == "invoiceGenerated"  // Assuming the status "paid" is stored as a String in the OrderModel
            }
        }

        // Map the filtered orders to a format suitable for display
        return filteredOrders.map { order in
            formatRow(for: order)
        }
    }

    
    private func formatRow(for order: OrderModel) -> [String] {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = order.createdAt.map { dateFormatter.string(from: $0) } ?? "N/A"
        let businessName = order.businessName ?? "No Business"
        let invoiceNumber = order.invoiceNumber ?? "NA"
        let orderId = order.id ?? ""
        return [dateString, businessName, invoiceNumber, orderId]
        
    }
}


// Custom Button Style
struct FilledRoundedButtonStyle: ButtonStyle {
    var isSelected: Bool
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundColor(isSelected ? .white : .black)
            .padding()
            .background(isSelected ? Color.green : Color.gray.opacity(0.2))
            .cornerRadius(8)
    }
}

struct OrderReport_Previews: PreviewProvider {
    static var previews: some View {
        OrderReport()
    }
}
