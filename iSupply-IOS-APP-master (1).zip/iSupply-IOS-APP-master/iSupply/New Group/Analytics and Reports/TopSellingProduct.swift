//
//  TopSellingProduct.swift
//  iSupply
//
//  Created by hassan ghouri on 28/04/2024.
//

import SwiftUI

struct TopSellingProduct: View {
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @State private var showProductDetails: Bool
    @StateObject var viewModel: ProductViewModel = ProductViewModel()
    var productId: String?
    @State private var navigationToUpdateScreen = false

    // Custom initializer
    init(showProductDetails: Bool, productId: String?) {
        _showProductDetails = State(initialValue: showProductDetails)
        self.productId = productId
    }

    @State private var selectedImageIndex = 0
    let timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    // Image Carousel
                    TabView(selection: $selectedImageIndex) {
                        if let productImages = viewModel.topSellingProduct?.images, !productImages.isEmpty {
                            ForEach(productImages.indices, id: \.self) { index in
                                AsyncImage(url: URL(string: Constants.imageBaseUrl + (productImages[index] ?? "avatar.jpeg"))) { image in
                                    image
                                        .resizable()
                                        .scaledToFit()
                                } placeholder: {
                                    ProgressView()
                                }
                                .tag(index)
                            }
                        } else {
                            Text("No images available")
                                .frame(height: 300)
                        }
                    }
                    .frame(height: 300)
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .automatic))
                    .onReceive(timer) { _ in
                        withAnimation {
                            if let count = viewModel.topSellingProduct?.images.count, count > 0 {
                                selectedImageIndex = (selectedImageIndex + 1) % count
                            }
                        }
                    }

                    // Product Name and Details
                    Text(viewModel.topSellingProduct?.name ?? "No Name")
                        .font(.title)
                        .fontWeight(.bold)

                    VStack {
                        DetailView(label: "Product Type", value: viewModel.topSellingProduct?.productType ?? "N/A")
                        DetailView(label: "Brand", value: viewModel.topSellingProduct?.brand ?? "N/A")
                        DetailView(label: "Flavor", value: viewModel.topSellingProduct?.flavourType ?? "N/A")
                        DetailView(label: "Size", value: viewModel.topSellingProduct?.size ?? "N/A")
                        DetailView(label: "Price", value: String(viewModel.topSellingProduct?.price ?? 0))
                        DetailView(label: "Stock", value: String(viewModel.topSellingProduct?.stock ?? 0))
                    }
                }
                .padding()
            }
            .onAppear {
                if !showProductDetails {
                    viewModel.getTopSellingProduct()
                } else {
                    if let id = productId {
                        viewModel.getProductById(id: id, route: "getProductById")
                    }
                }
            }
        }
        .toolbar(content: {
            if (userRole == "Vendor" || userRole == "Admin") && showProductDetails {
                Button {
                    // Action based on condition
                    navigationToUpdateScreen = true
                } label: {
                    Image(systemName: "pencil")
                }
            }
        })
        .navigationDestination(isPresented: $navigationToUpdateScreen) {
            UpdateProduct(product: viewModel.topSellingProduct ?? ProductModel())
        }
    }
}

struct DetailView: View {
    var label: String
    var value: String

    var body: some View {
        HStack {
            Text("\(label):")
                .fontWeight(.semibold)
            Spacer()
            Text(value)
        }
        .padding(.vertical, 2)
    }
}

struct TopSellingProduct_Previews: PreviewProvider {
    static var previews: some View {
        TopSellingProduct(showProductDetails: false, productId: "6642904efb49c9a60fa85d4a")
    }
}
