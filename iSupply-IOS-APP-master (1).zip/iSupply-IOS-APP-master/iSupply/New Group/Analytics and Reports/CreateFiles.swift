import Foundation
import PDFKit
import UIKit

func createCSV(from products: [ProductModel]) throws -> URL {
    let headers = "Name,Category,Brand,Size,Price,Flavor,Stock\n"
    var csvString = headers
    
    for product in products {
        // Break down each field into a simple string variable
        let name = product.name ?? ""
        let category = product.category ?? ""
        let brand = product.brand ?? ""
        let size = product.size ?? ""
        let price = String(product.price ?? 0)
        let flavor = product.flavourType ?? ""
        let stock = String(product.stock ?? 0)

        // Now construct the row string
        let row = "\(name),\(category),\(brand),\(size),\(price),\(flavor),\(stock)\n"
        
        // Append it to the main CSV string
        csvString.append(contentsOf: row)
    }
    
    let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    let csvPath = documentsPath.appendingPathComponent("ProductInventory.csv")
    // Write the CSV string to a file
    try csvString.write(to: csvPath, atomically: true, encoding: .utf8)
    
    return csvPath
}


func createExcel(from products: [ProductModel]) throws -> URL {
    let headers = "Name,Category,Brand,Size,Price,Flavor,Stock\n"
    var csvString = headers
    
    for product in products {
        // Break down each field into a simple string variable
        let name = product.name ?? ""
        let category = product.category ?? ""
        let brand = product.brand ?? ""
        let size = product.size ?? ""
        let price = String(product.price ?? 0)
        let flavor = product.flavourType ?? ""
        let stock = String(product.stock ?? 0)

        // Now construct the row string
        let row = "\(name),\(category),\(brand),\(size),\(price),\(flavor),\(stock)\n"
        
        // Append it to the main CSV string
        csvString.append(contentsOf: row)
    }
    
    let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    let csvPath = documentsPath.appendingPathComponent("ProductInventory.xlsx")
    // Write the CSV string to a file
    try csvString.write(to: csvPath, atomically: true, encoding: .utf8)
    
    return csvPath
}

func createPDF(from products: [ProductModel]) throws -> URL {
    let pdfDocument = PDFDocument()
    let pdfPage = PDFPage()
    let pageBounds = CGRect(x: 0, y: 0, width: 612, height: 792)  // Standard US Letter size
    pdfPage.setBounds(pageBounds, for: .mediaBox)

    let renderer = UIGraphicsImageRenderer(bounds: pageBounds)
    let imageData = renderer.pngData { ctx in
        let context = ctx.cgContext
        context.saveGState()  // Save the graphic state
        drawTableHeader(in: context, pageBounds: pageBounds)
        drawTableContent(products, in: context, pageBounds: pageBounds)
        context.restoreGState()  // Restore the graphic state
    }

    if let image = UIImage(data: imageData), let page = PDFPage(image: image) {
        pdfDocument.insert(page, at: 0)
    }

    let fileManager = FileManager.default
    let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
    let fileURL = documentsURL.appendingPathComponent("ProductDetails.pdf")

    pdfDocument.write(to: fileURL)

    return fileURL
}

func drawTableHeader(in context: CGContext, pageBounds: CGRect) {
    let headers = ["Name", "Category", "Brand", "Size", "Price", "Flavor", "Stock"]
    let columnWidth = pageBounds.width / CGFloat(headers.count)

    headers.enumerated().forEach { index, text in
        let frame = CGRect(x: CGFloat(index) * columnWidth, y: 20, width: columnWidth, height: 24)
        drawText(text, in: frame, context: context)
    }
}

func drawTableContent(_ products: [ProductModel], in context: CGContext, pageBounds: CGRect) {
    let rowHeight: CGFloat = 20
    let columnWidth = pageBounds.width / CGFloat(7)  // Assuming 7 columns based on headers
    var yOffset: CGFloat = 44  // Start below the header

    products.forEach { product in
        let productDetails = [
            product.name ?? "",
            product.category ?? "",
            product.brand ?? "",
            product.size ?? "",
            "\(product.price ?? 0)",
            product.flavourType ?? "",
            "\(product.stock ?? 0)"
        ]

        productDetails.enumerated().forEach { index, detail in
            let frame = CGRect(x: CGFloat(index) * columnWidth, y: yOffset, width: columnWidth, height: rowHeight)
            drawText(detail, in: frame, context: context)
        }
        yOffset += rowHeight
    }
}

func drawText(_ text: String, in frame: CGRect, context: CGContext) {
    let attributes: [NSAttributedString.Key: Any] = [
        .font: UIFont.systemFont(ofSize: 12),
        .foregroundColor: UIColor.black
    ]
    let attributedString = NSAttributedString(string: text, attributes: attributes)
    attributedString.draw(in: frame)
}

