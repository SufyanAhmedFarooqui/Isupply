//
//  TopSeller.swift
//  iSupply
//
//  Created by hassan ghouri on 28/04/2024.
//

import SwiftUI

struct TopSeller: View {
    // Dummy data for preview purposes
    let userImageUrl = "https://picsum.photos/200"
    let userName = "No Seller Yet"
    let direct = "914.645.6940"
    let username = "XYZ"
    let password = "9292"
    let address = "1223 Alemany St"
    let cityStateZip = "Morrisville, NC 27560"
    let email = "abc@gmail.com"
    @State private var showUserDetails:Bool
    @StateObject var viewModel = UserViewModel()
    var user:UserModel?
    @State private var navigationToUpdateScreen = false
    @State private var navigationToMapScreen = false
    
    init(showUserDetails: Bool, user:UserModel) {
        self.showUserDetails = showUserDetails
        self.user = user
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                // Handling avatar images
                if let avatarImage = viewModel.topSeller?.avatar, !avatarImage.isEmpty {
                    AsyncImage(url: URL(string: Constants.imageBaseUrl + avatarImage)) { image in
                        image.resizable().aspectRatio(contentMode: .fill)
                    } placeholder: {
                        Color.gray.frame(width: 100, height: 100).clipShape(Circle())
                    }
                    .frame(width: 100, height: 100)
                    .clipShape(Circle())
                    .padding(.top, 20)
                }else {
                    // Default avatar image when there's no avatar or empty string
                    AsyncImage(url: URL(string: Constants.imageBaseUrl + "avatar.jpeg")) { image in
                        image.resizable().aspectRatio(contentMode: .fill)
                    } placeholder: {
                        Color.gray.frame(width: 100, height: 100).clipShape(Circle())
                    }
                    .frame(width: 100, height: 100)
                    .clipShape(Circle())
                    .padding(.top, 20)
                }
                
                // User Details
                VStack(alignment: .leading, spacing: 8) {
                    Text(viewModel.topSeller?.name ?? userName)
                        .font(.title)
                        .fontWeight(.bold)
                    
                    Label(viewModel.topSeller?.telephone ?? direct, systemImage: "phone.fill")
                    Label(viewModel.topSeller?.userName ?? userName, systemImage: "person.fill")
                    Label(viewModel.topSeller?.direct ?? password, systemImage: "lock.fill")
                    Label(viewModel.topSeller?.address ?? address, systemImage: "house.fill")
                    Label(viewModel.topSeller?.city  ?? cityStateZip, systemImage: "map.fill")
                    Label(viewModel.topSeller?.email ?? email, systemImage: "envelope.fill")
                }
                .padding(.horizontal)
                .padding(.bottom, 20)
            }
            if(viewModel.topSeller?.role == "Customer" || viewModel.topSeller?.role == "Vendor"){
                NavigationLink {
                    LocationMapView(latitude: viewModel.topSeller?.storeLocation?.lat ?? 0, longitude: viewModel.topSeller?.storeLocation?.lat ?? 0, name: viewModel.topSeller?.name ?? "Unnamed")
                } label: {
                    Text("Show Store Location")
                }
            }
            

    }
        .navigationTitle("Users Detail")
        .toolbar(content: {
            
            Button {
                // Action based on condition
                if(showUserDetails){
                    navigationToUpdateScreen = true
                }else{
                    navigationToMapScreen = true
                }
            } label: {
                Image(systemName: showUserDetails ? "pencil" : "location.fill")
            }
        })
        .onAppear{
            if(!showUserDetails) {
                viewModel.getTopSeller()
            }else{
                viewModel.getUsers(email: user?.email ?? "", route: "getUserByEmail")
            }
        }
        .navigationBarBackButtonHidden(false)
        .navigationDestination(isPresented: $navigationToUpdateScreen, destination: {
            UpdateUser(user: user!, profile: false)
        })
        .navigationDestination(isPresented: $navigationToMapScreen) {
            LocationMapView(latitude: viewModel.topSeller?.currentLocation?.lat ?? 34.64, longitude: viewModel.topSeller?.currentLocation?.lng ?? -112.45, name: viewModel.topSeller?.name ?? "")
        }
    }
}

struct TopSeller_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            TopSeller(showUserDetails: false, user:UserModel(userName:"", email: "abc@gmail.com", password:"123"))
        }
    }
}
