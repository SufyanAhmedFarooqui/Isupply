//
//  CheckUser.swift
//  iSupply
//
//  Created by hassan ghouri on 09/03/2024.
//

import SwiftUI

struct CheckUser: View {
    @State private var email = ""
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @State private var alertItem: AlertType?
    @State private var isLoading = false
    @State private var navigateToAddUser = false
    @Environment(\.presentationMode) var presentationMode
    let apiManager = UsersAPI.sharedInstance
    var body: some View {
        NavigationStack {
            VStack {
                Spacer()
                InputView(text: $email, title: "Email", placeholder:"Enter Email of User")
                Button(action: {
                    checkUser()
                }, label: {
                    Text("Add User")
                }).padding()
                Spacer()
            }.padding(.horizontal)
        }.navigationDestination(isPresented: $navigateToAddUser) {
            AddUser(prevEmail:email)
        }
        .alert(item: $alertItem) { alertType in
            switch alertType {
            case .error(let message):
                return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
            case .success(let message):
                return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                    // Navigate to previous screen
                    presentationMode.wrappedValue.dismiss()
                }, secondaryButton: .cancel())
            }
        }
    }
    
    func checkUser(){
        if(!formIsValid){
            alertItem = .error(message: "Enter Email and Password they are necessary")
            return
        }
        Task {
            isLoading = true
            apiManager.checkUser(email: email, userEmail: userEmail, userRole: userRole) { result in
                switch result {
                case let .success(success):
                    if success {
                        isLoading = false
                        alertItem = .success(message: "User Created Successfully!")
                    } else {
                        isLoading = false
                        navigateToAddUser = true
                    }
                case let .failure(error):
                    // Handle the error
                    isLoading = false
                    alertItem = .error(message:error.localizedDescription)
                                                       
                }
            }
        }
    }
}

// Mark: - AuthenticationFormProtocol

extension CheckUser:AuthenticationFormProtocol {
    var formIsValid: Bool {
        return !email.isEmpty
        && email.contains("@")
    }
}


#Preview {
    CheckUser()
}
