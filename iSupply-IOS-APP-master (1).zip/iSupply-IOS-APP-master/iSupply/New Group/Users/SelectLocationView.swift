import SwiftUI
import MapKit


struct SelectLocationView: View {
    @StateObject private var viewModel = LocationViewModel()
    @State private var isLoading = false
    @State private var alertItem: AlertType?
    let apiManager = UsersAPI.sharedInstance
    @Environment(\.presentationMode) var presentationMode
    var email: String?
    
    var body: some View {
        NavigationStack {
            if isLoading {
                LoadingView()
            } else {
                content
                    .alert(item: $alertItem, content: alert)
                    .onAppear {
                        viewModel.checkIfLocationServicesEnabled()
                    }
            }
        }
    }
    
    private var content: some View {
        NavigationStack{
            ZStack {
                    MapView(viewModel: viewModel)
                    Image("pin")
                    .frame(width: 40, height: 40, alignment: .center)
                VStack {
                    Spacer() // Pushes everything below it to the bottom
                    Text("Latitude: \(viewModel.centerCoordinate?.latitude ?? 0)")
                        .foregroundColor(.black)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.white.opacity(0.85))
                        .clipShape(RoundedRectangle(cornerRadius: 0))
                    
                    Button("Select Location") {
                        saveLocationToDatabase()
                    }
                    .disabled(viewModel.centerCoordinate == nil)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.white.opacity(0.85))
                    .clipShape(RoundedRectangle(cornerRadius: 0))
                }
            }
            
        }
        
        
    }
    
    private func saveLocationToDatabase() {
        guard let coordinate = viewModel.centerCoordinate else { return }
        isLoading = true
        apiManager.saveLocationToDatabase(email: email ?? "default@email.com", lat: coordinate.latitude, lng: coordinate.longitude, route: "updateStoreLocation") { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success:
                    self.alertItem = .success(message: "Saved Store Location")
                case .failure(let error):
                    self.alertItem = .error(message: error.localizedDescription)
                }
            }
        }
    }
    private func alert(for type: AlertType) -> Alert {
            switch type {
            case .error(let message):
                return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
            case .success(let message):
                return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                    presentationMode.wrappedValue.dismiss()
                }, secondaryButton: .cancel())
            }
        }
}



// Preview
struct SelectLocationView_Previews: PreviewProvider {
    static var previews: some View {
        SelectLocationView()
    }
}


struct MapView: UIViewRepresentable {
    @ObservedObject var viewModel: LocationViewModel
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        // Center the map once when the view is created
        mapView.setRegion(viewModel.region, animated: true)
        
        return mapView
    }

    func updateUIView(_ mapView: MKMapView, context: Context) {
        // No further action to recenter the map in updateUIView
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(viewModel: viewModel)
    }

    class Coordinator: NSObject, MKMapViewDelegate {
        var viewModel: LocationViewModel

        init(viewModel: LocationViewModel) {
            self.viewModel = viewModel
        }

        func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
            // Update the viewModel with the new center coordinate when user manually changes map region
            DispatchQueue.main.async {
                self.viewModel.centerCoordinate = mapView.centerCoordinate
            }
        }
    }
}
