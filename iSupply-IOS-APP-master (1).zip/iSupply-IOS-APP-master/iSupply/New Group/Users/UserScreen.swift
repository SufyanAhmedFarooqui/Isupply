//
//  UserScreen.swift
//  iSupply
//
//  Created by hassan ghouri on 04/02/2024.
//

import SwiftUI

struct UserScreen: View {
    @State private var searchTerm = ""
    @State private var Users:[UserModel] = []
    @State private var showOnlyVendors = false
    @State private var showOnlyCustomers = false
    @State private var showOnlySeller = false
    @State private var backColor = Color(red: 0.92, green: 0.11, blue: 0.18).opacity(0.6)
    @State private var changedColor = Color(red: 0.17, green: 0.19, blue: 0.58).opacity(0.8)
    @StateObject private var viewModel = UserViewModel()
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    var requested:Bool?
    var body: some View {
        NavigationStack{
            VStack(alignment: .leading){
                if(userRole == "Vendor" || userRole == "Admin"){
                ZStack {
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 359, height: 64)
                        .background(Color(red: 0.97, green: 0.96, blue: 0.96))
                        .cornerRadius(15)
                        HStack{
                            Button {
                                showOnlyVendors = false
                                showOnlyCustomers = true
                                showOnlySeller = false
                            } label: {
                                ZStack{
                                    Rectangle()
                                        .foregroundColor(.clear)
                                        .frame(width: 96, height: 46)
                                        .background(showOnlyCustomers ? changedColor:backColor)
                                        .cornerRadius(15)
                                    Text("Customer")
                                        .font(
                                            Font.custom("Manrope", size: 14)
                                                .weight(.semibold)
                                        )
                                        .foregroundColor(.white)
                                }
                            }
                            if(userRole == "Admin"){
                                Button {
                                    showOnlyVendors = true
                                    showOnlyCustomers = false
                                    showOnlySeller = false
                                } label: {
                                    ZStack{
                                        Rectangle()
                                            .foregroundColor(.clear)
                                            .frame(width: 96, height: 46)
                                            .background(showOnlyVendors ? changedColor:backColor)
                                            .cornerRadius(15)
                                        Text("Vendor")
                                            .font(
                                                Font.custom("Manrope", size: 14)
                                                    .weight(.semibold)
                                            )
                                            .foregroundColor(.white)
                                    }
                                }
                            }
                            if(userRole == "Vendor" || userRole == "Admin"){
                                Button {
                                    showOnlyVendors = false
                                    showOnlyCustomers = false
                                    showOnlySeller = true
                                } label: {
                                    ZStack{
                                        Rectangle()
                                            .foregroundColor(.clear)
                                            .frame(width: 123, height: 46)
                                            .background(showOnlySeller ? changedColor:backColor)
                                            .cornerRadius(15)
                                        Text("Salesperson")
                                            .font(
                                                Font.custom("Manrope", size: 14)
                                                    .weight(.semibold)
                                            )
                                            .foregroundColor(.white)
                                    }
                                    
                                }
                            }
                        }
                    }
                }
               if (userRole != "Customer" && requested == nil) {
                    HStack{
                        Spacer()
                        NavigationLink {
                            if(userRole == "Vendor"){
                                CheckUser()
                            }else{
                                AddUser()
                            }
                            
                        } label: {
                            ZStack(alignment: .center, content: {
                                Rectangle()
                                    .foregroundColor(.clear)
                                    .frame(width: 126.00653, height: 44.25)
                                    .background(Color(red: 0.17, green: 0.19, blue: 0.58).opacity(0.8))
                                    .cornerRadius(20)
                                
                                Text(userRole == "Sales Person" ? "Add Customer":"Add User")
                                    .font(
                                        Font.custom("Manrope", size: 17)
                                            .weight(.semibold)
                                    )
                                    .foregroundColor(.white)
                                    .frame(width: 120, height: 32, alignment: .center)
                            })
                        }
                        
                    }
                }

                List(filteredUsers, id: \.email) { user in
                    NavigationLink {
                        if requested != nil {
                            RequestedOrders(customerEmail: user.email,requested: true)
                        }else {
                            TopSeller(showUserDetails: true, user: user)
                        }
                    } label: {
                        UserCell(user: user)
                    }
                }                
            }.padding(.horizontal)
            .navigationTitle("User Details")
                .searchable(text: $searchTerm, prompt: "Search for selected Users")
            Spacer()
        }
        .onAppear{
            viewModel.getUsers(email: userEmail,route:"getUsersByEmail")
            if (userRole == "Sales Person"){
                showOnlyCustomers = true
            }else if (userRole == "Vendor") {
                showOnlyCustomers = true
                showOnlySeller = true
            }
        }
        if (viewModel.isLoading){ LoadingView()}
    }
    
    var filteredUsers: [UserModel] {
        
        var filteredArray = viewModel.users

            if showOnlyCustomers {
                filteredArray = filteredArray.filter { $0.role == "Customer" }
            } else if showOnlyVendors {
                filteredArray = filteredArray.filter { $0.role == "Vendor" }
            } else if showOnlySeller {
                filteredArray = filteredArray.filter { $0.role == "Sales Person" }
            }

            if !searchTerm.isEmpty {
                filteredArray = filteredArray.filter { user in
                    user.email!.lowercased().contains(searchTerm.lowercased()) ||
                    user.name!.lowercased().contains(searchTerm.lowercased())
                }
            }

            return filteredArray
}

}

#Preview {
    UserScreen()
}


