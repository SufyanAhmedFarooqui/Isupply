//
//  UserViewModel.swift
//  iSupply
//
//  Created by hassan ghouri on 19/02/2024.
//

import Foundation

final class UserViewModel: ObservableObject {
    @Published var users:[UserModel] = []
    @Published var topSeller: UserModel?
    @Published var isLoading = false
    @Published var alertItem: AlertItem?
    @Published var truckStock:String?
    func getUsers(email:String,route:String) {
        isLoading = true
        UsersAPI.sharedInstance.getUserByEmail(email: email,route:route, completion: { [self] result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let users):
                    self.users = users
                    if (!users.isEmpty){
                        self.topSeller = users.first
                    }
                case .failure(_):
                    self.alertItem = AlertItem(title: "Cannot get Users", message: "Check your Internet Connection")
                }
                
            }
            
        })
    }
    func getUserDetailsforInvoice(vendorEmail:String, customerEmail:String,route:String) {
        isLoading = true
        UsersAPI.sharedInstance.getUserDetailsForInvoice(vendorEmail: vendorEmail,customerEmail:customerEmail,route:route, completion: { [self] result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let users):
                    self.users = users
                case .failure(_):
                    self.alertItem = AlertItem(title: "Cannot get Users", message: "Check your Internet Connection")
                }
                
            }
        })
    }
    func getTruckStockByProductId(productId:String){
        isLoading = true
        UsersAPI.sharedInstance.getTruckStockByProductId(productId: productId, completion: { [self] result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let stock):
                    self.truckStock = stock
                case .failure(_):
                    self.alertItem = AlertItem(title: "Cannot get Users", message: "Check your Internet Connection")
                }
                
            }
        })
    }
    func getTopSeller(){
        isLoading = true
        UsersAPI.sharedInstance.getTopSeller(completion: { [self] result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let user):
                    self.topSeller = user
                case .failure(_):
                    self.alertItem = AlertItem(title: "Cannot get Users", message: "Check your Internet Connection")
                }
                
            }
        })
    }
}
