//
//  ForgotPassword.swift
//  iSupply
//
//  Created by hassan ghouri on 31/01/2024.
//

import SwiftUI

struct ForgotPassword: View {
    @State private var email = ""
    @Environment(\.presentationMode) var presentationMode
    @State private var alertItem: AlertType?
    @State private var isLoading: Bool = false
    
    let apiManager = UsersAPI.sharedInstance
    
    var body: some View {
        NavigationStack{
            VStack(spacing: 25, content: {
                Image("forgotPassword")
                    .frame(width: 245, height: 229, alignment: .center)
                Text("Forgot password?")
                  .font(
                    Font.custom("Manrope", size: 22)
                      .weight(.heavy)
                  )
                  .foregroundColor(Color(red: 0.17, green: 0.19, blue: 0.58))
                  .frame(width: 212.744, height: 34.62561, alignment: .leading)
                  
                Text("Enter your email address below and we'll send you an email with a reset Link to change your password")
                  .font(Font.custom("Manrope", size: 14))
                  .foregroundColor(Color(red: 0.01, green: 0.01, blue: 0.01))
                  .frame(width: 266.19199, height: 56.6601, alignment: .topLeading)
                InputView(text: $email, title: "Email", placeholder: "name@example.com", isSecureField: false)
                    .autocapitalization(.none)
                    .padding(.horizontal)
                Button(action: {
                    Task {
                        isLoading = true
                        apiManager.resetPasswordAndDelete(email: email, route:"requestPasswordReset") { result in
                                switch result {
                                case let .success(success):
                                    isLoading = false
                                    alertItem = .success(message: success.message ?? "Reset Link Sent")
                                case .failure(_):
                                    // Handle the error
                                    isLoading = false
                                    alertItem = .error(message: "Email doesnot exist or " + "Check Your Internet Connection")
                                }
                            }
                    }
                }, label: {
                    ZStack {
                        Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 244, height: 61)
                            .background(Color(red: 0.92, green: 0.11, blue: 0.18))
                            .cornerRadius(100)
                        
                        Text("Recover Password")
                            .font(
                                Font.custom("Manrope", size: 22)
                                    .weight(.heavy)
                            )
                            .multilineTextAlignment(.center)
                            .foregroundColor(.white)
                            .frame(width: 234.752, height: 22.03448, alignment: .top)
                    }.padding(.vertical)
                })
                
            })
        }.alert(item: $alertItem) { alertType in
            switch alertType {
            case .error(let message):
                return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
            case .success(let message):
                return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                    // Navigate to previous screen
                    presentationMode.wrappedValue.dismiss()
                }, secondaryButton: .cancel())
            }
        }
    }
}

#Preview {
    ForgotPassword()
}
