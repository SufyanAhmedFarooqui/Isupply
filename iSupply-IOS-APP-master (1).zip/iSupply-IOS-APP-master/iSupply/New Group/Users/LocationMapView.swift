import SwiftUI
import MapKit

struct LocationMapView: View {
    var latitude: Double
    var longitude: Double
    var name:String
    @State private var region: MKCoordinateRegion

    init(latitude: Double, longitude: Double, name:String) {
        self.latitude = latitude
        self.longitude = longitude
        self.name = name
        _region = State(initialValue: MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: latitude, longitude: longitude),
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        ))
    }

    var body: some View {
        Map(coordinateRegion: $region, annotationItems: [MapPin(coordinate: CLLocationCoordinate2D(latitude: latitude, longitude: longitude))]) { pin in
            MapAnnotation(coordinate: pin.coordinate) {
                MapPinView(name:name)
            }
        }
        .navigationTitle("Location")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            // Center the map on the provided coordinates
            region.center = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        }
    }
}

struct MapPin: Identifiable {
    let coordinate: CLLocationCoordinate2D
    var id: String {
        "\(coordinate.latitude),\(coordinate.longitude)"
    }
}

struct MapPinView: View {
    var name:String
    var body: some View {
        VStack {
            Image(systemName: "mappin.and.ellipse.circle.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 30, height: 30)
                .foregroundColor(.red)
            Text(name)
                .fixedSize()
        }
    }
}

struct LocationMapView_Previews: PreviewProvider {
    static var previews: some View {
        LocationMapView(latitude: 40.7128, longitude: -74.0060, name:"Here")
    }
}
