//
//  AddUser.swift
//  iSupply
//
//  Created by hassan ghouri on 04/02/2024.
//
import PhotosUI
import SwiftUI

struct AddUser: View {
    var prevEmail:String?
    @Environment(\.presentationMode) var presentationMode
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @State private var name = ""
    @State private var email = ""
    @State private var telephone = ""
    @State private var accNumber = ""
    @State private var bussinessName = ""
    @State private var city = ""
    @State private var direct = ""
    @State private var contactPersonName = ""
    @State private var userName = ""
    @State private var password = ""
    @State private var address = ""
    @State private var userType = "Customer"
    @State private var isLoading = false
    @State private var avatarImage: UIImage?
    @State private var photosPickerItemInitial = true
    @State private var photosPickerItem: PhotosPickerItem?
    @State private var alertItem: AlertType?
    let apiManager = UsersAPI.sharedInstance
    var body: some View {
        NavigationStack{
            ZStack {
                if (isLoading){
                    LoadingView()
                }
                ScrollView {
                    VStack {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack{
                                Text("User Details")
                                    .font(
                                        Font.custom("Manrope", size: 18)
                                            .weight(.semibold)
                                    )
                                    .kerning(0.054)
                                    .foregroundColor(Color(red: 0.53, green: 0.53, blue: 0.53))
                                Spacer()
                                PhotosPicker(selection: $photosPickerItem, matching: .images) {
                                    Image(uiImage: avatarImage ?? UIImage(resource: .avatar))
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(width: 100,height: 100)
                                        .clipShape(.circle)
                                    
                                }
                            }
                            
                        }
                        
                        InputView(text: $name, title: "Name", placeholder: "Enter Name")
                        InputView(text: $email, title: "Email", placeholder: "Enter Email")
                        InputView(text: $telephone, title: "Telephone", placeholder: "Enter Telephone Number")
                        InputView(text: $accNumber, title: "Account number", placeholder: "Enter Account Number")
                        InputView(text: $bussinessName, title: "Business Name", placeholder: "Enter Business Name")
                        InputView(text: $city, title: "City", placeholder: "City , States, Zip ")
                        InputView(text: $contactPersonName, title: "Contact Name", placeholder: "XYZ")
                        InputView(text: $direct, title: "Direct #", placeholder: "Direct Number")
                        InputView(text: $userName, title: "Username", placeholder: "Xyz")
                        InputView(text: $password, title: "Password", placeholder: "*******",isSecureField: true)
                        InputView(text: $address, title: "Address", placeholder: "ABC Road XYZ Place")

                        VStack(alignment: .leading){
                            HStack(alignment: .center, spacing: 20){
                                Text("User Type")
                                    .frame(width:100)
                                Spacer()
                                Divider()
                                Spacer()
                                Picker("User", selection: $userType) {
                                    if(userRole == "Admin"){
                                        Text("Vendor").tag("Vendor")
                                        Text("Sales Person").tag("Sales Person")
                                        Text("Customer").tag("Customer")
                                    }else if (userRole == "Vendor"){
                                        Text("Sales Person").tag("Sales Person")
                                        Text("Customer").tag("Customer")
                                    }else {
                                        Text("Customer").tag("Customer")
                                    }
                                    
                                }
                            }
                            
                            Divider()
                        }
                    }.alert(item: $alertItem) { alertType in
                        switch alertType {
                        case .error(let message):
                            return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
                        case .success(let message):
                            return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                                // Navigate to previous screen
                                presentationMode.wrappedValue.dismiss()
                            }, secondaryButton: .cancel())
                        }
                    }
                    }.padding(.horizontal)
                    .onChange(of: photosPickerItem) { newPhotosPickerItem in
                        if photosPickerItemInitial {
                            // Handle initial value (optional)
                            Task {
                                if let photosPickerItem = newPhotosPickerItem {
                                    do {
                                        let data = try await photosPickerItem.loadTransferable(type: Data.self)
                                        if let image = UIImage(data: data!) {
                                            avatarImage = image
                                        }
                                    } catch {
                                        // Handle error
                                        print("Error loading photos picker item:", error)
                                    }
                                }
                            }
                        }
                    }
                    .onAppear{
                        if let providedEmail = prevEmail {
                            email = providedEmail
                        }
                    }
                    
            }
            
    }.navigationTitle("Add User")
            .toolbar {
                Button("Add +") {
                    if(!formIsValid){
                        alertItem = .error(message: "Enter Email and Password they are necessary")
                        return
                    }else if (!passIsValid){
                        alertItem = .error(message: "Password Must be 6 characters Long")
                        return
                    }
                    Task {
                        isLoading = true
                        createUser()
                        }
                        }
                }
            
            
        }
    func createUser(){
        let user = UserModel(userName: userName, email: email, password: password, telephone:telephone , accNumber: accNumber, businessName: bussinessName, city: city, direct: direct, contactPersonName: contactPersonName, name: name, address: address, role: userType, createdBy:userEmail,associatedUsers:[AssociatedUsers(email: userEmail, role: userRole)])
        apiManager.signUpApi(user: user, image: avatarImage,route:"addUser", completion: { result in
                switch result {
                case let .success(success):
                    if success {
                        isLoading = false
                        alertItem = .success(message: "User Created Successfully!")
                    } else {
                        isLoading = false
                        // Handle unsuccessful login or role mismatch
                        alertItem = .error(message: "Email, Password and Username are required.")
                    }
                case .failure(_):
                    // Handle the error
                    isLoading = false
                    alertItem = .error(message:"Check your internet connection. or Email already exist")
                                                       
                }
            })
    }
        
    }

// Mark: - AuthenticationFormProtocol

extension AddUser:AuthenticationFormProtocol {
    var formIsValid: Bool {
        return !email.isEmpty
        && email.contains("@")
        && !password.isEmpty
        && password.count > 5
    }
    var passIsValid: Bool {
        return password.count > 5
    }
}

#Preview {
    AddUser()
}
