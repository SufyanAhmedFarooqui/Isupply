//
//  ExploreUsers.swift
//  iSupply
//
//  Created by hassan ghouri on 13/03/2024.
//

import SwiftUI

struct ExploreUsers: View {
    var body: some View {
        NavigationStack{
            VStack{
                HStack(alignment: .center, spacing: 20) {
                    NavigationLink {
                        UserScreen()
                    } label: {
                        MainPageCard(title: "View Users", imageName: "box.truck.fill", backColor: Color(red: 0.46, green: 0.41, blue: 0.87).opacity(0.25))
                    }
                    NavigationLink {
                        SelectSalesPerson()
                    } label: {
                        MainPageCard(title: "Assign Customers", imageName: "basket.fill", backColor: Color(red: 0.69, green: 0.87, blue: 0.32).opacity(0.25))
                    }
                }
            }
        }.navigationTitle("Explore Users")
    }
}

#Preview {
    ExploreUsers()
}
