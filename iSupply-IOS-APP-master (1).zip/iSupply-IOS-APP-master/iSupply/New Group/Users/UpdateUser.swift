//
//  UpdateUser.swift
//  iSupply
//
//  Created by hassan ghouri on 05/02/2024.
//

import SwiftUI
import PhotosUI
struct UpdateUser: View {
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    let user: UserModel
    @Environment(\.presentationMode) var presentationMode
    @State private var name:String
    @State private var email:String
    @State private var telephone:String
    @State private var accNumber:String
    @State private var businessName:String
    @State private var city:String
    @State private var direct:String
    @State private var contactPersonName:String
    @State private var userName:String
    @State private var address:String
    @State private var userType:String
    @State private var avatar:String
    @State private var isLoading = false
    @State private var avatarImage: UIImage?
    @State private var photosPickerItemInitial = true
    @State private var photosPickerItem: PhotosPickerItem?
    @State private var alertItem: AlertType?
    @State private var isProfile:Bool
    let apiManager = UsersAPI.sharedInstance
    
    init(user: UserModel, profile:Bool?) {
            self.user = user
            _name = State(initialValue: user.name ?? "")
            _email = State(initialValue: user.email ?? "")
            _telephone = State(initialValue: user.telephone ?? "")
            _accNumber = State(initialValue: user.accNumber ?? "")
            _businessName = State(initialValue: user.businessName ?? "")
            _city = State(initialValue: user.city ?? "")
            _direct = State(initialValue: user.direct ?? "")
            _contactPersonName = State(initialValue: user.contactPersonName ?? "")
            _userName = State(initialValue: user.userName ?? "")
            _address = State(initialValue: user.address ?? "")
            _userType = State(initialValue: user.role ?? "")
            _avatar = State(initialValue: user.avatar ?? "")
            _isProfile = State(initialValue: profile ?? false)
        }
    var body: some View {
        NavigationStack{
            ScrollView {
                ZStack {
                    if (isLoading){
                        LoadingView()
                    }
                    VStack(alignment: .center, spacing: 10) {
                        
                        UserHeaderView(
                            isLoading: $isLoading,
                            avatarImage: $avatarImage,
                            avatar: avatar,
                            photosPickerItem: $photosPickerItem
                        )
                        TextFieldWithBorder(text: "Name", placeholder: "Name", value: $name)
                        VStack(alignment: .leading) {
                            HStack(alignment: .center, spacing: 20){
                                Text("Email")
                                    .frame(width: 120)
                                Spacer()
                                Divider()
                                Spacer()
                                Text(email)
                            }
                            Divider()
                        }
                        TextFieldWithBorder(text: "Phone", placeholder: "Phone", value: $telephone)
                        TextFieldWithBorder(text: "Acc. No", placeholder: "Acc. No", value: $accNumber)
                        TextFieldWithBorder(text: "Business Name", placeholder: "Business Name", value: $businessName)
                        TextFieldWithBorder(text: "City", placeholder: "City", value: $city)
                        TextFieldWithBorder(text: "Contact Name", placeholder: "Contact Person", value: $contactPersonName)
                        TextFieldWithBorder(text: "Direct #", placeholder: "Direct Number", value: $direct)
                        TextFieldWithBorder(text: "UserName", placeholder: "UserName", value: $userName)
                        TextFieldWithBorder(text: "Address", placeholder: "Address", value: $address)
                        if(user.role == "Customer" || user.role == "Vendor"){
                            NavigationLink {
                                SelectLocationView(email:email)
                            } label: {
                                Text("Select Store Location")
                            }
                        }
                        VStack(alignment: .leading){
                            HStack(alignment: .center, spacing: 20){
                                Text("User Type")
                                    .frame(width:100)
                                Spacer()
                                Divider()
                                Spacer()
                                Picker("User", selection: $userType) {
                                    if(isProfile){
                                        Text(userType).tag(userType)
                                    }else if(userRole == "Admin"){
                                        Text("Vendor").tag("Vendor")
                                        Text("Sales Person").tag("Sales Person")
                                        Text("Customer").tag("Customer")
                                    }else if (userRole == "Vendor"){
                                        Text("Sales Person").tag("Sales Person")
                                        Text("Customer").tag("Customer")
                                    }else {
                                        Text("Customer").tag("Customer")
                                    }
                                }
                            }
                            if(!isProfile){
                                HStack(alignment: .center) {
                                    Spacer()
                                    Button {
                                        deleteUser()
                                    } label: {
                                        ZStack{
                                            Rectangle()
                                                .foregroundColor(.clear)
                                                .frame(width: 125, height: 40)
                                                .background(Color(red: 0.6, green: 0.1, blue: 0.1).opacity(0.8))
                                                .cornerRadius(20)
                                            Text("Delete")
                                                .font(
                                                    Font.custom("Manrope", size: 17)
                                                        .weight(.semibold)
                                                )
                                                .multilineTextAlignment(.center)
                                                .foregroundColor(.white)
                                                .frame(width: 90, height: 20, alignment: .top)
                                        }
                                    }
                                    
                                }
                            }
                            Divider()
                            if(isProfile){
                                HStack(alignment: .center) {
                                    Spacer()
                                    Button {
                                        updateUser()
                                    } label: {
                                        ZStack{
                                            Rectangle()
                                              .foregroundColor(.clear)
                                              .frame(width: 125, height: 40)
                                              .background(Color(red: 0.17, green: 0.19, blue: 0.58).opacity(0.8))
                                              .cornerRadius(20)
                                            Text("Update")
                                              .font(
                                                Font.custom("Manrope", size: 17)
                                                  .weight(.semibold)
                                              )
                                              .multilineTextAlignment(.center)
                                              .foregroundColor(.white)
                                              .frame(width: 90, height: 20, alignment: .top)
                                        }
                                    }

                                }
                            }
                            
                    }
                        .alert(item: $alertItem) { alertType in
                            switch alertType {
                            case .error(let message):
                                return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
                            case .success(let message):
                                return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                                    // Navigate to previous screen
                                    presentationMode.wrappedValue.dismiss()
                                }, secondaryButton: .cancel())
                            }
                        }
                    }
                    .padding(.horizontal)
                    .onChange(of: photosPickerItem) { newPhotosPickerItem in
                        if photosPickerItemInitial {
                            Task {
                                if let photosPickerItem = newPhotosPickerItem {
                                    do {
                                        let data = try await photosPickerItem.loadTransferable(type: Data.self)
                                        if let image = UIImage(data: data!) {
                                            avatarImage = image
                                        }
                                    } catch {
                                        // Handle error
                                        print("Error loading photos picker item:", error)
                                    }
                                }
                            }
                        }
                }
                }
            }
    }.navigationTitle("View User")
            .toolbar {
                if(!isProfile){
                Button("Update") {
                    updateUser()
                }
            }
        }
        }
    func deleteUser(){
        Task {
            isLoading = true
            apiManager.resetPasswordAndDelete(email: email, route:"deleteUser") { result in
                    switch result {
                    case let .success(success):
                        isLoading = false
                        alertItem = .success(message: success.message ?? "User Deleted Successfully")
                    case let .failure(error):
                        // Handle the errorn
                        isLoading = false
                        alertItem = .error(message: error.localizedDescription + "Check Your Internet Connection")
                    }
                }
        }
    }
    func updateUser(){
        if(!formIsValid){
            alertItem = .error(message: "Enter Email and Password they are necessary")
            return
        }
        Task {
            isLoading = true
            let user = UserModel(userName: userName, email: email,password:"", telephone:telephone, accNumber: accNumber, businessName: businessName, city: city, direct: direct, contactPersonName: contactPersonName, name: name, address: address, role: userType)
            apiManager.signUpApi(user: user, image: avatarImage,route:"updateUser", completion: { result in
                switch result {
                case let .success(success):
                    if success {
                        isLoading = false
                        alertItem = .success(message: "User Updated Successfully!")
                    } else {
                        isLoading = false
                        // Handle unsuccessful login or role mismatch
                        alertItem = .error(message: "Email and Username are required.")
                    }
                case let .failure(error):
                    // Handle the error
                    isLoading = false
                    alertItem = .error(message: "Check Your internet Connection" + error.localizedDescription)
                    
                }
            })
        }
    }
}

// Mark: - AuthenticationFormProtocol

extension UpdateUser:AuthenticationFormProtocol {
    var formIsValid: Bool {
        return !email.isEmpty
        && email.contains("@")
    }

}

struct UserHeaderView: View {
    @Binding var isLoading: Bool
    @Binding var avatarImage: UIImage?
    var avatar: String
    @Binding var photosPickerItem: PhotosPickerItem?
    
    var body: some View {
        // Header view content
        HStack{
            Text("User Details")
                .font(
                    Font.custom("Manrope", size: 18)
                        .weight(.semibold)
                )
                .kerning(0.054)
                .foregroundColor(Color(red: 0.53, green: 0.53, blue: 0.53))
            Spacer()
            PhotosPicker(selection: $photosPickerItem, matching: .images) {
                if let avatarImage = avatarImage {
                    Image(uiImage: avatarImage)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 100, height: 100)
                        .clipShape(Circle())
                }else if avatar != "" {
                    AsyncImage(url: URL(string: Constants.imageBaseUrl+avatar)) { phase in
                        switch phase {
                        case .empty:
                            Image("avatar")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 100, height: 100)
                                .clipShape(Circle())
                        case .success(let image):
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 100, height: 100)
                                .clipShape(Circle())
                        default:
                            Image("avatar")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 100, height: 100)
                                .clipShape(Circle())
                        }
                    }
                }else {
                    Image("avatar")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 100, height: 100)
                        .clipShape(Circle())
                }
                                
                }
                
        }
        
    }
}

#Preview {
    UpdateUser(user: UserModel(id: UUID(), userName: "", email: "", password: "", avatar: "", telephone: "", accNumber: "", businessName: "", city: "", direct: "", contactPersonName: "", name: "", address: "", role: ""),profile: false)
}
