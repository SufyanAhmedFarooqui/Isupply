//
//  SelectSalesPerson.swift
//  iSupply
//
//  Created by hassan ghouri on 12/03/2024.
//

import SwiftUI

struct SelectSalesPerson: View {
        @State private var searchTerm = ""
        @State private var Users:[UserModel] = []
        @StateObject private var viewModel = UserViewModel()
        @AppStorage("userEmail") var userEmail = ""
        @AppStorage("userRole") var userRole = ""
        var locationScreen:Bool? = false
        var body: some View {
            NavigationStack{
                if (viewModel.isLoading){ LoadingView()}
                CustomSearchBar(searchText: $searchTerm)
                List(filteredUsers, id: \.email) { user in
                    if(locationScreen!){
                        NavigationLink(destination: LocationMapView(latitude: user.currentLocation?.lat ?? 0, longitude: user.currentLocation?.lng ?? 0,name:user.name ?? "Here")) {
                            UserCell(user: user)
                        }
                    }else{
                        NavigationLink(destination: AssociateCustomer(email:user.email, role:user.role)) {
                            UserCell(user: user)
                        }
                    }
                }.padding(.horizontal)
                .navigationTitle("Select Sales Person")
            }.onAppear{
                viewModel.getUsers(email: userEmail,route:"getUsersByEmail")
            }
        }
        var filteredUsers: [UserModel] {
            
            var filteredArray = viewModel.users
            
            filteredArray = filteredArray.filter { $0.role == "Sales Person" }
            
            if !searchTerm.isEmpty {
                filteredArray = filteredArray.filter { user in
                    user.email!.lowercased().contains(searchTerm.lowercased()) ||
                    user.name!.lowercased().contains(searchTerm.lowercased())
                }
            }
            
            return filteredArray
        }
}

#Preview {
    SelectSalesPerson()
}

struct CustomSearchBar: View {
    @Binding var searchText: String
    @State private var isEditing = false

    var body: some View {
        HStack {
            TextField("Search...", text: $searchText)
                .padding(7)
                .padding(.horizontal, 25)
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .overlay(
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                            .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 8)
                        
                        if isEditing {
                            Button(action: {
                                self.searchText = ""
                            }) {
                                Image(systemName: "multiply.circle.fill")
                                    .foregroundColor(.gray)
                                    .padding(.trailing, 8)
                            }
                        }
                    }
                )
                .onTapGesture {
                    self.isEditing = true
                }

            if isEditing {
                Button(action: {
                    self.isEditing = false
                    self.searchText = ""
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                }) {
                    Text("Cancel")
                }
                .padding(.trailing, 10)
                .transition(.move(edge: .trailing))
                .animation(.default, value: isEditing)
            }
        }
        .padding(.horizontal, 10)

    }
}
