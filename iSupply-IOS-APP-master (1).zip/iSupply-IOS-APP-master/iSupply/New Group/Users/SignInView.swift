//
//  ContentView.swift
//  iSupply
//
//  Created by hassan ghouri on 08/01/2024.
//

import SwiftUI

struct SignInView: View {
    @State private var name:String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isLoggedIn: Bool = false  // Track login state
    @State private var alertItem: AlertType?
    @State private var isLoading: Bool = false
    
    let apiManager = UsersAPI.sharedInstance
    enum AlertType: Identifiable {
        case error(message: String)
        
        var id: String {
            switch self {
            case .error(let message):
                return message
            }
        }
    }
    var body: some View {
        NavigationStack{
            ScrollView{
                ZStack{
                    if isLoading {
                        LoadingView()
                    }
                    VStack{
                        Spacer()
                        //Image
                        Image("logo")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 150, height: 170)
                            .padding(.vertical, 32)
                        // UI From Figma
                        Text("Welcome Back!")
                            .font(Font.custom("Manrope", size: 22).weight(.heavy))
                            .foregroundColor(Color(red: 0.17, green: 0.19, blue: 0.58))
                            .padding(5)
                        Text("Hi, login to contribute")
                            .font(Font.custom("Manrope", size: 14))
                            .foregroundColor(Color(red: 0.01, green: 0.01, blue: 0.01))
                        //Form Fields
                        VStack(spacing: 24){
                            InputView(text: $email, title: "Email Address", placeholder: "name@example.com", isSecureField: false)
                                .autocapitalization(.none)
                            InputView(text: $password, title: "Password", placeholder: "Enter Your Password", isSecureField: true)
                        }
                        .padding(.horizontal)
                        .padding(.top,12)
                        //Forgot Password Link
                        NavigationLink {
                            ForgotPassword()
                        } label: {
                            Text("Forgot Password?")
                                .font(Font.custom("Manrope", size: 14))
                                .multilineTextAlignment(.center)
                                .foregroundColor(Color(red: 0.01, green: 0.01, blue: 0.01))
                                .frame(width: 282.08029, height: 18.93333, alignment: .trailing)
                        }
                        
                        //Sign in Button
                        
                        .navigationDestination(isPresented: $isLoggedIn) {
                            MainView()
                        }
                        
                        Button{
                            Task {
                                isLoading = true
                                let user = UserModel(userName: name, email: email, password: password)
                                do {
                                    try await apiManager.signApi(user: user) { result in
                                        switch result {
                                        case let .success((success, role, name)):
                                            if success && role != "" {
                                                // Handle successful login for admin
                                                UserDefaults.standard.set(email, forKey: "userEmail")
                                                UserDefaults.standard.set(name, forKey: "userName")
                                                UserDefaults.standard.set(role, forKey: "userRole")
                                                isLoading = false
                                                isLoggedIn = true
                                            }else{
                                                isLoading = false
                                                alertItem = .error(message: "Incorrect email or Password")
                                            }
                                        case let .failure(error):
                                            // Handle the error
                                            isLoading = false
                                            alertItem = .error(message: error.localizedDescription + "Check Your Internet Connection")
                                        }
                                    }
                                } catch {
                                    // Handle error from signInApi
                                    alertItem = .error(message: error.localizedDescription)
                                }
                            }
                        } label: {
                            HStack{
                                Text("Login")
                                    .font(
                                        Font.custom("Manrope", size: 22)
                                            .weight(.heavy)
                                    )
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(.white)
                                    .frame(width: 214.18979, height: 22.08889, alignment: .top)
                            }
                            .foregroundColor(.white)
                            .frame(width: UIScreen.main.bounds.width-50, height: 48)
                            
                        }
                        .background(Color(red: 0.17, green: 0.19, blue: 0.58))
                        .cornerRadius(10)
                        .padding(.top, 24)
                        .disabled(!formIsValid)
                        .opacity(formIsValid ? 1.0 : 0.5)
                        
                        Spacer()
                        
                    }
                    .alert(item: $alertItem) { alertType in
                        switch alertType {
                        case .error(let message):
                            return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
                        }
                    }
                }
            }
            
        }
        
        
    }
}

// Mark: - AuthenticationFormProtocol

extension SignInView:AuthenticationFormProtocol {
    var formIsValid: Bool {
        return !email.isEmpty
        && email.contains("@")
        && !password.isEmpty
        && password.count > 5
    }
}

#Preview {
    SignInView()
}
