//
//  AssociateCustomer.swift
//  iSupply
//
//  Created by hassan ghouri on 12/03/2024.
//

import SwiftUI

struct AssociateCustomer: View {
    @State private var searchTerm = ""
    @State private var Users:[UserModel] = []
    @StateObject private var viewModel = UserViewModel()
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @State private var isLoading = false
    @Environment(\.presentationMode) var presentationMode
    @State private var alertItem: AlertType?
    let apiManager = UsersAPI.sharedInstance
    var email:String?
    var role:String?
    var id:String?
    var body: some View {
        if (viewModel.isLoading){ LoadingView()}
        NavigationStack{
            List(filteredUsers, id: \.email) { user in
                    UserCell(user: user)
                    .onTapGesture {
                        associateUser(SalePersonEmail: email ?? "" , customerEmail: user.email ?? "", customerRole: user.role ?? "")
                    }
            }.padding(.horizontal)
            .navigationTitle("Select Customer")
            .searchable(text: $searchTerm, prompt: "Search for Customer")
        }.onAppear{
            viewModel.getUsers(email: userEmail,route:"getUsersByEmail")
        }
        .alert(item: $alertItem) { alertType in
            switch alertType {
            case .error(let message):
                return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
            case .success(let message):
                return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                    // Navigate to previous screen
                    presentationMode.wrappedValue.dismiss()
                }, secondaryButton: .cancel())
            }
        }
    }
    var filteredUsers: [UserModel] {
        
        var filteredArray = viewModel.users
        
        filteredArray = filteredArray.filter { $0.role == "Customer" }
        
        if !searchTerm.isEmpty {
            filteredArray = filteredArray.filter { user in
                user.email!.lowercased().contains(searchTerm.lowercased()) ||
                user.name!.lowercased().contains(searchTerm.lowercased())
            }
        }
        
        return filteredArray
    }
    
    func associateUser(SalePersonEmail: String, customerEmail:String,customerRole:String){
        Task {
            isLoading = true
            apiManager.checkUser(email: SalePersonEmail, userEmail: customerEmail, userRole: customerRole) { result in
                switch result {
                case let .success(success):
                    if success {
                        isLoading = false
                        alertItem = .success(message: "Customer Assigned Successfully!")
                    }
                case .failure(_):
                    // Handle the error
                    isLoading = false
                    alertItem = .error(message:"Customer Already Assiged")
                                                       
                }
            }
        }
    }
}

#Preview {
    AssociateCustomer()
}
