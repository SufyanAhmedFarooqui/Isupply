import Foundation
import MapKit

final class LocationViewModel: NSObject, ObservableObject, CLLocationManagerDelegate {
    var locationManager: CLLocationManager?
    @Published var centerCoordinate: CLLocationCoordinate2D?
    @Published var region = MKCoordinateRegion()

    override init() {
        super.init()
        checkIfLocationServicesEnabled()
        if let location = locationManager?.location {
            DispatchQueue.main.async {
                self.region = MKCoordinateRegion(center: location.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05))
                self.centerCoordinate = location.coordinate
            }
        }
        
    }

    func checkIfLocationServicesEnabled() {
        if CLLocationManager.locationServicesEnabled() {
            locationManager = CLLocationManager()
            locationManager?.delegate = self
            // Do not request authorization here
        } else {
            print("Alert: Location services are turned off.")
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
        case .notDetermined:
            // User has not yet made a choice with regards to this application
            manager.requestWhenInUseAuthorization()
        case .restricted, .denied:
            // User has explicitly denied authorization for this application, or location services are disabled
            print("Location authorization denied or restricted.")
        case .authorizedWhenInUse, .authorizedAlways:
            // Location authorization granted
            updateRegionToUserLocation()
        @unknown default:
            fatalError("Unknown location authorization status")
        }
    }
    func updateRegionToUserLocation() {
        if let location = locationManager?.location {
            DispatchQueue.main.async {
                self.region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
                self.centerCoordinate = location.coordinate
            }
        }
    }
}
