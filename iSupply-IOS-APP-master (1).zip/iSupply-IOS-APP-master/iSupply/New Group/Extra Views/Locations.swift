//
//  Locations.swift
//  iSupply
//
//  Created by hassan ghouri on 31/01/2024.
//

import SwiftUI

import SwiftUI
import MapKit

struct Locations: View {
    let users: [UserModel]
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194), // Initial map center
        span: MKCoordinateSpan(latitudeDelta: 10, longitudeDelta: 10)
    )

    var body: some View {
        Map(coordinateRegion: $region, annotationItems: filteredUsers) { user in
            MapAnnotation(coordinate: CLLocationCoordinate2D(latitude: user.currentLocation?.lat ?? 0, longitude: user.currentLocation?.lng ?? 0)) {
                AnnotationView(user: user)
            }
        }
    }
    var filteredUsers: [UserModel] {
        var filteredArray = users
        filteredArray = filteredArray.filter { $0.role == "Sales Person" }
        return filteredArray
}
}

struct AnnotationView: View {
    let user: UserModel
    
    var body: some View {
        VStack {
            AsyncImage(url: URL(string: Constants.imageBaseUrl+user.avatar!)) { phase in
                switch phase {
                case .empty:
                    Image("avatar")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 30, height: 30)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.white, lineWidth: 2))
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()
                        .frame(width: 30, height: 30)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.white, lineWidth: 2))
                default:
                    Image("avatar")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 30, height: 30)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.white, lineWidth: 2))
                }
            }
            Text(user.userName!)
                .font(.caption)
                .foregroundColor(.black)
        }
        .padding(5)
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 10)
    }
}


#Preview {
    Locations(users: [UserModel(userName: "Abc", email: "Cs", password: "",avatar:"2024-03-13T02-00-49.233Z-avatar.jpeg", role:"Sales Person",currentLocation: Location(lat: 37.33, lng: -122.14))])
}
