//
//  Settings.swift
//  iSupply
//
//  Created by hassan ghouri on 31/01/2024.
//

import SwiftUI

struct Settings: View {
    var body: some View {
        NavigationStack {
            VStack{
                ZStack{
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 410, height: 160)
                        .background(Color(red: 0.17, green: 0.19, blue: 0.58).opacity(0.5))
                    HStack{
                        Text("Setting")
                            .font(
                                Font.custom("Manrope", size: 34)
                                    .weight(.heavy)
                            )
                            .foregroundColor(.white)
                            .frame(alignment: .topLeading)
                        Spacer()
                        Image(systemName: "gear.circle")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 54.6, height: 50)
                            .cornerRadius(44)
                    }.padding(.horizontal)
                }
                Form {
                    Section{
                        NavigationLink {
                            PrivacyPolicy()
                        } label: {
                                Text("Privacy Policy")
                                  .font(
                                    Font.custom("Manrope", size: 17)
                                      .weight(.semibold)
                                  )
                                  .foregroundColor(Color(red: 0.01, green: 0.01, blue: 0.01))
                                  .frame(width: 151.44, alignment: .topLeading)
                        }
                    }
                }.padding(0)
                Spacer()
            }
        }
    }
}

#Preview {
    Settings()
}
