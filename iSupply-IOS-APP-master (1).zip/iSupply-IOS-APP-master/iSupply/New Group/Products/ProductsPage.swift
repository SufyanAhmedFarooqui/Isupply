//
//  ProductsPage.swift
//  iSupply
//
//  Created by hassan ghouri on 11/02/2024.
//

import SwiftUI

struct ProductsPage: View {
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @State private var searchTerm = ""
    @State private var Products:[ProductModel] = []
    @StateObject private var viewModel = ProductViewModel()
    var email: String?
    var lowStock:Bool = false
    var body: some View {
        NavigationStack{
            VStack(alignment: .leading){
                if(userRole == "Vendor" || userRole == "Admin"){
                    HStack{
                        Spacer()
                        if(!lowStock){
                            NavigationLink {
                                AddProduct()
                            } label: {
                                ZStack(alignment: .center, content: {
                                    Rectangle()
                                        .foregroundColor(.clear)
                                        .frame(width: 126.00653, height: 44.25)
                                        .background(Color(red: 0.17, green: 0.19, blue: 0.58).opacity(0.8))
                                        .cornerRadius(20)
                                    
                                    Text("Add Product")
                                        .font(
                                            Font.custom("Manrope", size: 17)
                                                .weight(.semibold)
                                        )
                                        .foregroundColor(.white)
                                        .frame(width: 94, height: 32, alignment: .center)
                                })
                            }
                        }
                    }
                }
                Text("Product Details")
                  .font(
                    Font.custom("Manrope", size: 18)
                      .weight(.semibold)
                  )
                  .kerning(0.054)
                  .foregroundColor(Color(red: 0.53, green: 0.53, blue: 0.53))
                List(filteredProducts, id: \.id) { product in
                    NavigationLink(destination: {
                        TopSellingProduct(showProductDetails: true, productId:product.id ?? "")
                    }) {
                        ProductCell(product: product)
                    }
                    
                }

            }.padding(.horizontal)
            .navigationTitle("Inventory - Products")
                .searchable(text: $searchTerm, prompt: "Search")
            Spacer()
        }
        .onAppear{
            if (userRole == "Admin")
            {
                viewModel.getProducts()
            }else if (userRole == "Vendor" || userRole == "Sales Person"){
                viewModel.getProductsByEmail(email: userEmail, role: nil)
            }else{
                if let email = email {
                    viewModel.getProductsByEmail(email: email, role: nil)
                }
            }
        }
        if (viewModel.isLoading){ LoadingView()}
    }
    var filteredProducts: [ProductModel] {
        var filteredArray = viewModel.products
        
        // Apply search term filter if it is not empty
        if !searchTerm.isEmpty {
            filteredArray = filteredArray.filter { product in
                let containsName = product.name?.lowercased().contains(searchTerm.lowercased()) ?? false
                let containsCategory = product.category?.lowercased().contains(searchTerm.lowercased()) ?? false
                return containsName || containsCategory
            }
        }
        return filteredArray
        // Apply scanned code filter if it is not empty
        //    if !scannedCode.isEmpty {
        //        filteredArray = filteredArray.filter { product in
        //            // Convert itemCode to String for comparison
        //            let itemCodeString = String(product.itemCode ?? 123456)
        //            let isCodeMatch = itemCodeString == scannedCode
        //            // Print debug information
        //            print("Comparing \(itemCodeString) with \(scannedCode): \(isCodeMatch)")
        //            return isCodeMatch
        //        }
        //    }
        //
        //    return filteredArray
        //}
        //
        //var paginatedProducts: [ProductModel] {
        //    let startIndex = (currentPage - 1) * itemsPerPage
        //    let endIndex = min(startIndex + itemsPerPage, filteredProducts.count)
        //    if startIndex >= endIndex {
        //        return []
        //    }
        //    return Array(filteredProducts[startIndex..<endIndex])
        //}
    }
}

#Preview {
    ProductsPage()
}
