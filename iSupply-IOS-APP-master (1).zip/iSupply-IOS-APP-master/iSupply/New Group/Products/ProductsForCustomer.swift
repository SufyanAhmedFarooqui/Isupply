//
//  ProductsForCustomer.swift
//  iSupply
//
//  Created by hassan ghouri on 12/03/2024.
//

import SwiftUI

struct ProductsForCustomer: View {
    @State private var searchTerm = ""
    @State private var Users:[UserModel] = []
    @StateObject private var viewModel = UserViewModel()
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    var body: some View {
        if (viewModel.isLoading){ LoadingView()}
        NavigationStack{
            List(filteredUsers, id: \.email) { user in
                NavigationLink(destination: ProductsPage(email:user.email)) {
                    UserCell(user: user)
                }
            }.padding(.horizontal)
            .navigationTitle("See Products")
            .searchable(text: $searchTerm, prompt: "Search for Vendors")
        }.onAppear{
            viewModel.getUsers(email: userEmail,route:"getUsersByEmail")
        }
    }
    var filteredUsers: [UserModel] {
        
        var filteredArray = viewModel.users
        filteredArray = filteredArray.filter { $0.role == "Vendor" }
        if !searchTerm.isEmpty {
            filteredArray = filteredArray.filter { user in
                user.email!.lowercased().contains(searchTerm.lowercased()) ||
                user.name!.lowercased().contains(searchTerm.lowercased())
            }
        }
        
        return filteredArray
    }
}

#Preview {
    ProductsForCustomer()
}
