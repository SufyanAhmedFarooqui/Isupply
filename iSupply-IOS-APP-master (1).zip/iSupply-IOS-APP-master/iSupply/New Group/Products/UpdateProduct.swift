//
//  UpdateProduct.swift
//  iSupply
//
//  Created by hassan ghouri on 05/02/2024.
//

import SwiftUI
import PhotosUI

struct UpdateProduct: View {
    
    let product: ProductModel
    @Environment(\.presentationMode) var presentationMode
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @State private var id = ""
    @State private var name = ""
    @State private var category = ""
    @State private var invoiceDescription = ""
    @State private var brand = ""
    @State private var flavourType = ""
    @State private var size = ""
    @State private var productType = ""
    @State private var itemCode = ""
    @State private var stockThreshold = ""
    @State private var stock = ""
    @State private var price = ""
    @State private var salesMethod = ""
    @State private var photosPickerItemsInitial = true
    @State private var productImages: [UIImage] = []
    @State private var images = []
    @State private var deletedImages:[String] = []
    @State private var photosPickerItems: [PhotosPickerItem] = []
    let apiManager = ProductsAPI.sharedInstance
    let userApiManager = UsersAPI.sharedInstance
    @State private var alertItem: AlertType?
    @State private var isLoading = false
    
    
    init(product: ProductModel) {
        self.product = product
        _id = State(initialValue: product.id ?? "")
        _name = State(initialValue: product.name ?? "")
        _category = State(initialValue: product.category ?? "")
        _invoiceDescription = State(initialValue: product.invoiceDescription ?? "")
        _brand = State(initialValue: product.brand ?? "")
        _flavourType = State(initialValue: product.flavourType ?? "")
        _size = State(initialValue: product.size ?? "")
        _productType = State(initialValue: product.productType ?? "Qty")
        _itemCode = State(initialValue: product.itemCode ?? "0")
        _stockThreshold = State(initialValue: "\(product.stockThreshold ?? 0)")
        _stock = State(initialValue: "\(product.stock ?? 0)")
        _price = State(initialValue: "\(product.price ?? 0.0)")
        _salesMethod = State(initialValue: product.salesMethod ?? "FIFO")
        _images = State(initialValue: product.images as [String?] as [Any]) // Initialize productImages as an empty array
        _photosPickerItemsInitial = State(initialValue: true)
        _photosPickerItems = State(initialValue: [])
        _alertItem = State(initialValue: nil)
        _isLoading = State(initialValue: false)
    }
    
    var body: some View {
        NavigationStack{
            ZStack {
                if (isLoading){
                    LoadingView()
                }
                ScrollView {
                    VStack(alignment: .center, spacing: 10) {
                        
                            productImagesView()
                            if(images.count >= 5){
                                PhotosPicker("Select New Images",selection: $photosPickerItems, maxSelectionCount:5)
                            }else {
                                PhotosPicker("Add More Images",selection: $photosPickerItems, maxSelectionCount:5-images.count)
                            }
                            newProductImagesView()
                            TextFieldWithBorder(text: "Name", placeholder: "Name", value: $name)
                            TextFieldWithBorder(text: "Category", placeholder: "Category", value: $category)
                            TextFieldWithBorder(text: "Invoice Description", placeholder: "Invoice Description", value: $invoiceDescription)
                            TextFieldWithBorder(text: "Brand", placeholder: "Brand", value: $brand)
                            TextFieldWithBorder(text: "Flavor", placeholder: "Flavour Type", value: $flavourType)
                            TextFieldWithBorder(text: "Size", placeholder: "size", value: $size)
                            Picker(selection: $productType, label: Text("Product Type")) {
                                Text("Qty").tag("Qty")
                                Text("Weight").tag("Weight")
                            }.pickerStyle(SegmentedPickerStyle())
                            TextFieldWithBorder(text: "UPC/ Item #", placeholder: "UPC/ Item #", value: $itemCode)
                            TextFieldWithBorder(text: "Stock Threshhold", placeholder: "Stock Threshhold", value: $stockThreshold)
                            TextFieldWithBorder(text: "Stock", placeholder: "Stock", value: $stock)
                            TextFieldWithBorder(text: "Price", placeholder: "12$", value: $price)
                            Picker(selection: $salesMethod, label: Text("Sales Method")) {
                                Text("FIFO").tag("FIFO")
                                Text("LIFO").tag("LIFO")
                            }.pickerStyle(SegmentedPickerStyle())
                        HStack(alignment: .center) {
                            Spacer()
                            Button {
                                deleteProduct()
                            } label: {
                                ZStack{
                                    Rectangle()
                                      .foregroundColor(.clear)
                                      .frame(width: 125, height: 40)
                                      .background(Color(red: 0.6, green: 0.1, blue: 0.1).opacity(0.8))
                                      .cornerRadius(20)
                                    Text("Delete")
                                      .font(
                                        Font.custom("Manrope", size: 17)
                                          .weight(.semibold)
                                      )
                                      .multilineTextAlignment(.center)
                                      .foregroundColor(.white)
                                      .frame(width: 90, height: 20, alignment: .top)
                                }
                            }

                        }
                        }
                        .padding(.horizontal)
                        .alert(item: $alertItem) { alertType in
                            switch alertType {
                            case .error(let message):
                                return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
                            case .success(let message):
                                return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                                    // Navigate to previous screen
                                    presentationMode.wrappedValue.dismiss()
                                }, secondaryButton: .cancel())
                            }
                    }
                }
                }
            .onChange(of: photosPickerItems) { newPhotosPickerItems in
                if photosPickerItemsInitial {
                    Task {
                        await handlePhotosPickerItems()
                    }
                }
        }
            }.navigationTitle("View Product")
                .toolbar {
                    Button("Update") {
                        if(!formIsValid){
                            alertItem = .error(message: "Name and Product Category is required")
                            return
                        }
                        if(!itemCodeIsValid){
                            alertItem = .error(message: "UPC or Item Number must be 6 or more numbers")
                            return
                        }
                        if(!priceIsValid){
                            alertItem = .error(message: "Product must contain some price")
                            return
                        } 
                        Task {
                            isLoading = true
                            let product = ProductModel(id: id ,name: name, category: category, brand:brand, size:size, price:Float(price), flavourType:flavourType, invoiceDescription: invoiceDescription, productType: productType, itemCode:itemCode, stockThreshold: Int(stockThreshold), stock:Int(stock), salesMethod:salesMethod, userEmail:userEmail, userRole: userRole)
                            apiManager.addProductApi(product: product, images: productImages, deletedImages: deletedImages ,route:"updateProduct", completion: { result in
                                    switch result {
                                    case let .success(success):
                                        if success {
                                            isLoading = false
                                            alertItem = .success(message: "Product Updated Successfully!")
                                        }
                                    case .failure(_):
                                        // Handle the error
                                        isLoading = false
                                        alertItem = .error(message: "Product not updated Try again!")
                                    }
                                })
                            }
                    }
                }
            
        }
   
    func deleteProduct(){
        Task {
            isLoading = true
            userApiManager.deleteById(id: id, route:"deleteProduct") { result in
                    switch result {
                    case let .success(success):
                        isLoading = false
                        alertItem = .success(message: success.message ?? "Reset Link Sent")
                    case .failure(_):
                        // Handle the error
                        isLoading = false
                        alertItem = .error(message: "Email doesnot exist or " + "Check Your Internet Connection")
                    }
                }
        }
    }
    
    @ViewBuilder
    private func productImagesView() -> some View {
        ScrollView(.horizontal) {
            HStack(spacing: 20) {
                // Your image views go here
                ForEach(0..<images.count, id: \.self) { i in
                    let image = images[i]
                    ZStack(alignment: .bottomTrailing) {
                        AsyncImage(url: URL(string: Constants.imageBaseUrl + (image as! String))) { phase in
                            switch phase {
                            case .empty:
                                Image("placeholder_image") // Show a placeholder image if necessary
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 100, height: 100)
                                    .clipShape(Circle())
                            case .success(let image):
                                image
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 100, height: 100)
                                    .clipShape(Circle())
                            default:
                                Image("placeholder_image") // Show a placeholder image if necessary
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 100, height: 100)
                                    .clipShape(Circle())
                            }
                        }
                        // Add a delete icon
                        Button(action: {
                            deleteImage(at: i)
                        }) {
                            Image(systemName: "trash")
                                .foregroundColor(.white)
                                .padding(8)
                                .background(Color.red)
                                .clipShape(Circle())
                        }
                        .offset(x: -10, y: -10)
                    }
                }
            }
        }
    }

    private func deleteImage(at index: Int) {
            guard index >= 0 && index < images.count else {
                return
            }
        deletedImages.append(images[index] as! String)
            images.remove(at: index)
            print(deletedImages) // Debugging: Print the deleted images array
        }

    
    @ViewBuilder
    private func newProductImagesView() -> some View {
        ScrollView(.horizontal) {
            HStack(spacing: 20) {
                ForEach(Array(productImages.enumerated()), id: \.element) { index, image in
                    ZStack(alignment: .bottomTrailing) {
                        Image(uiImage: image)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 100, height: 100)
                            .clipShape(Circle())
                        
                        Button(action: {
                            deleteProductImage(at: index)
                        }) {
                            Image(systemName: "trash")
                                .foregroundColor(.white)
                                .padding(8)
                                .background(Color.red)
                                .clipShape(Circle())
                        }
                        .offset(x: -10, y: -10)
                    }
                }
            }
        }
    }

    private func deleteProductImage(at index: Int) {
        guard index >= 0 && index < productImages.count else {
            return
        }
        productImages.remove(at: index)
    }

    private func handlePhotosPickerItems() async {
        do {
            for item in photosPickerItems {
                if let data = try await item.loadTransferable(type: Data.self) {
                    if let image = UIImage(data: data) {
                        productImages.append(image)
                    }
                }
            }
            photosPickerItems = []
        } catch {
            // Handle the error appropriately
            print("Error handling photosPickerItems: \(error)")
        }
    }

}


// Mark: - AuthenticationFormProtocol

extension UpdateProduct:AuthenticationFormProtocol {
var formIsValid: Bool {
    return !name.isEmpty && !category.isEmpty
}
var itemCodeIsValid: Bool {
    return itemCode.count > 5
}
var priceIsValid: Bool {
    return !price.isEmpty
    
}
}

#Preview {
    UpdateProduct(product: ProductModel(id: "", name: "", category: "", brand: "", size: "", price: 0.0, flavourType: "", invoiceDescription: "", productType: "", itemCode: "0", stockThreshold: 0, stock: 0, salesMethod: "", images: [], userEmail: "", userRole: ""))
}

