//
//  AddProduct.swift
//  iSupply
//
//  Created by hassan ghouri on 11/02/2024.
//

import SwiftUI
import PhotosUI

struct AddProduct: View {
    @Environment(\.presentationMode) var presentationMode
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @State private var name = ""
    @State private var category = ""
    @State private var invoiceDescription = ""
    @State private var brand = ""
    @State private var flavourType = ""
    @State private var size = ""
    @State private var productType = "Qty"
    @State private var itemCode = ""
    @State private var stockThreshold = ""
    @State private var stock = ""
    @State private var price = ""
    @State private var salesMethod = "FIFO"
    @State private var photosPickerItemsInitial = true
    @State private var productImages: [UIImage] = []
    @State private var photosPickerItems: [PhotosPickerItem] = []
    let apiManager = ProductsAPI.sharedInstance
    @State private var alertItem: AlertType?
    @State private var isLoading = false
    var body: some View {
        NavigationStack {
            ZStack {
                if isLoading {LoadingView()}
                ScrollView {
                    contentView
                }.alert(item: $alertItem) { alertType in
                    switch alertType {
                    case .error(let message):
                        return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
                    case .success(let message):
                        return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                            // Navigate to previous screen
                            presentationMode.wrappedValue.dismiss()
                        }, secondaryButton: .cancel())
                    }
                }
                .onChange(of: photosPickerItems) { newPhotosPickerItems in
                    if photosPickerItemsInitial {
                        Task {
                            await handlePhotosPickerItems()
                        }
                    }
            }
            }

        }
        .navigationTitle("Add Product")
        .toolbar {
            Button("Add +") {
                if(!formIsValid){
                    alertItem = .error(message: "Name and Product Category is required")
                    return
                }
                if(!itemCodeIsValid){
                    alertItem = .error(message: "UPC or Item Number must be 6 or more numbers")
                    return
                }
                if(!priceIsValid){
                    alertItem = .error(message: "Product must contain some price")
                    return
                }
                Task {
                    isLoading = true
                    let product = ProductModel(name: name, category: category, size:size, price:Float(price), flavourType:flavourType, invoiceDescription: invoiceDescription, productType: productType, itemCode:itemCode, stockThreshold: Int(stockThreshold), stock:Int(stock), salesMethod:salesMethod, userEmail:userEmail, userRole: userRole)
                    apiManager.addProductApi(product: product, images: productImages, deletedImages:[] ,route:"createProduct", completion: { result in
                            switch result {
                            case let .success(success):
                                if success {
                                    isLoading = false
                                    alertItem = .success(message: "Product Updated Successfully!")
                                }
                            case .failure(_):
                                // Handle the error
                                isLoading = false
                                alertItem = .error(message: "Product not updated Try again!")
                            }
                        })
                    }
                
                    }
        }
    }

    @ViewBuilder
    private var contentView: some View {
        VStack(alignment: .leading, spacing: 10) {
            // Your input views and pickers go here
            InputView(text: $name, title: "Name", placeholder: "My Product")
            InputView(text: $category, title: "Category", placeholder: "ABC foods")
            InputView(text: $invoiceDescription, title: "Invoice Description", placeholder: "invoiceDescription")
            InputView(text: $brand, title: "Brand", placeholder: "Shahi")
            InputView(text: $flavourType, title: "Flavor", placeholder: "Mint etc")
            InputView(text: $size, title: "size", placeholder: "18x12")
            Picker(selection: $productType, label: Text("Product Type")) {
                Text("Qty").tag("Qty")
                Text("Weight").tag("Weight")
            }.pickerStyle(SegmentedPickerStyle())
            InputView(text: $itemCode, title: "UPC/ Item # (min 6 digits)", placeholder: "897238", number: true)
            InputView(text: $stockThreshold, title: "Stock Threshold", placeholder: "123", number:true)
            Picker(selection: $salesMethod, label: Text("Sales Method")) {
                Text("FIFO").tag("FIFO")
                Text("LIFO").tag("LIFO")
            }.pickerStyle(SegmentedPickerStyle())
            InputView(text: $stock, title: "Stock", placeholder: "123", number:true)
            InputView(text: $price, title: "Unit Price", placeholder: "13$", number:true)
            PhotosPicker("Select Product Images",selection: $photosPickerItems, maxSelectionCount:5)
            productImagesView()
            
        }
        .padding(.horizontal)
    }

    @ViewBuilder
    private func productImagesView() -> some View {
        ScrollView(.horizontal) {
            HStack(spacing: 20) {
                ForEach(Array(productImages.enumerated()), id: \.element) { index, image in
                    ZStack(alignment: .bottomTrailing) {
                        Image(uiImage: image)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 100, height: 100)
                            .clipShape(Circle())
                        
                        Button(action: {
                            deleteProductImage(at: index)
                        }) {
                            Image(systemName: "trash")
                                .foregroundColor(.white)
                                .padding(8)
                                .background(Color.red)
                                .clipShape(Circle())
                        }
                        .offset(x: -10, y: -10)
                    }
                }
            }
        }
    }

    private func deleteProductImage(at index: Int) {
        guard index >= 0 && index < productImages.count else {
            return
        }
        productImages.remove(at: index)
    }

    private func handlePhotosPickerItems() async {
        do {
            for item in photosPickerItems {
                if let data = try await item.loadTransferable(type: Data.self) {
                    if let image = UIImage(data: data) {
                        productImages.append(image)
                    }
                }
            }
            photosPickerItems = []
        } catch {
            // Handle the error appropriately
            print("Error handling photosPickerItems: \(error)")
        }
    }

}
// Mark: - AuthenticationFormProtocol

extension AddProduct:AuthenticationFormProtocol {
    var formIsValid: Bool {
        return !name.isEmpty && !category.isEmpty
    }
    var itemCodeIsValid: Bool {
        return itemCode.count > 5
    }
    var priceIsValid: Bool {
        return !price.isEmpty
        
    }
}

#Preview {
    AddProduct()
}
