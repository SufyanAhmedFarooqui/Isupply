//
//  UserViewModel.swift
//  iSupply
//
//  Created by hassan ghouri on 19/02/2024.
//

import Foundation

final class ProductViewModel: ObservableObject {
    @Published var products:[ProductModel] = []
    @Published var isLoading = false
    @Published var alertItem: AlertItem?
    @Published var topSellingProduct:ProductModel?
    @Published var totalRevenue:Int?
    
    func getProducts() {
        isLoading = true
        ProductsAPI.sharedInstance.getProducts{ [self] result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let products):
                    self.products = products
                case .failure(_):
                    self.alertItem = AlertItem(title: "Cannot get Users", message: "Check your Internet Connection")
                }
                
            }
            
        }
    }
    
    func getTopSellingProduct() {
        isLoading = true
        ProductsAPI.sharedInstance.getTopSellingProduct{ [self] result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let product):
                    self.topSellingProduct = product.product
                    self.totalRevenue = product.totalRevenue
                    
                case .failure(_):
                    self.alertItem = AlertItem(title: "Cannot get Users", message: "Check your Internet Connection")
                }
                
            }
            
        }
    }
    
    func getProductById(id:String, route:String) {
        isLoading = true
        ProductsAPI.sharedInstance.getProductById(id: id, route: route, completion: { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let product):
                    self.topSellingProduct = product
                case .failure(_):
                    self.alertItem = AlertItem(title: "Cannot get Users", message: "Check your Internet Connection")
                }
                
            }
        })
    }
    
    func getProductsByEmail(email:String,role:String?) {
        isLoading = true
        ProductsAPI.sharedInstance.getProductsByEmail(email:email, role:role, route: "getProductsByEmail"){ [self] result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let products):
                    self.products = products
                case .failure(_):
                    self.alertItem = AlertItem(title: "Cannot get Products", message: "Check your Internet Connection")
                }
            }
            
        }
    }
    
    func getProductsByDateAndEmail(email:String,fromDate: Date, toDate: Date) {
        isLoading = true
        ProductsAPI.sharedInstance.getProductsByDateRange(email:email,fromDate:fromDate, toDate:toDate, route: "getProductsByDateAndEmail"){ [self] result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let products):
                    self.products = products
                case .failure(_):
                    self.alertItem = AlertItem(title: "Cannot get Products", message: "Check your Internet Connection")
                }
            }
            
        }
    }
            
    
}
