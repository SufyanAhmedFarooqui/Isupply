//
//  ViewProduct.swift
//  iSupply
//
//  Created by hassan ghouri on 13/03/2024.
//

import SwiftUI

struct ViewProduct: View {
    let product: ProductModel
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
                    // Horizontal image carousel
                    ScrollView(.horizontal, showsIndicators: true) {
                        HStack(spacing: 10) {
                            ForEach(product.images.compactMap { $0 }, id: \.self) { imageName in
                                AsyncImage(url: URL(string: Constants.imageBaseUrl + imageName))
                                { phase in
                                    switch phase {
                                    case .empty:
                                        Image("placeholder_image") // Show a placeholder image if necessary
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .frame(width: 100, height: 100)
                                            .clipShape(Circle())
                                    case .success(let image):
                                        image
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .frame(width: 100, height: 100)
                                            .clipShape(Circle())
                                    default:
                                        Image("placeholder_image") // Show a placeholder image if necessary
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .frame(width: 100, height: 100)
                                            .clipShape(Circle())
                                    }
                                }
                            }
                        }
                    }
                    
                    // Product details
                    VStack(alignment: .leading, spacing: 8) {
                        Text(product.name ?? "")
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Text("Product Type: \(product.productType ?? "")")
                        Text("Flavour Type: \(product.flavourType ?? "")")
                        Text("Price: \(formatPrice(product.price))")
                    }
                    .padding(.horizontal)
                    
                    Spacer()
                }
                .padding()
                .navigationTitle("Product Details")
            }
            
            // Helper method to format price
            private func formatPrice(_ price: Float?) -> String {
                guard let price = price else { return "Price: N/A" }
                let formatter = NumberFormatter()
                formatter.numberStyle = .currency
                formatter.currencyCode = "USD" // Change currency code as needed
                return formatter.string(from: NSNumber(value: price)) ?? "Price: N/A"
            }
}

#Preview {
    ViewProduct(product: ProductModel())
}
