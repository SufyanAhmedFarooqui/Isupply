//
//  AppDelegate.swift
//  iSupply
//
//  Created by hassan ghouri on 11/05/2024.
//

import Foundation
import UIKit
import StripePaymentSheet

class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        StripeAPI.defaultPublishableKey = "pk_test_51PANqfP4Bh3TwxQVWGyFnZACNszNmVyhwBaOgjd98JlE5s4V0Mf3YLLsmpZQNoqavL8cYjwPoxfzKKv0eQm1quaD00HcwAxlND"
        // do any other necessary launch configuration
        return true
    }
}
