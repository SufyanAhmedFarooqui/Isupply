//
//  BarcodeScannerView.swift
//  iSupply
//
//  Created by hassan ghouri on 16/04/2024.
//
import SwiftUI
import CodeScanner

struct BarcodeScannerView: View {
    @State private var isShowingScanner = false
    @State private var scannedCode: String = ""

    var scannerSheet: some View {
        CodeScannerView(codeTypes: [.ean8, .ean13, .pdf417], simulatedData: "1234567890128") { result in
            isShowingScanner = false
            switch result {
            case .success(let code):
                self.scannedCode = code.string
            case .failure:
                // Handle the error scenario, possibly setting a default error message
                self.scannedCode = "Failed to scan."
            }
        }
    }

    var body: some View {
        VStack(spacing: 10) {
            Button("Scan Barcode") {
                isShowingScanner = true
            }
            .sheet(isPresented: $isShowingScanner) {
                scannerSheet
            }
            
            TextField("Scanned Barcode", text: $scannedCode)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
        }
        .padding()
    }
}

struct BarcodeScannerView_Previews: PreviewProvider {
    static var previews: some View {
        BarcodeScannerView()
    }
}

