//
//  SideMenu.swift
//  iSupply
//
//  Created by hassan ghouri on 17/01/2024.
//

import SwiftUI

struct SideMenuView<RenderView : View>: View {
    @Binding var isShowing:Bool
    var Direction: Edge
    @ViewBuilder var content:RenderView
    
    
    var body: some View {
        ZStack(alignment:.leading){
            ZStack(alignment:.leading){
                if isShowing{
                    Color.black
                        .opacity(0.3)
                        .ignoresSafeArea()
                        .onTapGesture {
                            isShowing.toggle()
                        }
                    content
                        .transition(.move(edge: Direction))
                        .background(
                            Color.white
                        )
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
            .ignoresSafeArea()
            .animation(.easeInOut, value: isShowing)
            
        }
    }
}

