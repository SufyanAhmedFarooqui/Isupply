import SwiftUI

struct ProductCard: View {
    var product: ProductModel
    var body: some View {
        ZStack(alignment: .topTrailing){
            ZStack(alignment: .bottom, content: {
                if let imageName = product.images.first {
                    AsyncImage(url: URL(string: Constants.imageBaseUrl + imageName!)) { phase in
                        switch phase {
                        case .empty:
                            Image("avatar")
                                .resizable()
                                .scaledToFit()
                                .clipShape(.rect(cornerRadius: 20))
                                .frame(width: 180)
                        case .success(let image):
                            image
                                .resizable()
                                .scaledToFit()
                                .clipShape(.rect(cornerRadius: 20))
                                .frame(width: 180)
                        default:
                            Image("avatar")
                                .resizable()
                                .scaledToFit()
                                .clipShape(.rect(cornerRadius: 20))
                                .frame(width: 180)

                        }
                    }
                } else {
                    Image("avatar")
                        .resizable()
                        .scaledToFit()
                        .clipShape(.rect(cornerRadius: 20))
                        .frame(width: 180)
                }
                VStack(alignment:.leading){
                    Text(product.name!)
                        .bold()
                    Text("$\(product.price!)")
                        .font(.caption)
                }
                .padding()
                .frame(width: 180, alignment: .leading)
                .background(.ultraThinMaterial)
                .clipShape(.rect(cornerRadius: 20))
                .foregroundStyle(.black)
            })
            .frame(width:180,height:250)
            .shadow(radius: 3)
//            
//            Button {
//                print("Added to cart!")
//            } label: {
//                Image(systemName: "plus")
//                    .padding(10)
//                    .foregroundColor(.white)
//                    .background(Color.black)
//                    .clipShape(.rect(cornerRadius: 50))
//                    .padding()
//            }
        }
    }
}

struct ProductCard_Previews: PreviewProvider {
    static var previews: some View {
        ProductCard(product: ProductModel(id: "", name: "abc", category: "", brand: "", size: "", price: 10.0, flavourType: "", invoiceDescription: "", productType: "", itemCode: "11", stockThreshold: 10, stock: 10, salesMethod: "", images: [], userEmail: "", userRole: ""))
    }
}
