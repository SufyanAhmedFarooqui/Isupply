//
//  AlertItem.swift
//  SwiftUI-MVVM
//
//  Created by Sean Allen on 5/24/21.
//

import SwiftUI

struct AlertItem: Identifiable {
    var id = UUID()
    var title: String
    var message: String
    var dismissButton: Alert.Button?
}

enum AlertType: Identifiable {
    case error(message: String)
    case success(message: String)
    var id: String {
        switch self {
        case .error(let message), .success(let message):
            return message
        }
    }
}

enum ConfirmAlertType: Identifiable {
    case error(message: String)
    case success(message: String, action: () -> Void) // Add action closure
    
    var id: String {
        switch self {
        case .error(let message), .success(let message, _): // Include action closure in pattern match
            return message
        }
    }
}
