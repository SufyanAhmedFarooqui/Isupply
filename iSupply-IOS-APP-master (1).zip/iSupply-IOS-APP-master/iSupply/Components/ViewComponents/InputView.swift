//
//  SwiftUIView.swift
//  iSupply
//
//  Created by hassan ghouri on 16/01/2024.
//

import SwiftUI

struct InputView: View {
    @Binding var text: String
    let title:String
    let placeholder:String
    var isSecureField = false
    var number = false
    var body: some View {
        VStack(alignment: .leading, spacing: 12, content: {
            Text(title)
                .foregroundColor(Color(.darkGray))
                .fontWeight(.bold)
                .font(.footnote)
            if isSecureField{
                    SecureField(placeholder,text: $text)
                        .font(.system(size: 14))
            }else if number{
                TextField(placeholder,text: $text)
                    .font(.system(size: 14))
                    .keyboardType(.numberPad)
            }else if(title == "Email") {
                TextField(placeholder,text: $text)
                    .font(.system(size: 14))
                    .textInputAutocapitalization(.never)
            }else{
                TextField(placeholder,text: $text)
                    .font(.system(size: 14))
            }
            Divider()
        })

        
    }
}

struct InputView_Previews: PreviewProvider {
    static var previews: some View {
        InputView(text: .constant(""), title: "Email Address", placeholder: "name@email.com")
    }
}
