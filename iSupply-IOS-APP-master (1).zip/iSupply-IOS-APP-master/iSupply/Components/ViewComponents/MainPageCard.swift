//
//  MainPageCard.swift
//  iSupply
//
//  Created by hassan ghouri on 26/01/2024.
//

import SwiftUI

struct MainPageCard: View {
    var title:String
    var imageName:String
    var backColor: Color
    var text:String?
    var body: some View {
            VStack(alignment: .leading, spacing: 12) {
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 30, height: 34)
                    .background(
                        Image(systemName:imageName)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                    )
                Text(title)
                    .font(
                        Font.custom("Manrope", size: 20)
                            .weight(.bold)
                    )
                    .multilineTextAlignment(.leading)
                    .foregroundColor(Color(red: 0.08, green: 0.08, blue: 0.08))
                if let tex = text{
                        Text(tex)
                            .font(Font.custom("Manrope", size: 11))
                            .foregroundColor(.gray)
                            .frame(maxWidth: .infinity, alignment: .topLeading)
                
                }
                
            }
            .padding(.horizontal)
            .frame(width: 184, height: 150, alignment: .leading)
            .background(backColor)
            .cornerRadius(12)
        }
}

#Preview {
    MainPageCard(title: "User Page",imageName: "logo", backColor: Color.gray)
}
