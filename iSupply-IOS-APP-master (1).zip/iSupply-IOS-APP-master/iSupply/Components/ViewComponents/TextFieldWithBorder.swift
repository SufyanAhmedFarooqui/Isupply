//
//  TextFieldWithBorder.swift
//  iSupply
//
//  Created by hassan ghouri on 07/02/2024.
//

import Foundation
import SwiftUI

struct TextFieldWithBorder: View {
    let text:String
    let placeholder:String
    @Binding var value: String
    var number = false
    var body: some View {
        VStack(alignment: .leading,spacing:10) {
            HStack(alignment: .center, spacing: 20){
                Text(text)
                    .frame(width: 120)
                    .lineLimit(nil)
                    .multilineTextAlignment(.leading)
                Spacer()
                Divider()
                Spacer()
                if number {
                    TextField(placeholder, text: $value)
                    .keyboardType(.numberPad)
                }else{
                    TextField(placeholder, text: $value)
                }
                
            }.frame(height: 50)
            Divider()
        }
    }
}
