//
//  MainPageCard2.swift
//  iSupply
//
//  Created by Hassan Ghori on 10/08/2025.
//

import SwiftUI

struct MainPageCard2: View {
    let title: String
    let imageName: String

    var body: some View {
            VStack(spacing: 8) {
       
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)

                Image(imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(height: 100)
                    .frame(maxWidth: .infinity)
                    .clipped()
                    .cornerRadius(100)
                    .overlay(
                        RoundedRectangle(cornerRadius: 100)
                            .stroke(Color.green, lineWidth: 3)
                    )
            }
            .shadow(color: Color.black.opacity(0.2), radius: 6, x: 0, y: 5)
            .padding(.horizontal)
    }
}


#Preview {
    MainPageCard2(title: "PRODUCTS", imageName: "kulfi")
}
