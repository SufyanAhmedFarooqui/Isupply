import SwiftUI


struct ProductCell: View {
    let product: ProductModel
    var body: some View {
    
            HStack{
                if let image = product.images.first {
                    AsyncImage(url: URL(string: Constants.imageBaseUrl + (image ?? ""))) { phase in
                        switch phase {
                        case .empty:
                            Image("avatar")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 57, height: 57)
                                .cornerRadius(15)
                        case .success(let image):
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 57, height: 57)
                                .cornerRadius(15)
                        default:
                            Image("avatar")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 57, height: 57)
                                .cornerRadius(15)
                        }
                    }
                }else{
                    Image("avatar")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 57, height: 57)
                        .cornerRadius(15)
                }
                
                VStack(alignment: .leading, spacing: 10){
                    if let name = product.name, let type = product.category {
                        Text(name)
                            .font(
                                Font.custom("Manrope", size: 16)
                                    .weight(.semibold)
                            )
                            .foregroundColor(Color(red: 0.12, green: 0.12, blue: 0.12))
                        Text(type)
                            .font(Font.custom("DM Sans", size: 10))
                            .foregroundColor(Color(red: 0.12, green: 0.12, blue: 0.12))
                    }
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 10){
//                    Image(systemName: "arrow.right")
//                        .frame(width: 20, height: 20)
//                        .foregroundStyle(.white)
//                        .background(Color(red: 0.17, green: 0.19, blue: 0.58))
//                        .rotationEffect(Angle(degrees: -45))
                    // Additional product details can be added here
                    Text((product.stock != nil) ? String(product.stock!):"0")
                      .font(Font.custom("Manrope", size: 14))
                      .kerning(0.042)
                      .multilineTextAlignment(.trailing)
                      .foregroundColor(Color(red: 0.32, green: 0.39, blue: 0.75))
                }
            }.foregroundColor(.clear)
                .background(.white)
                .cornerRadius(20)
                .frame(height: 100)
        
    }
}


#Preview {
    ProductCell(product: ProductModel(id:"asdf123",name:"Product 1", category:"Avbc",stock:12 ,images: []))
}
