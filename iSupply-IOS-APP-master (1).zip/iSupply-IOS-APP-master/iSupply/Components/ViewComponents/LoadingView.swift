//
//  LoadingView.swift
//  iSupply
//
//  Created by hassan ghouri on 15/02/2024.
//

import SwiftUI

struct LoadingView: View {
    var body: some View {
        ZStack{
            Color(.systemBackground)
                .ignoresSafeArea()
                .opacity(0.9)
            ProgressView()
                .progressViewStyle(CircularProgressViewStyle(tint: .blue))
                .scaleEffect(5)
        }
    }
}

#Preview {
    LoadingView()
}
