//
//  ESignView.swift
//  iSupply
//
//  Created by hassan ghouri on 07/03/2024.
//


import SwiftUI

struct ESignView: View {
    @Environment(\.presentationMode) var presentationMode
    @State var isSigning: Bool = false
    @State var clearSignature: Bool = false
    @Binding var signatureImage: UIImage?
    @Binding var signaturePDF: Data?
    @State private var image:UIImage?
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userRole") var userRole = ""
    @State private var alertItem: AlertType?
    @State private var isLoading = false
    let orderId: String
    let apiManager = OrdersAPI.sharedInstance

    var body: some View {
        NavigationStack {
            ZStack {
                if (isLoading){
                    LoadingView()
                }
                VStack {
                    Group {
                        VStack(alignment: .leading, spacing: 16){
                            Text("Proof of Delivery (POD)")
                                .font(.headline)
                                .foregroundColor(.accentColor)
                        }
                        .padding(.top, 20)
                    }
                    .padding(.horizontal, 16)
                    Divider()                
                    VStack(spacing: 16) {
                        ZStack(alignment: isSigning ? .bottomTrailing: .center) {
                            SignatureViewContainer(clearSignature: $clearSignature, signatureImage: $signatureImage, pdfSignature: $signaturePDF)
                                .disabled(!isSigning)
                                .frame(height: 197)
                                .frame(maxWidth: .infinity)
                                .background(.white)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.accentColor, lineWidth: 3)
                                )
                            if isSigning {
                                Button(action: {
                                    clearSignature = true
                                }, label: {
                                    HStack {
                                        Text("Clear")
                                            .font(.callout)
                                            .foregroundColor(.black)
                                    }
                                    .padding(.horizontal, 12)
                                    .frame(height: 28)
                                    .background(
                                        Capsule()
                                            .fill(.green)
                                    )
                                })
                                .offset(.init(width: -12, height: -12))
                            } else {
                                Button(action: {
                                    isSigning = true
                                }, label: {
                                    VStack(alignment: .center, spacing: 0) {
                                        Image(systemName: "pencil")
                                            .resizable()
                                            .foregroundColor(.black)
                                            .frame(width: 20, height: 20)
                                            .padding(8)
                                        Text("Sign here")
                                            .font(.footnote)
                                            .foregroundColor(.gray)
                                    }
                                })
                            }
                        }
                        .padding(.top, 16)
                        .padding(.horizontal, 3)
                        Button(action: {
                            // Save the image
                            saveImageAndCrop()
                        }) {
                            Text("Save")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color.blue)
                                .cornerRadius(8)
                        }
                    }
                    
                }
                .padding()
            }
        }.navigationTitle("E-Signature")
        .alert(item: $alertItem) { alertType in
            switch alertType {
            case .error(let message):
                return Alert(title: Text("Error"), message: Text(message), dismissButton: .default(Text("OK")))
            case .success(let message):
                return Alert(title: Text("Success"), message: Text(message), primaryButton: .default(Text("OK")) {
                }, secondaryButton: .cancel())
            }
    }
}
    private func takeSnapshot() -> UIImage? {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let window = windowScene.windows.first else {
            return nil
        }
        
        let renderer = UIGraphicsImageRenderer(bounds: window.bounds)
        return renderer.image { rendererContext in
            window.drawHierarchy(in: window.bounds, afterScreenUpdates: true)
        }
    }
    private func cropTopAndBottomThirds(from image: UIImage) -> UIImage? {
        guard let cgImage = image.cgImage else { return nil }
        
        // Calculate crop rectangle
        let cropRect = CGRect(x: 0,
                              y: CGFloat(cgImage.height) / 2.5,
                              width: CGFloat(cgImage.width),
                              height: CGFloat(cgImage.height) / 4)
        
        guard let croppedCGImage = cgImage.cropping(to: cropRect) else { return nil }
        
        return UIImage(cgImage: croppedCGImage)
    }
    func updateOrder(image:UIImage, completion: @escaping (Bool) -> Void) {
        Task {
            isLoading = true
            let order = OrderModel(id: orderId, userEmail: userEmail, userRole: userRole)
            apiManager.createOrderApi(order: order, image: image, route: "updateOrder") { result in
                switch result {
                case let .success((success, _)):
                    if success {
                        isLoading = false
                        completion(success)
                    } else {
                        isLoading = false
                        alertItem = .error(message: "Check Internet Connection.")
                        completion(false)
                    }
                case let .failure(error):
                    isLoading = false
                    alertItem = .error(message: error.localizedDescription)
                }
            }
        }
    }
}

#Preview {
    ESignView(signatureImage: .constant(.init()), signaturePDF: .constant(.init()), orderId: "65e4fd204d6e36d145cc4564")
}

extension ESignView {
    func saveImageAndCrop() {
        guard let snapshot = takeSnapshot() else {
            DispatchQueue.main.async {
                alertItem = .error(message: "Failed to capture snapshot.")
            }
            return
        }
        
        guard let croppedImage = cropTopAndBottomThirds(from: snapshot) else {
            DispatchQueue.main.async {
                alertItem = .error(message: "Failed to crop image.")
            }
            return
        }
        
        updateOrder(image: croppedImage) { success in
            DispatchQueue.main.async {
                isLoading = false
                if success {
                    // If the updateOrder was successful, navigate to the Previous Screen
                    presentationMode.wrappedValue.dismiss()
                } else {
                    // Handle error case if needed
                    alertItem = .error(message: "Failed to update order.")
                }
            }
        }
    }
}

