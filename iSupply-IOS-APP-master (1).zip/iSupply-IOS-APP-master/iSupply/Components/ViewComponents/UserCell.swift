//
//  UserCell.swift
//  iSupply
//
//  Created by hassan ghouri on 07/02/2024.
//

import SwiftUI

struct UserCell: View{

    let user:UserModel
    
    var body: some View {
            HStack{
                if let image = user.avatar {
                    AsyncImage(url: URL(string: Constants.imageBaseUrl+image)) { phase in
                        switch phase {
                        case .empty:
                            Image("avatar")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 57, height: 57)
                                .cornerRadius(15)
                        case .success(let image):
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 57, height: 57)
                                .cornerRadius(15)
                        default:
                            Image("avatar")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 57, height: 57)
                                .cornerRadius(15)
                        }
                    }
                }
                
                VStack(alignment: .leading, spacing: 10){
                    if let name = user.userName, let companyName = user.businessName{
                        Text(name)
                            .font(
                                Font.custom("Manrope", size: 16)
                                    .weight(.semibold)
                            )
                            .foregroundColor(Color(red: 0.12, green: 0.12, blue: 0.12))
                        Text(companyName)
                            .font(Font.custom("DM Sans", size: 10))
                            .foregroundColor(Color(red: 0.12, green: 0.12, blue: 0.12))
                    }else{
                        Text("Test User")
                            .font(
                                Font.custom("Manrope", size: 16)
                                    .weight(.semibold)
                            )
                            .foregroundColor(Color(red: 0.12, green: 0.12, blue: 0.12))
                        Text("Customer")
                            .font(Font.custom("DM Sans", size: 10))
                            .foregroundColor(Color(red: 0.12, green: 0.12, blue: 0.12))
                    }
                    
                }
                Spacer()
            }.foregroundColor(.clear)
                .background(.white)
                .cornerRadius(20)
                .frame(height: 100)
        
    }
}

#Preview {
    UserCell(user: UserModel(userName: "Hassan", email: "abc", password:"avdsa", avatar: "avatar",role: "User"))
}
