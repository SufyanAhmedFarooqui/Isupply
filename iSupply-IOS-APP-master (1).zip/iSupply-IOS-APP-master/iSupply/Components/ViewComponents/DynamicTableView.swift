//
//  OrdersTableView.swift
//  iSupply
//
//  Created by hassan ghouri on 21/03/2024.
//

import Foundation
import SwiftUI

struct DynamicTableView: View {
    let headers: [String]
    let rows: [[String]]
    let route:String?
    @AppStorage("userEmail") var userEmail = ""
    var body: some View {
        ScrollView {
            LazyVStack(spacing: 0) {
                TableHeaderView(headers: headers)
                ForEach(rows, id: \.self) { row in
                    NavigationLink {
                        if(route == "RequestPayment"){
                            SelectPayment(orderId: row.last ?? "", request: true)
                        }else if(route == "products"){
                            ProductScreen(request:false, email:userEmail,orderId:row.last ?? "")
                        }else if(route == "payment"){
                            SelectPayment(orderId: row.last ?? "", request:false)
                        }else if(route == "review"){
                            Review(orderId: row.last ?? "" , check: false)
                        }
                    } label: {
                        TableRowView(row: row)
                            .border(Color.gray, width: 0.5)
                    }

                    
                }
            }
        }
    }
}

struct TableHeaderView: View {
    let headers: [String]

    var body: some View {
        HStack {
            ForEach(headers, id: \.self) { header in
                Text(header)
                    .font(.headline)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal)
            }
        }
        .padding(.vertical, 5)
        .background(Color.gray.opacity(0.2))
        .border(Color.gray, width: 0.5)
    }
}

struct TableRowView: View {
    let row: [String]
    
    var body: some View {
        HStack {
            // Use prefix to take only the first three elements
            ForEach(Array(row.prefix(3)), id: \.self) { cell in
                Text(cell)
                    .padding(.horizontal)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(.vertical, 10)
        .overlay(
            RoundedRectangle(cornerRadius: 5)
                .stroke(Color.gray, lineWidth: 0.5)
        )
    }
}
// Preview
struct DynamicTableView_Previews: PreviewProvider {
    static var previews: some View {
        DynamicTableView(headers: ["Product", "Quantity", "Price", "Total"],
                         rows: [
                            ["Apple", "2", "$1.00", "$2.00"],
                            ["Banana", "5", "$0.50", "$2.50"]
                         ],route:"")
    }
}
