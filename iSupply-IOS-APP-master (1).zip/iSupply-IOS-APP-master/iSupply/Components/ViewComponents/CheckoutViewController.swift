import SwiftUI
import StripePaymentSheet
import Stripe

struct CheckoutView: View {
    @State private var paymentIntentClientSecret: String?
    @State private var isButtonEnabled = false
    var amount:Int = 20
    
    init(amount:Int){
        self.amount = amount
    }
    var body: some View {
        VStack {
            Button("Pay now") {
                pay()
            }
            .padding()
            .background(isButtonEnabled ? Color.blue : Color.gray)
            .foregroundColor(.white)
            .cornerRadius(5)
            .disabled(!isButtonEnabled)
        }
        .onAppear {
            fetchPaymentIntent()
        }
        .alert(isPresented: $showingAlert) {
            Alert(title: Text(alertTitle), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.clear)
    }

    // Environment variables and functions for handling Stripe payment sheet
    func fetchPaymentIntent() {
        let url = URL(string: Constants.apiBaseUrl + "create-payment-intent")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let shoppingCartContent: [String: Any] = ["amount": amount*100]
        request.httpBody = try? JSONSerialization.data(withJSONObject: shoppingCartContent)

        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data,
                  let response = response as? HTTPURLResponse,
                  response.statusCode == 200,
                  let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                  let clientSecret = json["clientSecret"] as? String else {
                self.alertTitle = "Error"
                self.alertMessage = error?.localizedDescription ?? "Failed to decode response from server."
                self.showingAlert = true
                return
            }

            DispatchQueue.main.async {
                self.paymentIntentClientSecret = clientSecret
                self.isButtonEnabled = true
            }
        }.resume()
    }

    func pay() {
        guard let clientSecret = paymentIntentClientSecret else {
            print("Client secret is nil")
            return
        }
        
        var configuration = PaymentSheet.Configuration()
        configuration.merchantDisplayName = "Example, Inc."

        // Optionally configure Apple Pay
        configuration.applePay = .init(merchantId: "your_merchant_id_here", merchantCountryCode: "US")

        let paymentSheet = PaymentSheet(paymentIntentClientSecret: clientSecret, configuration: configuration)
        
        
        // Get the current root view controller to present the payment sheet
        if let viewController = getRootViewController() {
            paymentSheet.present(from: viewController) { paymentResult in
                switch paymentResult {
                case .completed:
                    print("Payment successful")
                case .failed(let error):
                    print("Payment failed: \(error.localizedDescription)")
                case .canceled:
                    print("Payment canceled")
                }
            }
        } else {
            print("Failed to get root view controller")
        }
    }


    @State private var showingAlert = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
}

struct CheckoutView_Previews: PreviewProvider {
    static var previews: some View {
        CheckoutView(amount:20)
    }
}

extension View {
    func getRootViewController() -> UIViewController? {
        // Find the active window scene
        guard let windowScene = UIApplication.shared.connectedScenes
            .first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene else {
            return nil
        }
        // Find the key window and return its root view controller
        return windowScene.windows.first(where: { $0.isKeyWindow })?.rootViewController
    }
}
