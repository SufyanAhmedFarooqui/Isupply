//
//  ProductsTableView.swift
//  iSupply
//
//  Created by hassan ghouri on 26/02/2024.
//

import SwiftUI

struct ProductsTableView: View {
    let data: [OrderProduct] // Data to be displayed
    let orderId:String
    var body: some View {
        ScrollView {
            LazyVStack(spacing: 0) {
                TableRowHeaderView(header1: "Product", header2: "Quantity", header3: "Price", header4: "Total")
                ForEach(data.indices, id: \.self) { index in
                    TableRowContentView(row: data[index], orderId:orderId)
                        .border(Color.gray, width: 0.5)
                }
            }
        }
    }
}


struct TableRowHeaderView: View {
    var header1: String?
    var header2: String?
    var header3: String?
    var header4: String?
    
    var body: some View {
        HStack {
            Text(header1 ?? "Product")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading) // No change, as this is already set to take as much space as possible
            Divider()
            Text(header2 ?? "Quantity")
                .font(.headline)
                .frame(width: 60, alignment: .leading)
            Divider()
            Text(header3 ?? "Price")
                .font(.headline)
                .frame(width: 60, alignment: .leading)
            Divider()
            Text(header4 ?? "Total")
                .font(.headline)
                .frame(width: 80, alignment: .trailing)
        }
        .padding(.vertical, 5)
        .background(Color.gray.opacity(0.2))
        .border(Color.gray, width: 0.5)
    }
}

struct TableRowContentView: View {
    let row: OrderProduct
    let orderId: String
    @Environment(\.presentationMode) var presentationMode
    @StateObject private var viewModel = OrderProductViewModel()
    @State private var isLoading = true
    let orderApiManager = OrdersAPI.sharedInstance
    
    var productName: String {
        row.productName ?? ""
    }
    
    var quantityText: String {
        "\(row.quantity ?? 0)"
    }
    
    var priceText: String {
        if let price = row.price {
            return price.formatted()
        }
        return ""
    }
    
    var totalText: String {
        let total = (row.price ?? 0.0) * Double(row.quantity ?? 0)
        return total.formatted()
    }
    
    var body: some View {
        HStack {
            // Product Name
            Text(productName)
                .padding(.horizontal)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            Divider()
            
            // Quantity
            Text(quantityText)
                .padding(.horizontal)
                .frame(width: 80, alignment: .leading)
            
            Divider()
            
            // Price
            Text(priceText)
                .padding(.horizontal)
                .frame(width: 70, alignment: .leading)
            
            Divider()
            
            // Total + Delete Button
            VStack(alignment: .leading, spacing: 6) {
                Text(totalText)
                    .padding(.horizontal)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                Button(action: {
                    deleteProduct(orderId: orderId, productId: row.id ?? "")
                }) {
                    Image(systemName: "trash")
                        .foregroundColor(.white)
                        .padding(4)
                        .background(Color.red)
                        .clipShape(Circle())
                }
            }
            .frame(width: 80, alignment: .trailing)
        }
        .padding(.vertical, 10)
        .overlay(
            RoundedRectangle(cornerRadius: 0)
                .stroke(Color.gray, lineWidth: 0.5)
        )
    }
    func deleteProduct(orderId:String, productId:String){
        Task {
            isLoading = true
            print("delete Pressed")
            orderApiManager.deleteOrderProduct(orderId: orderId,productId:productId ,route:"deleteOrderProduct") { result in
                    switch result {
                        
                    case .success(_):
                        DispatchQueue.main.async {
                                // Make sure isLoading and other UI updates are on the main thread
                                isLoading = false
                                presentationMode.wrappedValue.dismiss()
                        }
                        isLoading = false
                        print("product Deleted")
                    case .failure(_):
                        // Handle the error
                        isLoading = false
                        print("delete Failure")
                    }
                }
        }
    }
}

