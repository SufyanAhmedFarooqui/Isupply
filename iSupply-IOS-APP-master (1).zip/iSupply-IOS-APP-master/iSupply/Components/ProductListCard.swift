//
//  ProductListCard.swift
//  iSupply
//
//  Created by Hassan Ghori on 24/08/2025.
//

import SwiftUI
struct ProductListCard: View {
    var product: ProductModel
    var backgroundColor: Color
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(product.name ?? "")
                    .font(.headline)
                Text("$\(String(format: "%.2f", product.price ?? 0.0)) | Stock: \(product.stock ?? 0)")
                    .font(.subheadline)
                    .foregroundColor(.green)
            }
            Spacer()
            
            if let imageName = product.images.first, let urlString = imageName {
                AsyncImage(url: URL(string: Constants.imageBaseUrl + urlString)) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                            .frame(width: 80, height: 80) // 👈 fixed
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                            .frame(width: 80, height: 80) // 👈 fixed square
                            .clipped()
                            .cornerRadius(10)
                    default:
                        Image("avatar")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 80, height: 80) // 👈 fixed
                            .clipped()
                            .cornerRadius(10)
                    }
                }
            } else {
                Image("avatar")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 80, height: 80) // 👈 fixed
                    .clipped()
                    .cornerRadius(10)
            }
        }
        .padding()
        .background(backgroundColor)
        .cornerRadius(10)
        .padding(.horizontal)
    }
}

#Preview {
    ProductListCard(product: ProductModel(id: "", name: "abc", category: "", brand: "", size: "", price: 10.0, flavourType: "", invoiceDescription: "", productType: "", itemCode: "11", stockThreshold: 10, stock: 10, salesMethod: "", images: [], userEmail: "", userRole: ""), backgroundColor: Color(.systemGray6))
}
