//
//  Constant.swift
//  iSupply
//
//  Created by hassan ghouri on 16/01/2024.
//

import Foundation

struct Constants {
    static let apiBaseUrl = "https://isupplypro.zapto.org:3000/api/"
    static let imageBaseUrl = "https://isupplypro.zapto.org:3000/uploads/"
}
