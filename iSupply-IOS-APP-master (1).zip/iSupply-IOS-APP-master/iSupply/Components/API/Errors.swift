//
//  NetworkError.swift
//  iSupply
//
//  Created by hassan ghouri on 19/02/2024.
//

import Foundation


protocol AuthenticationFormProtocol {
    var formIsValid:Bool {get}
}

// Define a custom SignInerror enum
enum SignInError: Error {
    case authenticationFailed(message: String)
    case emailExist
}


// Define NetworkError if not already defined
enum NetworkError: Error {
    case invalidURL
    case invalidImageData
    case invalidData
    case decodingError
    case requestFailed(Error)
    case badResponse(Int)
}

enum APIError: Error {
    case invalidURL
    case requestFailed
    case decodingError
    case serverError(String)
}
