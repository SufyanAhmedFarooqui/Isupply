//
//  ProductsAPI.swift
//  iSupply
//
//  Created by hassan ghouri on 11/02/2024.
//

import Foundation
import SwiftUI

final class ProductsAPI: ObservableObject {
    static let sharedInstance = ProductsAPI()
    let constInstance = Constants()
    
    func addProductApi(product: ProductModel, images: [UIImage]?, deletedImages: [String], route: String, completion: @escaping (Result<Bool, Error>) -> Void) {
        guard let url = URL(string: Constants.apiBaseUrl + route) else {
            completion(.failure(NetworkError.invalidURL))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let boundary = "Boundary-\(UUID().uuidString)"
        let contentType = "multipart/form-data; boundary=\(boundary)"
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")

        let body = NSMutableData()
        
        // Append user data to form data
        func addTextField(named name: String, value: String) {
            body.append(textFormField(named: name, value: value).data(using: .utf8)!)
        }

        func addTextField(named name: String, value: Int) {
            body.append(textFormField(named: name, value: value).data(using: .utf8)!)
        }
        func addTextField(named name: String, value: Double) {
            body.append(textFormField(named: name, value: value).data(using: .utf8)!)
        }
        func addTextField(named name: String, value: Float) {
            body.append(textFormField(named: name, value: value).data(using: .utf8)!)
        }
        func textFormField(named name: String, value: String) -> String {
            var fieldString = "--\(boundary)\r\n"
            fieldString += "Content-Disposition: form-data; name=\"\(name)\"\r\n"
            fieldString += "Content-Type: text/plain; charset=ISO-8859-1\r\n"
            fieldString += "Content-Transfer-Encoding: 8bit\r\n"
            fieldString += "\r\n"
            fieldString += "\(value)\r\n"
            return fieldString
        }

        func textFormField(named name: String, value: Int) -> String {
            var fieldString = "--\(boundary)\r\n"
            fieldString += "Content-Disposition: form-data; name=\"\(name)\"\r\n"
            fieldString += "Content-Type: text/plain; charset=ISO-8859-1\r\n"
            fieldString += "Content-Transfer-Encoding: 8bit\r\n"
            fieldString += "\r\n"
            fieldString += "\(value)\r\n"
            return fieldString
        }
        func textFormField(named name: String, value: Float) -> String {
            var fieldString = "--\(boundary)\r\n"
            fieldString += "Content-Disposition: form-data; name=\"\(name)\"\r\n"
            fieldString += "Content-Type: text/plain; charset=ISO-8859-1\r\n"
            fieldString += "Content-Transfer-Encoding: 8bit\r\n"
            fieldString += "\r\n"
            fieldString += "\(value)\r\n"
            return fieldString
        }
        func textFormField(named name: String, value: Double) -> String {
            var fieldString = "--\(boundary)\r\n"
            fieldString += "Content-Disposition: form-data; name=\"\(name)\"\r\n"
            fieldString += "Content-Type: text/plain; charset=ISO-8859-1\r\n"
            fieldString += "Content-Transfer-Encoding: 8bit\r\n"
            fieldString += "\r\n"
            fieldString += "\(value)\r\n"
            return fieldString
        }

        addTextField(named: "id", value: product.id ?? "")
        addTextField(named: "name", value: product.name ?? "")
        addTextField(named: "category", value: product.category ?? "")
        addTextField(named: "brand", value: product.brand ?? "")
        addTextField(named: "size", value: product.size ?? "")
        addTextField(named: "price", value: product.price ?? 0.0)
        addTextField(named: "flavourType", value: product.flavourType ?? "")
        addTextField(named: "invoiceDescription", value: product.invoiceDescription ?? "")
        addTextField(named: "productType", value: product.productType ?? "")
        addTextField(named: "itemCode", value: product.itemCode ?? "0")
        addTextField(named: "stockThreshold", value: product.stockThreshold ?? 0)
        addTextField(named: "stock", value: product.stock ?? 0)
        addTextField(named: "salesMethod", value: product.salesMethod ?? "")
        addTextField(named: "userEmail", value: product.userEmail ?? "")
        addTextField(named: "userRole", value: product.userRole ?? "")

        // Add deleted images as JSON
        let deletedImagesData = try? JSONSerialization.data(withJSONObject: deletedImages, options: [])
        if let deletedImagesData = deletedImagesData, let deletedImagesString = String(data: deletedImagesData, encoding: .utf8) {
            addTextField(named: "deletedImages", value: deletedImagesString)
        }

        // Function to append image data to the body
        func appendImageDataToBody(image: UIImage, boundary: String) {
            guard let imageData = image.jpegData(compressionQuality: 0.2) else {
                return
            }
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(product.name!).jpeg\"\r\n".data(using: .utf8)!)
            body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
            body.append(imageData)
            body.append("\r\n".data(using: .utf8)!)
        }

        // Append image data if available
        if let images = images {
            for image in images {
                appendImageDataToBody(image: image, boundary: boundary)
            }
        }
        
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body as Data
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            // Handle response data
            if let data = data {
                do {
                    let decodedMessage = try JSONDecoder().decode(APIResult.self, from: data)
                    if decodedMessage.message == "success" {
                        completion(.success(true))
                    } else {
                        // Handle other responses or errors
                        completion(.failure(NetworkError.invalidURL))
                    }
                } catch {
                    completion(.failure(error))
                }
            }
        }

        task.resume()
    }

    func getProducts(completion: @escaping (Result<[ProductModel], Error>) -> Void) {
        
        let url = URL(string: Constants.apiBaseUrl + "getProducts")!
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET"
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if error != nil{
                completion(.failure(NetworkError.invalidURL))
            }
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            if let data = data {
                do {
                    let decoder = JSONDecoder()
                    let decodedResponse = try decoder.decode([ProductModel].self, from: data) // Decode an array of Products
                    completion(.success(decodedResponse))
                } catch let error {
                    print("Decoding error: \(error)")
                    completion(.failure(NetworkError.decodingError))
                }
            }

        }
        
        task.resume()
    }
    
    func getTopSellingProduct(completion: @escaping (Result<TopSellingProductResult, Error>) -> Void) {
        
        let url = URL(string: Constants.apiBaseUrl + "topSellingProduct")!
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET"
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if error != nil{
                completion(.failure(NetworkError.invalidURL))
            }
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            if let data = data {
                do {
                    let decoder = JSONDecoder()
                    let decodedResponse = try decoder.decode(TopSellingProductResult.self, from: data) // Decode an array of Products
                    completion(.success(decodedResponse))
                } catch let error {
                    print("Decoding error: \(error)")
                    completion(.failure(NetworkError.decodingError))
                }
            }

        }
        
        task.resume()
    }
    
    func getProductById(id:String, route: String ,completion: @escaping (Result<ProductModel, Error>) -> Void) {
        
        let url = URL(string: Constants.apiBaseUrl + route)!
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        // Create a dictionary to hold the email parameter
        let requestBody: [String: String] = ["id": id]
        
        do {
            // Encode the request body as JSON data
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
            urlRequest.httpBody = jsonData // Set the request body
        } catch {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if error != nil{
                completion(.failure(NetworkError.invalidURL))
            }
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            if let data = data {
                do {
                    let decoder = JSONDecoder()
                    let decodedResponse = try decoder.decode(ProductModel.self, from: data) // Decode an array of Products
                    completion(.success(decodedResponse))
                } catch let error {
                    print("Decoding error: \(error)")
                    completion(.failure(NetworkError.decodingError))
                }
            }

        }
        
        task.resume()
    }
    
    func getProductsByEmail(email:String,role:String?, route: String ,completion: @escaping (Result<[ProductModel], Error>) -> Void) {
        
        let url = URL(string: Constants.apiBaseUrl + route)!
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Create a dictionary to hold the email parameter
        let requestBody: [String: String] = ["email": email,"userRole":role ?? ""]
        
        do {
            // Encode the request body as JSON data
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
            urlRequest.httpBody = jsonData // Set the request body
        } catch {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if error != nil{
                completion(.failure(NetworkError.invalidURL))
            }
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            if let data = data {
                do {
                    let decoder = JSONDecoder()
                    let decodedResponse = try decoder.decode([ProductModel].self, from: data)
                    DispatchQueue.main.async {
                        completion(.success(decodedResponse))
                    }
                } catch {
                    completion(.failure(NetworkError.decodingError))
                }
            }

        }
        
        task.resume()
    }

    func getProductsByDateRange(email: String?, fromDate: Date, toDate: Date, route: String, completion: @escaping (Result<[ProductModel], Error>) -> Void) {
        
        guard let url = URL(string: Constants.apiBaseUrl + route) else {
            completion(.failure(NetworkError.invalidURL))
            return
        }
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd" // Adjust date format to match your backend requirements

        // Create a dictionary to hold the parameters
        var requestBody: [String: String] = [
            "fromDate": formatter.string(from: fromDate),
            "toDate": formatter.string(from: toDate)
        ]
        
        if let email = email {
            requestBody["email"] = email
        }
        
        do {
            // Encode the request body as JSON data
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
            urlRequest.httpBody = jsonData
        } catch {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let response = response as? HTTPURLResponse else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            if response.statusCode != 200 {
                completion(.failure(NetworkError.invalidData))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.decodingError))
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let decodedResponse = try decoder.decode([ProductModel].self, from: data)
                completion(.success(decodedResponse))
            } catch {
                completion(.failure(NetworkError.decodingError))
            }
        }
        
        task.resume()
    }

}


