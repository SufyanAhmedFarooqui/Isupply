import Foundation
import SwiftUI


final class UsersAPI {
    static let sharedInstance = UsersAPI()
    let constInstance = Constants()
    
    func signApi(user: UserModel, completion: @escaping (Result<(success: Bool, role: String?,name:String?), Error>) -> Void) async throws  {
        
        let url = URL(string: Constants.apiBaseUrl + "login")!
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        
        do {
            let requestBody = try JSONEncoder().encode(user)
            urlRequest.httpBody = requestBody
            urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        } catch {
            throw error
        }
        
        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let err = error{
                completion(.failure(err))
            }
            if let data = data{
                do {
                    // Step 2: Decode Data into your model
                    let decodedMessage = try JSONDecoder().decode(AuthModel.self, from: data)
                    if(decodedMessage.message == "Authentication successful"){
                        let success = true
                        let role = decodedMessage.role
                        let name = decodedMessage.name
                        completion(.success((success, role , name)))
                    }else{
                        let success = false
                        let role = decodedMessage.role
                        let name = decodedMessage.name
                        completion(.success((success, role, name)))
                    }
                } catch {
                    completion(.failure(error))
                    print(error.localizedDescription)
                }
                
            }
            
        }
        
        task.resume()
    }
    


    func signUpApi(user: UserModel, image: UIImage?,route:String, completion: @escaping (Result<Bool, Error>) -> Void) {
        guard let url = URL(string: Constants.apiBaseUrl + route) else {
            completion(.failure(NetworkError.invalidURL))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let boundary = "Boundary-\(UUID().uuidString)"
        let contentType = "multipart/form-data; boundary=\(boundary)"
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")

        let body = NSMutableData()
        
        // Append user data to form data
        func addTextField(named name: String, value: String) {
            body.append(textFormField(named: name, value: value).data(using: .utf8)!)
            }

        func textFormField(named name: String, value: String) -> String {
                var fieldString = "--\(boundary)\r\n"
                fieldString += "Content-Disposition: form-data; name=\"\(name)\"\r\n"
                fieldString += "Content-Type: text/plain; charset=ISO-8859-1\r\n"
                fieldString += "Content-Transfer-Encoding: 8bit\r\n"
                fieldString += "\r\n"
                fieldString += "\(value)\r\n"

                return fieldString
            }
        addTextField(named: "name", value: user.name ?? "")
        addTextField(named: "email", value: user.email ?? "")
        addTextField(named: "telephone", value: user.telephone ?? "")
        addTextField(named: "accNumber", value: user.accNumber ?? "")
        addTextField(named: "businessName", value: user.businessName ?? "")
        addTextField(named: "city", value: user.city ?? "")
        addTextField(named: "direct", value: user.direct ?? "")
        addTextField(named: "contactPersonName", value: user.direct ?? "")
        addTextField(named: "userName", value: user.userName ?? "")
        addTextField(named: "password", value: user.password ?? "")
        addTextField(named: "address", value: user.address ?? "")
        addTextField(named: "role", value: user.role ?? "")
        addTextField(named: "createdBy", value: user.createdBy ?? "")
        // Append image data if available
        if let imageData = image?.jpegData(compressionQuality: 0.2) {
            body.append("--\(boundary)\r\n" .data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"file\"; filename=\"avatar.jpeg\"\r\n".data(using: .utf8)!)
            body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
            body.append(imageData)
            body.append("\r\n".data(using: .utf8)!)
            
        }
        let encoder = JSONEncoder()
        // Add the associatedUsers array as JSON data
        if user.associatedUsers.isEmpty {
            // If the associatedUsers array is empty, encode an empty array
            if let emptyData = try? encoder.encode([AssociatedUsers]()) {
                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"associatedUsers\"\r\n\r\n".data(using: .utf8)!)
                body.append(emptyData)
                body.append("\r\n".data(using: .utf8)!)
            }
        } else {
            // If the associatedUsers array is not empty, encode it normally
            if let jsonData = try? encoder.encode(user.associatedUsers) {
                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"associatedUsers\"\r\n\r\n".data(using: .utf8)!)
                body.append(jsonData)
                body.append("\r\n".data(using: .utf8)!)
            }
        }

        // Add the truckStock array as JSON data
        if user.truckStock.isEmpty {
            // If the truckStock array is empty, encode an empty array
            if let emptyData = try? encoder.encode([truckStock]()) {
                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"truckStock\"\r\n\r\n".data(using: .utf8)!)
                body.append(emptyData)
                body.append("\r\n".data(using: .utf8)!)
            }
        } else {
            // If the truckStock array is not empty, encode it normally
            if let jsonData = try? encoder.encode(user.truckStock) {
                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"truckStock\"\r\n\r\n".data(using: .utf8)!)
                body.append(jsonData)
                body.append("\r\n".data(using: .utf8)!)
            }
        }

        
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body as Data
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            // Handle response data
            if let data = data {
                do {
                    
                    let decodedMessage = try JSONDecoder().decode(APIResult.self, from: data)
                    if decodedMessage.message == "success" {
                        completion(.success(true))
                    } else if decodedMessage.message == "Mail Exists" {
                        completion(.failure(SignInError.emailExist))
                    } else {
                        // Handle other responses or errors
                        completion(.failure(NetworkError.invalidURL))
                    }
                } catch {
                    completion(.failure(error))
                }
            }
        }

        task.resume()
    }

    struct UserRequestBody: Codable {
        let email: String
        let truckStock: [truckStock?]
    }

    func updateTruckStock(user: UserModel, completion: @escaping (Result<Bool, Error>) -> Void) {
        guard let url = URL(string: Constants.apiBaseUrl + "updateTruckStock") else {
            completion(.failure(NetworkError.invalidURL))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Create a UserRequestBody object
        let requestBody = UserRequestBody(email: user.email ?? "", truckStock: user.truckStock )
        do {
            // Encode the request body as JSON data
            let jsonData = try JSONEncoder().encode(requestBody)
            
            // Set the request body
            request.httpBody = jsonData
            
            // Set the appropriate content type header
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            // Perform the request
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    completion(.failure(error))
                    return
                }
                
                // Handle response data
                if let data = data {
                    do {
                        let decodedMessage = try JSONDecoder().decode(APIResult.self, from: data)
                        if decodedMessage.message == "success" {
                            completion(.success(true))
                        }else {
                            // Handle other responses or errors
                            completion(.failure(NetworkError.invalidURL))
                        }
                    } catch {
                        completion(.failure(error))
                    }
                }
            }
            
            task.resume()
        } catch {
            completion(.failure(error))
        }
    }
    
    func getTruckStockByProductId(productId:String,completion: @escaping (Result<String, Error>) -> Void) {
        
        let url = URL(string: Constants.apiBaseUrl + "getTruckStock/\(productId)")!
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET"
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if error != nil{
                completion(.failure(NetworkError.invalidURL))
            }
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            if let data = data {
                do {
                    let decoder = JSONDecoder()
                    let decodedResponse = try decoder.decode(APIResult.self, from: data)
                    print(decodedResponse)
                    if let stock = decodedResponse.message{
                        completion(.success(stock))
                    }else{
                        completion(.success(""))
                    }
                    
                } catch let error {
                    print("Decoding error: \(error)")
                    completion(.failure(NetworkError.decodingError))
                }
            }

        }
        
        task.resume()
    }

    func getUserByEmail(email: String, route:String, completion: @escaping (Result<[UserModel], Error>) -> Void) {
        let url = URL(string: Constants.apiBaseUrl + route)! // Update the endpoint URL
        
        // Prepare the request
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST" // Change the HTTP method to POST
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Create a dictionary to hold the email parameter
        let requestBody: [String: String] = ["email": email]
        
        do {
            // Encode the request body as JSON data
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
            urlRequest.httpBody = jsonData // Set the request body
        } catch {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        // Perform the request
        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            // Decode the response data
            do {
                let decoder = JSONDecoder()
                let decodedResponse = try decoder.decode([UserModel].self, from: data)
                completion(.success(decodedResponse))
            } catch {
                completion(.failure(NetworkError.decodingError))
            }
        }
        
        task.resume()
    }
    
    func resetPasswordAndDelete(email: String,route: String, completion: @escaping (Result<APIResult, Error>) -> Void) {
        let url = URL(string: Constants.apiBaseUrl + route)! // Update the endpoint URL
        var method = "POST"
        if(route == "deleteUser"){
            method = "DELETE"
        }
        // Prepare the request
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = method // Change the HTTP method to POST
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Create a dictionary to hold the email parameter
        let requestBody: [String: String] = ["email": email]
        
        do {
            // Encode the request body as JSON data
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
            urlRequest.httpBody = jsonData // Set the request body
        } catch {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        // Perform the request
        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            // Decode the response data
            do {
                let decoder = JSONDecoder()
                let decodedResponse = try decoder.decode(APIResult.self, from: data)
                completion(.success(decodedResponse))
            } catch {
                completion(.failure(NetworkError.decodingError))
            }
        }
        
        task.resume()
    }
    
    func deleteById(id: String,route: String, completion: @escaping (Result<APIResult, Error>) -> Void) {
        let url = URL(string: Constants.apiBaseUrl + route)! // Update the endpoint URL
        // Prepare the request
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "DELETE" // Change the HTTP method to DELETE
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Create a dictionary to hold the email parameter
        let requestBody: [String: String] = ["id": id]
        
        do {
            // Encode the request body as JSON data
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
            urlRequest.httpBody = jsonData // Set the request body
        } catch {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        // Perform the request
        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            // Decode the response data
            do {
                let decoder = JSONDecoder()
                let decodedResponse = try decoder.decode(APIResult.self, from: data)
                completion(.success(decodedResponse))
            } catch {
                completion(.failure(NetworkError.decodingError))
            }
        }
        
        task.resume()
    }
    
    func getTopSeller(completion: @escaping (Result<UserModel, Error>) -> Void) {
        let url = URL(string: Constants.apiBaseUrl + "topSeller")! // Update the endpoint URL
        
        // Prepare the request
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET" // Change the HTTP method to POST
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")

        // Perform the request
        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            // Decode the response data
            do {
                let decoder = JSONDecoder()
                let decodedResponse = try decoder.decode(UserModel.self, from: data)
                completion(.success(decodedResponse))
            } catch {
                completion(.failure(NetworkError.decodingError))
            }
        }
        
        task.resume()
    }
    
    func getUserDetailsForInvoice(vendorEmail: String, customerEmail:String, route:String, completion: @escaping (Result<[UserModel], Error>) -> Void) {
        let url = URL(string: Constants.apiBaseUrl + route)! // Update the endpoint URL
        
        // Prepare the request
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST" // Change the HTTP method to POST
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Create a dictionary to hold the email parameter
        let requestBody: [String: String] = ["vendorEmail": vendorEmail, "customerEmail":customerEmail]
        
        do {
            // Encode the request body as JSON data
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
            urlRequest.httpBody = jsonData // Set the request body
        } catch {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        // Perform the request
        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            // Decode the response data
            do {
                let decoder = JSONDecoder()
                let decodedResponse = try decoder.decode([UserModel].self, from: data)
                completion(.success(decodedResponse))
            } catch {
                completion(.failure(NetworkError.decodingError))
            }
        }
        
        task.resume()
    }
    
    func saveLocationToDatabase(email:String, lat: Double, lng: Double,route:String,completion: @escaping (Result<Bool, APIError>) -> Void) {
        guard let url = URL(string: Constants.apiBaseUrl + route) else {
            completion(.failure(.invalidURL))
            return
        }
        
        let body: [String: Any] = ["email":email,"lat": lat, "lng": lng]
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: body)
            request.httpBody = jsonData
        } catch {
            completion(.failure(.requestFailed))
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(.serverError(error.localizedDescription)))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                completion(.failure(.serverError("Invalid response from server")))
                return
            }
            
            completion(.success(true))
        }.resume()
    }

    func checkUser(email: String,userEmail:String,userRole:String, completion: @escaping (Result<Bool, Error>) -> Void) {
        let url = URL(string: Constants.apiBaseUrl + "checkUser")! // Update the endpoint URL
        
        // Prepare the request
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST" // Change the HTTP method to POST
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Create a dictionary to hold the email parameter
        let requestBody: [String: String] = ["email": email,"userEmail":userEmail,"userRole":userRole]
        
        do {
            // Encode the request body as JSON data
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
            urlRequest.httpBody = jsonData // Set the request body
        } catch {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        // Perform the request
        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            // Decode the response data
            // Decode the response data
            do {
                let decoder = JSONDecoder()
                let decodedResponse = try decoder.decode(APIResult.self, from: data)
                print(decodedResponse.message!)
                if decodedResponse.message == "success" {
                    completion(.success(true))
                } else if decodedResponse.message == "User does not exist" {
                    completion(.success(false))
                } else {
                    // Handle other responses or errors
                    completion(.failure(NetworkError.invalidURL))
                }
            } catch {
                completion(.failure(NetworkError.decodingError))
            }
        }
        
        task.resume()
    }
    func loadImageAsync(from url: URL, completion: @escaping (UIImage?) -> Void) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                // Handle error
                print("Failed to load image:", error?.localizedDescription ?? "Unknown error")
                completion(nil)
                return
            }
            
            if let image = UIImage(data: data) {
                // Image loaded successfully
                completion(image)
            } else {
                // Failed to create UIImage from data
                print("Failed to create UIImage from data")
                completion(nil)
            }
        }.resume()
    }


}


