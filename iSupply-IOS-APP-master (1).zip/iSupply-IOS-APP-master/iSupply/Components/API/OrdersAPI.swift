//
//  OrdersAPI.swift
//  iSupply
//
//  Created by hassan ghouri on 01/03/2024.
//

import Foundation
import SwiftUI

final class OrdersAPI: ObservableObject,OrdersAPIProtocol {
    static let sharedInstance = OrdersAPI()
    let constInstance = Constants()
    
    func createOrderApi(order: OrderModel, image: UIImage? ,route:String, completion: @escaping (Result<(success: Bool, id: String?), Error>) -> Void){
        guard let url = URL(string: Constants.apiBaseUrl + route) else {
            completion(.failure(NetworkError.invalidURL))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let boundary = "Boundary-\(UUID().uuidString)"
        let contentType = "multipart/form-data; boundary=\(boundary)"
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")

        let body = NSMutableData()
        
        // Append user data to form data
        func addTextField(named name: String, value: String) {
            body.append(textFormField(named: name, value: value).data(using: .utf8)!)
        }

        func addTextField(named name: String, value: Int) {
            body.append(textFormField(named: name, value: value).data(using: .utf8)!)
        }
        
        func addTextField(named name: String, value: Float) {
            body.append(textFormField(named: name, value: value).data(using: .utf8)!)
        }
        func addTextField(named name: String, value: Double) {
            body.append(textFormField(named: name, value: value).data(using: .utf8)!)
        }

        func textFormField(named name: String, value: String) -> String {
                var fieldString = "--\(boundary)\r\n"
                fieldString += "Content-Disposition: form-data; name=\"\(name)\"\r\n"
                fieldString += "Content-Type: text/plain; charset=ISO-8859-1\r\n"
                fieldString += "Content-Transfer-Encoding: 8bit\r\n"
                fieldString += "\r\n"
                fieldString += "\(value)\r\n"

                return fieldString
            }
        func textFormField(named name: String, value: Int) -> String {
                var fieldString = "--\(boundary)\r\n"
                fieldString += "Content-Disposition: form-data; name=\"\(name)\"\r\n"
                fieldString += "Content-Type: text/plain; charset=ISO-8859-1\r\n"
                fieldString += "Content-Transfer-Encoding: 8bit\r\n"
                fieldString += "\r\n"
                fieldString += "\(value)\r\n"

                return fieldString
            }
        func textFormField(named name: String, value: Float) -> String {
                var fieldString = "--\(boundary)\r\n"
                fieldString += "Content-Disposition: form-data; name=\"\(name)\"\r\n"
                fieldString += "Content-Type: text/plain; charset=ISO-8859-1\r\n"
                fieldString += "Content-Transfer-Encoding: 8bit\r\n"
                fieldString += "\r\n"
                fieldString += "\(value)\r\n"

                return fieldString
            }
        func textFormField(named name: String, value: Double) -> String {
                var fieldString = "--\(boundary)\r\n"
                fieldString += "Content-Disposition: form-data; name=\"\(name)\"\r\n"
                fieldString += "Content-Type: text/plain; charset=ISO-8859-1\r\n"
                fieldString += "Content-Transfer-Encoding: 8bit\r\n"
                fieldString += "\r\n"
                fieldString += "\(value)\r\n"

                return fieldString
            }
        if(route == "updateOrder"){
            addTextField(named: "id", value: order.id ?? "")
        }
        addTextField(named: "userEmail", value: order.userEmail ?? "")
        addTextField(named: "userRole", value: order.userRole ?? "")
        addTextField(named: "customerEmail", value: order.customerEmail ?? "")
        addTextField(named: "vendorEmail", value: order.vendorEmail ?? "")
        addTextField(named: "businessName", value: order.businessName ?? "")
        addTextField(named: "customerName", value: order.customerName ?? "")
        addTextField(named: "customerAddress", value: order.customerAddress ?? "")
        addTextField(named: "customerPhone", value: order.customerPhone ?? "")
        addTextField(named: "totalAmount", value: order.totalAmount ?? 0.0)
        addTextField(named: "paymentMethod", value: order.paymentMethod ?? "")
        addTextField(named: "paymentDetail", value: order.paymentDetail ?? "")
        addTextField(named: "adjustmentType", value: order.adjustmentType ?? "")
        addTextField(named: "adjustment", value: order.adjustment ?? 0)
        addTextField(named: "discount", value: order.discount ?? 0)
        addTextField(named: "credit", value: order.credit ?? 0)
        addTextField(named: "notes", value: order.notes ?? "")
        addTextField(named: "paymentAmount", value: order.paymentAmount ?? 0)
        addTextField(named: "status", value: order.status ?? "")
        addTextField(named: "paymentStatus", value: order.paymentStatus ?? "")
        addTextField(named: "invoiceNumber", value: order.invoiceNumber ?? "")
        addTextField(named: "invoice", value: order.invoice ?? "")
        
        // Add the products array as JSON data
        let encoder = JSONEncoder()
        if order.products.isEmpty {
            // If the products array is empty, encode an empty array
            if let emptyData = try? encoder.encode([OrderProduct]()) {
                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"products\"\r\n\r\n".data(using: .utf8)!)
                body.append(emptyData)
                body.append("\r\n".data(using: .utf8)!)
            }
        } else {
            // If the products array is not empty, encode it normally
            if let jsonData = try? encoder.encode(order.products) {
                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"products\"\r\n\r\n".data(using: .utf8)!)
                body.append(jsonData)
                body.append("\r\n".data(using: .utf8)!)
            }
        }

        
        // Add the eSign image if available
        if let eSignImage = image, let imageData = eSignImage.jpegData(compressionQuality: 1.0) {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"eSign\"; filename=\"eSign.jpg\"\r\n".data(using: .utf8)!)
            body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
            body.append(imageData)
            body.append("\r\n".data(using: .utf8)!)
        }
        
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body as Data
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            // Handle response data
            if let data = data {
                do {
                    
                    let decodedMessage = try JSONDecoder().decode(APIResult.self, from: data)
                    if decodedMessage.message == "success" {
                        let success = true
                        let id = decodedMessage.id
                        completion(.success((success, id)))
                    }else {
                        // Handle other responses or errors
                        completion(.failure(NetworkError.invalidURL))
                    }
                } catch {
                    completion(.failure(error))
                }
            }
        }

        
        task.resume()
    }
    
    func getProducts(orderId: String, completion: @escaping (Result<[OrderProduct], Error>) -> Void) {
        let url = URL(string: Constants.apiBaseUrl + "getOrderProducts")!
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Construct the request body
        let requestBody: [String: Any] = ["orderId": orderId]
        do {
            urlRequest.httpBody = try JSONSerialization.data(withJSONObject: requestBody, options: [])
        } catch {
            completion(.failure(error))
            return
        }

        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            if let data = data {
                do {
                    let decoder = JSONDecoder()
                    let decodedResponse = try decoder.decode([OrderProduct].self, from: data)
                    completion(.success(decodedResponse))
                } catch {
                    print("Decoding error: \(error)")
                    completion(.failure(NetworkError.decodingError))
                }
            }
        }
        
        task.resume()
    }
    
    func generateInvoiceNumber(orderId: String, businessName:String , completion: @escaping (Result<String, Error>) -> Void) {
        let url = URL(string: Constants.apiBaseUrl + "generateInvoiceNumber")!
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Construct the request body
        let requestBody: [String: Any] = ["orderId": orderId, "businessName": businessName]
        do {
            urlRequest.httpBody = try JSONSerialization.data(withJSONObject: requestBody, options: [])
        } catch {
            completion(.failure(error))
            return
        }

        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            if let data = data {
                do {
                    let decoder = JSONDecoder()
                    let decodedResponse = try decoder.decode(AuthModel.self, from: data)
                    completion(.success(decodedResponse.message!))
                } catch {
                    print("Decoding error: \(error)")
                    completion(.failure(NetworkError.decodingError))
                }
            }
        }
        
        task.resume()
    }

    func getOrder(orderId: String, completion: @escaping (Result<OrderModel, Error>) -> Void) {
        let url = URL(string: Constants.apiBaseUrl + "getOrder/\(orderId)")!
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET"
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            if let data = data {
                do {
                    let decoder = JSONDecoder.customDateDecoder
                    let decodedResponse = try decoder.decode(OrderModel.self, from: data)
                    completion(.success(decodedResponse))
                } catch {
                    print("Decoding error: \(error)")
                    completion(.failure(NetworkError.decodingError))
                }
            }
        }
        
        task.resume()
    }
    
    func fetchOrders(email: String,role:String, status: String, route: String, completion: @escaping (Result<[OrderModel], NetworkError>) -> Void) {
        guard let url = URL(string: Constants.apiBaseUrl + route) else {
            completion(.failure(.invalidURL))
            return
        }
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        var requestBody:[String:String] = [:]
        // Prepare request body
        if (role == "Customer"){
            requestBody = ["customerEmail": email, "status": status]
        }else if (role == "Sales Person"){
            requestBody = ["userEmail": email, "status": status]
        }else{
            requestBody = ["vendorEmail": email, "status": status]
        }
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
            urlRequest.httpBody = jsonData
        } catch {
            completion(.failure(.requestFailed(error)))
            return
        }
        
        // Execute the network request
        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(.requestFailed(error)))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                completion(.failure(.badResponse(-1)))
                return
            }
            
            guard httpResponse.statusCode == 200 else {
                completion(.failure(.badResponse(httpResponse.statusCode)))
                return
            }
            
            guard let data = data else {
                completion(.failure(.decodingError))
                return
            }
            print(data)
            do {
                let decoder = JSONDecoder.customDateDecoder
                let orders = try decoder.decode([OrderModel].self, from: data)
                completion(.success(orders))
                print("Decoded orders: \(orders.count)")
            } catch {
                completion(.failure(.decodingError))
                print("Decoding Error")
            }
        }
        
        task.resume()
    }
    
    func deleteOrderProduct(orderId: String, productId:String,route: String, completion: @escaping (Result<APIResult, Error>) -> Void) {
        let url = URL(string: Constants.apiBaseUrl + route)! // Update the endpoint URL
        // Prepare the request
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "DELETE" // Change the HTTP method to DELETE
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        // Create a dictionary to hold the email parameter
        let requestBody: [String: String] = ["orderId": orderId, "productId":productId]
        
        do {
            // Encode the request body as JSON data
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
            urlRequest.httpBody = jsonData // Set the request body
        } catch {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        // Perform the request
        let task = URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.invalidURL))
                return
            }
            
            // Decode the response data
            do {
                let decoder = JSONDecoder()
                let decodedResponse = try decoder.decode(APIResult.self, from: data)
                
                completion(.success(decodedResponse))
            } catch {
                completion(.failure(NetworkError.decodingError))
            }
        }
        
        task.resume()
    }
}


protocol OrdersAPIProtocol {
    func createOrderApi(order: OrderModel, image: UIImage?, route: String, completion: @escaping (Result<(success: Bool, id: String?), Error>) -> Void)
    func getProducts(orderId: String, completion: @escaping (Result<[OrderProduct], Error>) -> Void)
    func generateInvoiceNumber(orderId: String, businessName: String, completion: @escaping (Result<String, Error>) -> Void)
    func getOrder(orderId: String, completion: @escaping (Result<OrderModel, Error>) -> Void)
    func fetchOrders(email: String,role:String, status: String, route: String, completion: @escaping (Result<[OrderModel], NetworkError>) -> Void)
    func deleteOrderProduct(orderId: String, productId:String,route: String, completion: @escaping (Result<APIResult, Error>) -> Void)
}

extension DateFormatter {
    static let iso8601Full: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        formatter.calendar = Calendar(identifier: .iso8601)
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        return formatter
    }()
}

extension JSONDecoder {
    static let customDateDecoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .custom { decoder -> Date in
            let container = try decoder.singleValueContainer()
            let dateString = try container.decode(String.self)
            if let date = DateFormatter.iso8601Full.date(from: dateString) {
                return date
            }
            throw DecodingError.dataCorruptedError(in: container,
                                                   debugDescription: "Invalid date: \(dateString)")
        }
        return decoder
    }()
}
