//
//  File.swift
//  iSupply
//
//  Created by hassan ghouri on 22/01/2024.
//


import Foundation
struct AuthModel : Codable {
    let message : String?
    let token : String?
    let role: String?
    let name: String?
    
    
    enum CodingKeys: String, CodingKey {

        case message = "message"
        case token = "token"
        case role = "role"
        case name = "name"
        
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        token = try values.decodeIfPresent(String.self, forKey: .token)
        role = try values.decodeIfPresent(String.self, forKey: .role)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        
    }

}
