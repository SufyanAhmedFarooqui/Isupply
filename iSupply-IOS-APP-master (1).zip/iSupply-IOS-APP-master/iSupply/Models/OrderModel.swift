import Foundation

struct OrderModel: Identifiable, Codable {
    let id: String?
    let logo: String?
    let userEmail: String?
    let userRole: String?
    let customerName: String?
    let businessName: String?
    let customerEmail: String?
    let customerAddress: String?
    let customerPhone: String?
    let vendorEmail: String?
    let vendorPhone: String?
    let vendorName: String?
    let vendorAddress: String?
    let products: [OrderProduct]   // ✅ Fixed
    let totalAmount: Double?
    let paymentMethod: String?
    let paymentDetail: String?
    let adjustmentType: String?
    let adjustment: Double?        // ✅ Use Double
    let discount: Double?          // ✅ Changed from Int
    let credit: Double?            // ✅ Changed from Int
    let notes: String?
    let paymentAmount: Double?     // ✅ Changed from Int
    let eSign: String?
    let status: String?
    let paymentStatus: String?
    let requestId: String?
    let invoiceNumber: String?
    let invoice: String?
    let createdAt: Date?           // ✅ Handled by custom decoder
    
    // Custom initializer to provide default values for optional properties
    init(id: String? = nil, logo:String? = nil , userEmail: String? = nil, userRole: String? = nil, customerName: String? = nil, customerEmail: String? = nil,vendorEmail:String? = nil,vendorName:String? = nil,vendorPhone:String? = nil,vendorAddress:String? = nil,businessName: String? = nil,customerAddress:String? = nil,customerPhone:String? = nil, products: [OrderProduct] = [], totalAmount: Double? = nil, paymentMethod: String? = nil, paymentDetail: String? = nil, adjustmentType: String? = nil, adjustment: Double? = nil, discount: Double? = nil,credit:Double? = nil ,notes: String? = nil, paymentAmount: Double? = nil, eSign: String? = nil, status: String? = nil, paymentStatus:String? = nil,requestId:String? = nil, invoiceNumber:String? = nil, invoice:String? = nil, createdAt:Date? = nil) {
        self.id = id
        self.userEmail = userEmail
        self.userRole = userRole
        self.logo = logo
        self.customerName = customerName
        self.businessName = businessName
        self.customerEmail = customerEmail
        self.customerPhone = customerPhone
        self.customerAddress = customerAddress
        self.vendorEmail = vendorEmail
        self.vendorName = vendorName
        self.vendorPhone = vendorPhone
        self.vendorAddress = vendorAddress
        self.products = products
        self.totalAmount = totalAmount
        self.paymentMethod = paymentMethod
        self.paymentDetail = paymentDetail
        self.adjustmentType = adjustmentType
        self.adjustment = adjustment
        self.discount = discount
        self.credit = credit
        self.notes = notes
        self.paymentAmount = paymentAmount
        self.eSign = eSign
        self.status = status
        self.paymentStatus = paymentStatus
        self.requestId = requestId
        self.invoiceNumber = invoiceNumber
        self.invoice = invoice
        self.createdAt = createdAt
    }
}


struct OrderProduct: Identifiable, Codable, Equatable {
    let id: String?
    let productCode: String?
    let productName: String?
    let quantity: Int?
    let price: Double?   // ✅ Changed from Float (JSON has decimals)

    static func == (lhs: OrderProduct, rhs: OrderProduct) -> Bool {
        lhs.id == rhs.id
    }
    init(id: String? = nil, productCode:String? = nil, productName: String? = nil, quantity: Int? = nil, price: Double? = nil) {
            self.id = id
            self.productCode = productCode
            self.productName = productName
            self.quantity = quantity
            self.price = price }
}


