import Foundation

struct ProductModel: Identifiable, Codable {
    let id: String?
    let name: String?
    let category: String?
    let brand: String?
    let size: String?
    let price: Float?
    let flavourType: String?
    let invoiceDescription: String?
    let productType: String?
    let itemCode: String?
    let stockThreshold: Int?
    let stock: Int?
    let tempStock: Int?
    let salesMethod: String?
    let images: [String?] // Array of optional strings for image URLs
    let userEmail: String? // Optional user email
    let userRole: String? // Optional user role
    
    // Custom initializer to provide default values for optional properties
    init(id: String? = nil ,name: String? = nil, category: String? = nil, brand: String? = nil, size: String? = nil, price: Float? = nil, flavourType: String? = nil, invoiceDescription: String? = nil, productType: String? = nil, itemCode: String? = nil, stockThreshold: Int? = nil, stock: Int? = nil, tempStock:Int? = nil,salesMethod: String? = nil, images: [String?] = [], userEmail: String? = nil, userRole: String? = nil) {
        self.id = id
        self.name = name
        self.category = category
        self.brand = brand
        self.size = size
        self.price = price
        self.flavourType = flavourType
        self.invoiceDescription = invoiceDescription
        self.productType = productType
        self.itemCode = itemCode
        self.stockThreshold = stockThreshold
        self.stock = stock
        self.tempStock = tempStock
        self.salesMethod = salesMethod
        self.images = images
        self.userEmail = userEmail
        self.userRole = userRole
    }
}
