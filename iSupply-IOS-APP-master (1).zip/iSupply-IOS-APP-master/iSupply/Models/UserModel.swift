//
//  UserModel.swift
//  iSupply
//
//  Created by hassan ghouri on 16/01/2024.
//

import Foundation

struct UserModel: Identifiable, Codable {
    var id: UUID? // Make id optional
    let userName: String?
    let email: String?
    let password: String?
    let avatar: String?
    let telephone: String?
    let accNumber: String?
    let businessName: String?
    let city: String?
    let direct: String?
    let contactPersonName: String?
    let name: String?
    let address: String?
    let role: String?
    let createdBy:String?
    let associatedUsers:[AssociatedUsers?]
    let truckStock:[truckStock?]
    let storeLocation: Location?
    let currentLocation: Location?

    // Provide a custom initializer to handle optional id
    init(id: UUID? = nil, userName: String?, email: String?, password: String?, avatar: String? = nil, telephone: String? = nil, accNumber: String? = nil, businessName: String? = nil, city: String? = nil, direct: String? = nil, contactPersonName: String? = nil, name: String? = nil, address: String? = nil, role: String? = nil, createdBy:String? = nil, associatedUsers:[AssociatedUsers?]=[],truckStock:[truckStock?]=[], storeLocation: Location? = nil, currentLocation: Location? = nil) {
        self.id = id
        self.userName = userName
        self.email = email
        self.password = password
        self.telephone = telephone
        self.accNumber = accNumber
        self.businessName = businessName
        self.city = city
        self.direct = direct
        self.contactPersonName = contactPersonName
        self.name = name
        self.address = address
        self.role = role
        self.avatar = avatar
        self.createdBy = createdBy
        self.associatedUsers = associatedUsers
        self.truckStock = truckStock
        self.storeLocation = storeLocation
        self.currentLocation = currentLocation
    }

}

struct AssociatedUsers: Identifiable, Codable {
    let id: String?
    let email:String?
    let name:String?
    let address:String?
    let telephone:String?
    let role:String?
    
    init(id:String? = nil,email: String? = nil,name:String? = nil,address:String? = nil, telephone:String? = nil, role: String? = nil) {
        self.id = id
        self.email = email
        self.name = name
        self.address = address
        self.telephone = telephone
        self.role = role
    }
}

struct truckStock: Identifiable, Codable {
    let id: String?
    let productId:String?
    var truckStock:Int?
    
    init(id:String? = nil,productId: String? = nil, truckStock: Int? = nil) {
        self.id = id
        self.truckStock = truckStock
        self.productId = productId
    }
}

struct Location: Codable {
    let lat: Double?
    let lng: Double?
    
    init(lat: Double? = nil, lng: Double? = nil) {
        self.lat = lat
        self.lng = lng
    }
}
