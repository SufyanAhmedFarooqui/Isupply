//
//  APIResult.swift
//  iSupply
//
//  Created by hassan ghouri on 15/02/2024.
//

import Foundation
struct APIResult : Codable {
    let message : String?
    let error: String?
    let id: String?
    enum CodingKeys: String, CodingKey {

        case message = "message"
        case id = "id"
        case error = "error"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        id = try values.decodeIfPresent(String.self, forKey: .id)
        error = try values.decodeIfPresent(String.self, forKey: .error)
    }

}

struct TopSellingProductResult : Codable {
    let product : ProductModel?
    let totalRevenue: Int?
    enum CodingKeys: String, CodingKey {

        case product = "product"
        case totalRevenue = "totalRevenue"
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        product = try values.decodeIfPresent(ProductModel.self, forKey: .product)
        totalRevenue = try values.decodeIfPresent(Int.self, forKey: .totalRevenue)
    }
}
