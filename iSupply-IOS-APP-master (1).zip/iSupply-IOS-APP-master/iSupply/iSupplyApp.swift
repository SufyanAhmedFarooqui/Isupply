//
//  iSupplyApp.swift
//  iSupply
//
//  Created by hassan ghouri on 08/01/2024.
//

import SwiftUI
import Stripe
@main
struct iSupplyApp: App {
    init(){
        StripeAPI.defaultPublishableKey = "pk_test_51PANqfP4Bh3TwxQVWGyFnZACNszNmVyhwBaOgjd98JlE5s4V0Mf3YLLsmpZQNoqavL8cYjwPoxfzKKv0eQm1quaD00HcwAxlND"
    }
    var body: some Scene {
        WindowGroup {
            ContainerView()
        }
    }
}
